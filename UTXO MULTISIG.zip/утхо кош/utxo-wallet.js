/*!
 * UTXO КОШЕЛЕК — модуль мультисиг-кошельков для UTXO-блокчейнов
 * Версия 1.0 · самодостаточный файл: никаких зависимостей, работает офлайн
 * Сети: Bitcoin, Bitcoin Testnet3, Bitcoin Testnet4, Bitcoin Signet, Litecoin, Dogecoin, Dash, Bitcoin Cash, eCash, Zcash (прозрачные адреса), Zcash Testnet
 *
 * Подключение:  <script src="utxo-wallet.js"></script>  →  window.UTXO
 * Документация: ИНСТРУКЦИЯ-ДЛЯ-АГЕНТА.md
 */
(function (root) {
  'use strict';

/* ------------------------------------------------------------------ ядро --- */
const {
  enc: enc,
  dec: dec,
  concatBytes: concatBytes,
  bytesToHex: bytesToHex,
  hexToBytes: hexToBytes,
  utf8ToBytes: utf8ToBytes,
  wipe: wipe,
  K256: K256,
  sha256: sha256,
  sha256d: sha256d,
  K512: K512,
  MASK64: MASK64,
  rotr64: rotr64,
  ROUND_SHIFTS: ROUND_SHIFTS,
  _w512: _w512,
  sha512: sha512,
  RL: RL,
  RR: RR,
  SL: SL,
  SR: SR,
  KL: KL,
  KR: KR,
  rol32: rol32,
  ripemd160: ripemd160,
  hash160: hash160,
  hmac: hmac,
  hmacSha256: hmacSha256,
  hmacSha512: hmacSha512,
  pbkdf2Sha512: pbkdf2Sha512,
  P: P,
  N: N,
  Gx: Gx,
  Gy: Gy,
  mod: mod,
  powMod: powMod,
  invMod: invMod,
  INF: INF,
  jDouble: jDouble,
  jAddAffine: jAddAffine,
  jToAffine: jToAffine,
  G_TABLE: G_TABLE,
  pointMultiplyG: pointMultiplyG,
  pointMultiply: pointMultiply,
  pointAdd: pointAdd,
  G: G,
  pointPow: pointPow,
  isOnCurve: isOnCurve,
  bigintToBytes32: bigintToBytes32,
  bytesToBigint: bytesToBigint,
  serializePubkey: serializePubkey,
  parsePubkey: parsePubkey,
  CURVE: CURVE,
  B58: B58,
  base58Encode: base58Encode,
  base58Decode: base58Decode,
  base58checkEncode: base58checkEncode,
  base58checkDecode: base58checkDecode,
  CHARSET: CHARSET,
  BECH32_CONST: BECH32_CONST,
  BECH32M_CONST: BECH32M_CONST,
  bech32Polymod: bech32Polymod,
  bech32HrpExpand: bech32HrpExpand,
  convertBits: convertBits,
  bech32Encode: bech32Encode,
  bech32Decode: bech32Decode,
  segwitEncode: segwitEncode,
  segwitDecode: segwitDecode,
  cashaddrEncode: cashaddrEncode,
  cashaddrDecode: cashaddrDecode,
  WORDLIST: WORDLIST,
  HARDENED: HARDENED,
  NETWORKS: NETWORKS,
  getNetwork: getNetwork,
  SCRIPT_TYPES: SCRIPT_TYPES,
  getScriptType: getScriptType,
  scriptTypesFor: scriptTypesFor,
  verBytes: verBytes,
  generateMnemonic: generateMnemonic,
  entropyToMnemonic: entropyToMnemonic,
  mnemonicToEntropy: mnemonicToEntropy,
  normalizeMnemonic: normalizeMnemonic,
  validateMnemonic: validateMnemonic,
  mnemonicToSeed: mnemonicToSeed,
  ser32: ser32,
  fingerprintOf: fingerprintOf,
  HDKey: HDKey,
  bip48Path: bip48Path,
  _seedCache: _seedCache,
  cachedMnemonicToSeed: cachedMnemonicToSeed,
  clearSeedCache: clearSeedCache,
  deriveAccountKey: deriveAccountKey,
  precomputeAccounts: precomputeAccounts,
  sortPubkeysBip67: sortPubkeysBip67,
  isSortedBip67: isSortedBip67,
  OP_CHECKMULTISIG: OP_CHECKMULTISIG,
  buildMultisigScript: buildMultisigScript,
  multisigAddress: multisigAddress,
  p2pkhAddress: p2pkhAddress,
  DESC_CHARSET: DESC_CHARSET,
  DESC_INPUT_CHARSET: DESC_INPUT_CHARSET,
  DESC_CHECKSUM_CHARSET: DESC_CHECKSUM_CHARSET,
  descPolyMod: descPolyMod,
  descriptorChecksum: descriptorChecksum,
  addDescriptorChecksum: addDescriptorChecksum,
  createMultisigWallet: createMultisigWallet,
  deriveAddresses: deriveAddresses,
  xpubNodesFromWallet: xpubNodesFromWallet,
  toDescriptorExport: toDescriptorExport,
  accountDescriptor: accountDescriptor,
  toColdcardMultisigFile: toColdcardMultisigFile,
  EXPLORER_API: EXPLORER_API,
  explorerUrls: explorerUrls,
  getJson: getJson,
  getText: getText,
  scriptHashFromAddress: scriptHashFromAddress,
  verifyAddressLocally: verifyAddressLocally,
  satToBtc: satToBtc,
  esploraAddress: esploraAddress,
  blockcypherAddress: blockcypherAddress,
  blockchairAddress: blockchairAddress,
  checkAddressOnChain: checkAddressOnChain,
  checkTxPaysAddress: checkTxPaysAddress,
  tipHeight: tipHeight,
  faucetInfo: faucetInfo
} = (function () {

// ===================== src/core.mjs =====================
// ============================================================================
//  core.mjs — криптографическое ядро (БЕЗ внешних зависимостей)
//  SHA-256 / SHA-512 / RIPEMD-160 / HMAC / PBKDF2 / secp256k1 /
//  Base58Check / Bech32 / Bech32m / CashAddr
//  Всё написано вручную: файл работает и в браузере, и в Node.js.
// ============================================================================

/* ------------------------------------------------------------------ утилиты */
const enc = new TextEncoder();
const dec = new TextDecoder();

function concatBytes(...arrs) {
  const len = arrs.reduce((s, a) => s + a.length, 0);
  const out = new Uint8Array(len);
  let o = 0;
  for (const a of arrs) { out.set(a, o); o += a.length; }
  return out;
}
function bytesToHex(b) {
  let s = '';
  for (let i = 0; i < b.length; i++) s += b[i].toString(16).padStart(2, '0');
  return s;
}
function hexToBytes(hex) {
  const h = hex.replace(/^0x/i, '').replace(/\s+/g, '');
  if (h.length % 2) throw new Error('hex: РЅРµС‡С‘С‚РЅР°СЏ РґР»РёРЅР°');
  const out = new Uint8Array(h.length / 2);
  for (let i = 0; i < out.length; i++) {
    const v = parseInt(h.substr(i * 2, 2), 16);
    if (Number.isNaN(v)) throw new Error('hex: РЅРµРІРµСЂРЅС‹Р№ СЃРёРјРІРѕР»');
    out[i] = v;
  }
  return out;
}
function utf8ToBytes(s) { return enc.encode(s); }
/** XOR-конкатенация для затирания секретов в памяти */
function wipe(...arrs) {
  for (const a of arrs) if (a && a.fill) a.fill(0);
}

/* ------------------------------------------------------------------ SHA-256 */
const K256 = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);
function sha256(msg) {
  const h = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                             0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
  const bitLen = msg.length * 8;
  const padLen = ((msg.length + 9 + 63) >> 6) << 6;
  const m = new Uint8Array(padLen);
  m.set(msg); m[msg.length] = 0x80;
  const dv = new DataView(m.buffer);
  dv.setUint32(padLen - 4, bitLen >>> 0, false);
  dv.setUint32(padLen - 8, Math.floor(bitLen / 0x100000000), false);
  const w = new Uint32Array(64);
  for (let off = 0; off < padLen; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4, false);
    for (let i = 16; i < 64; i++) {
      const x = w[i - 15], y = w[i - 2];
      const s0 = ((x >>> 7) | (x << 25)) ^ ((x >>> 18) | (x << 14)) ^ (x >>> 3);
      const s1 = ((y >>> 17) | (y << 15)) ^ ((y >>> 19) | (y << 13)) ^ (y >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
    }
    let [a, b, c, d, e, f, g, hh] = h;
    for (let i = 0; i < 64; i++) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const ch = (e & f) ^ (~e & g);
      const t1 = (hh + S1 + ch + K256[i] + w[i]) >>> 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const mj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + mj) >>> 0;
      hh = g; g = f; f = e; e = (d + t1) >>> 0;
      d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    h[0] = (h[0] + a) >>> 0; h[1] = (h[1] + b) >>> 0; h[2] = (h[2] + c) >>> 0; h[3] = (h[3] + d) >>> 0;
    h[4] = (h[4] + e) >>> 0; h[5] = (h[5] + f) >>> 0; h[6] = (h[6] + g) >>> 0; h[7] = (h[7] + hh) >>> 0;
  }
  const out = new Uint8Array(32);
  const ov = new DataView(out.buffer);
  for (let i = 0; i < 8; i++) ov.setUint32(i * 4, h[i], false);
  return out;
}
function sha256d(msg) { return sha256(sha256(msg)); }

/* ------------------------------------------------------------------ SHA-512 */
const K512 = [
  0x428a2f98d728ae22n, 0x7137449123ef65cdn, 0xb5c0fbcfec4d3b2fn, 0xe9b5dba58189dbbcn,
  0x3956c25bf348b538n, 0x59f111f1b605d019n, 0x923f82a4af194f9bn, 0xab1c5ed5da6d8118n,
  0xd807aa98a3030242n, 0x12835b0145706fben, 0x243185be4ee4b28cn, 0x550c7dc3d5ffb4e2n,
  0x72be5d74f27b896fn, 0x80deb1fe3b1696b1n, 0x9bdc06a725c71235n, 0xc19bf174cf692694n,
  0xe49b69c19ef14ad2n, 0xefbe4786384f25e3n, 0x0fc19dc68b8cd5b5n, 0x240ca1cc77ac9c65n,
  0x2de92c6f592b0275n, 0x4a7484aa6ea6e483n, 0x5cb0a9dcbd41fbd4n, 0x76f988da831153b5n,
  0x983e5152ee66dfabn, 0xa831c66d2db43210n, 0xb00327c898fb213fn, 0xbf597fc7beef0ee4n,
  0xc6e00bf33da88fc2n, 0xd5a79147930aa725n, 0x06ca6351e003826fn, 0x142929670a0e6e70n,
  0x27b70a8546d22ffcn, 0x2e1b21385c26c926n, 0x4d2c6dfc5ac42aedn, 0x53380d139d95b3dfn,
  0x650a73548baf63den, 0x766a0abb3c77b2a8n, 0x81c2c92e47edaee6n, 0x92722c851482353bn,
  0xa2bfe8a14cf10364n, 0xa81a664bbc423001n, 0xc24b8b70d0f89791n, 0xc76c51a30654be30n,
  0xd192e819d6ef5218n, 0xd69906245565a910n, 0xf40e35855771202an, 0x106aa07032bbd1b8n,
  0x19a4c116b8d2d0c8n, 0x1e376c085141ab53n, 0x2748774cdf8eeb99n, 0x34b0bcb5e19b48a8n,
  0x391c0cb3c5c95a63n, 0x4ed8aa4ae3418acbn, 0x5b9cca4f7763e373n, 0x682e6ff3d6b2b8a3n,
  0x748f82ee5defb2fcn, 0x78a5636f43172f60n, 0x84c87814a1f0ab72n, 0x8cc702081a6439ecn,
  0x90befffa23631e28n, 0xa4506cebde82bde9n, 0xbef9a3f7b2c67915n, 0xc67178f2e372532bn,
  0xca273eceea26619cn, 0xd186b8c721c0c207n, 0xeada7dd6cde0eb1en, 0xf57d4f7fee6ed178n,
  0x06f067aa72176fban, 0x0a637dc5a2c898a6n, 0x113f9804bef90daen, 0x1b710b35131c471bn,
  0x28db77f523047d84n, 0x32caab7b40c72493n, 0x3c9ebe0a15c9bebcn, 0x431d67c49c100d4cn,
  0x4cc5d4becb3e42b6n, 0x597f299cfc657e2an, 0x5fcb6fab3ad6faecn, 0x6c44198c4a475817n,
];
const MASK64 = (1n << 64n) - 1n;
const rotr64 = (x, n) => ((x >> n) | (x << (64n - n))) & MASK64;

// Константы раундов разворачиваем в локальные переменные: обращение к
// K512[i] в цикле на 80 итераций стоит заметно дороже, чем к локальной.
// Раунды идут по 8 штук, поэтому достаточно 8 «слотов», сдвигаемых по кругу.
const ROUND_SHIFTS = [28n, 34n, 39n];
let _w512 = null, _m512 = null;

function sha512(msg) {
  // H — локальные переменные, а не массив: так движок держит их в регистрах
  let h0 = 0x6a09e667f3bcc908n, h1 = 0xbb67ae8584caa73bn, h2 = 0x3c6ef372fe94f82bn, h3 = 0xa54ff53a5f1d36f1n;
  let h4 = 0x510e527fade682d1n, h5 = 0x9b05688c2b3e6c1fn, h6 = 0x1f83d9abfb41bd6bn, h7 = 0x5be0cd19137e2179n;
  const bitLen = BigInt(msg.length) * 8n;
  const padLen = ((msg.length + 17 + 127) >> 7) << 7;
  let m, needNew = true;
  if (_m512 && _m512.length >= padLen && _m512.length <= padLen + 8192) { m = _m512; needNew = false; }
  if (needNew) { m = new Uint8Array(padLen); _m512 = m; }
  else m.fill(0, 0, padLen);
  m.set(msg); m[msg.length] = 0x80;
  const dv = new DataView(m.buffer);
  dv.setBigUint64(padLen - 8, bitLen & MASK64, false);
  const w = _w512 || (_w512 = new Array(80));
  for (let off = 0; off < padLen; off += 128) {
    for (let i = 0; i < 16; i++) w[i] = dv.getBigUint64(off + i * 8, false);
    for (let i = 16; i < 80; i++) {
      const x = w[i - 15], y = w[i - 2];
      const s0 = rotr64(x, 1n) ^ rotr64(x, 8n) ^ (x >> 7n);
      const s1 = rotr64(y, 19n) ^ rotr64(y, 61n) ^ (y >> 6n);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & MASK64;
    }
    let a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, hh = h7;
    for (let i = 0; i < 80; i += 8) {
      // 8 раундов подряд, без обращения к массиву констант через индекс в цикле
      for (let j = 0; j < 8; j++) {
        const k = K512[i + j], wi = w[i + j];
        const S1 = rotr64(e, 14n) ^ rotr64(e, 18n) ^ rotr64(e, 41n);
        const ch = (e & f) ^ (~e & g & MASK64);
        const t1 = (hh + S1 + ch + k + wi) & MASK64;
        const S0 = rotr64(a, ROUND_SHIFTS[0]) ^ rotr64(a, ROUND_SHIFTS[1]) ^ rotr64(a, ROUND_SHIFTS[2]);
        const mj = (a & b) ^ (a & c) ^ (b & c);
        const t2 = (S0 + mj) & MASK64;
        hh = g; g = f; f = e; e = (d + t1) & MASK64;
        d = c; c = b; b = a; a = (t1 + t2) & MASK64;
      }
    }
    h0 = (h0 + a) & MASK64; h1 = (h1 + b) & MASK64; h2 = (h2 + c) & MASK64; h3 = (h3 + d) & MASK64;
    h4 = (h4 + e) & MASK64; h5 = (h5 + f) & MASK64; h6 = (h6 + g) & MASK64; h7 = (h7 + hh) & MASK64;
  }
  const out = new Uint8Array(64);
  const ov = new DataView(out.buffer);
  ov.setBigUint64(0, h0, false); ov.setBigUint64(8, h1, false);
  ov.setBigUint64(16, h2, false); ov.setBigUint64(24, h3, false);
  ov.setBigUint64(32, h4, false); ov.setBigUint64(40, h5, false);
  ov.setBigUint64(48, h6, false); ov.setBigUint64(56, h7, false);
  return out;
}

/* --------------------------------------------------------------- RIPEMD-160 */
const RL = [
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
  7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8,
  3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12,
  1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2,
  4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13,
];
const RR = [
  5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12,
  6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2,
  15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13,
  8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14,
  12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11,
];
const SL = [
  11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8,
  7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12,
  11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5,
  11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12,
  9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6,
];
const SR = [
  8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6,
  9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11,
  9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5,
  15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8,
  8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11,
];
const KL = [0x00000000, 0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xa953fd4e];
const KR = [0x50a28be6, 0x5c4dd124, 0x6d703ef3, 0x7a6d76e9, 0x00000000];
const rol32 = (x, n) => ((x << n) | (x >>> (32 - n))) >>> 0;

function ripemd160(msg) {
  let h0 = 0x67452301, h1 = 0xefcdab89, h2 = 0x98badcfe, h3 = 0x10325476, h4 = 0xc3d2e1f0;
  const bitLen = msg.length * 8;
  const padLen = ((msg.length + 9 + 63) >> 6) << 6;
  const m = new Uint8Array(padLen);
  m.set(msg); m[msg.length] = 0x80;
  const dv = new DataView(m.buffer);
  // 64-битная длина в битах, little-endian: младшее слово в конце, старшее — перед ним
  dv.setUint32(padLen - 4, Math.floor(bitLen / 0x100000000) >>> 0, true);
  dv.setUint32(padLen - 8, bitLen >>> 0, true);
  for (let off = 0; off < padLen; off += 64) {
    const X = new Uint32Array(16);
    for (let i = 0; i < 16; i++) X[i] = dv.getUint32(off + i * 4, true);
    let al = h0, bl = h1, cl = h2, dl = h3, el = h4;
    let ar = h0, br = h1, cr = h2, dr = h3, er = h4;
    for (let j = 0; j < 80; j++) {
      const rnd = (j / 16) | 0;
      let t = (al + (rnd === 0 ? (bl ^ cl ^ dl) : rnd === 1 ? ((bl & cl) | (~bl & dl))
             : rnd === 2 ? (((bl | ~cl) >>> 0) ^ dl) : rnd === 3 ? ((bl & dl) | (cl & ~dl))
             : (bl ^ (cl | ~dl))) + X[RL[j]] + KL[rnd]) >>> 0;
      t = (rol32(t, SL[j]) + el) >>> 0;
      al = el; el = dl; dl = rol32(cl, 10); cl = bl; bl = t;
      let u = (ar + (rnd === 0 ? (br ^ (cr | ~dr)) : rnd === 1 ? ((br & dr) | (cr & ~dr))
             : rnd === 2 ? (((br | ~cr) >>> 0) ^ dr) : rnd === 3 ? ((br & cr) | (~br & dr))
             : (br ^ cr ^ dr)) + X[RR[j]] + KR[rnd]) >>> 0;
      u = (rol32(u, SR[j]) + er) >>> 0;
      ar = er; er = dr; dr = rol32(cr, 10); cr = br; br = u;
    }
    const t = (h1 + cl + dr) >>> 0;
    h1 = (h2 + dl + er) >>> 0;
    h2 = (h3 + el + ar) >>> 0;
    h3 = (h4 + al + br) >>> 0;
    h4 = (h0 + bl + cr) >>> 0;
    h0 = t;
  }
  const out = new Uint8Array(20);
  const ov = new DataView(out.buffer);
  ov.setUint32(0, h0, true); ov.setUint32(4, h1, true); ov.setUint32(8, h2, true);
  ov.setUint32(12, h3, true); ov.setUint32(16, h4, true);
  return out;
}
function hash160(msg) { return ripemd160(sha256(msg)); }

/* -------------------------------------------------------- HMAC / PBKDF2 */
function hmac(hashFn, blockSize, key, msg) {
  let k = key.length > blockSize ? hashFn(key) : key;
  const pad = new Uint8Array(blockSize);
  pad.set(k);
  const ipad = new Uint8Array(blockSize), opad = new Uint8Array(blockSize);
  for (let i = 0; i < blockSize; i++) { ipad[i] = pad[i] ^ 0x36; opad[i] = pad[i] ^ 0x5c; }
  const inner = hashFn(concatBytes(ipad, msg));
  return hashFn(concatBytes(opad, inner));
}

/** HMAC-SHA-256 (используется только для RFC 6979, не в горячем пути) */
const hmacSha256 = (key, msg) => hmac(sha256, 64, key, msg);

/** HMAC-SHA-512 — простая и очевидно корректная реализация (эталон для остального). */
function hmacSha512(key, msg) {
  const BLOCK = 128;
  const k = key.length > BLOCK ? sha512(key) : key;
  if (msg.length <= 64) {
    const ipad = new Uint8Array(BLOCK);
    const opad = new Uint8Array(BLOCK);
    for (let i = 0; i < BLOCK; i++) {
      const b = i < k.length ? k[i] : 0;
      ipad[i] = b ^ 0x36;
      opad[i] = b ^ 0x5c;
    }
    const inner = sha512(concatBytes(ipad, msg));
    return sha512(concatBytes(opad, inner));
  }
  return hmac(sha512, BLOCK, key, msg);
}

/**
 * PBKDF2-HMAC-SHA512 — только для BIP-39 seed (2048 итераций).
 * Внутренний цикл не создаёт массивов: ipad/opad и сообщение живут
 * в заранее выделенных буферах, иначе сборщик мусора съедает больше
 * времени, чем сама криптография.
 */
function pbkdf2Sha512(password, salt, iterations, dkLen = 64) {
  const BLOCK = 128;
  const blocks = Math.ceil(dkLen / 64);
  const out = new Uint8Array(blocks * 64);
  const k = password.length > BLOCK ? sha512(password) : password;
  const ipad = new Uint8Array(BLOCK);
  const opad = new Uint8Array(BLOCK);
  for (let i = 0; i < BLOCK; i++) {
    const b = i < k.length ? k[i] : 0;
    ipad[i] = b ^ 0x36;
    opad[i] = b ^ 0x5c;
  }
  const t = new Uint8Array(64);
  const u = new Uint8Array(64);
  const ob = new Uint8Array(BLOCK + 64);
  ob.set(opad);            // opad лежит в ob[0..128) и больше не меняется:
                           // hmacInto всегда пишет хеш в ob[128..192)

  /** HMAC(prefix || msg): sha512() сам дописывает паддинг, поэтому
   *  срез — это ровно данные, без «места под паддинг». */
  const hmacInto = (prefix, msgBytes) => {
    const inner = sha512(concatBytes(prefix, msgBytes));
    ob.set(inner, BLOCK);
    u.set(sha512(ob));
  };

  for (let i = 1; i <= blocks; i++) {
    const idx = new Uint8Array(4);
    new DataView(idx.buffer).setUint32(0, i, false);
    hmacInto(ipad, concatBytes(salt, idx));                   // U1
    t.set(u);
    for (let j = 1; j < iterations; j++) {
      hmacInto(ipad, u);                                      // Un = HMAC(Un-1)
      for (let kk = 0; kk < 64; kk++) t[kk] ^= u[kk];
    }
    out.set(t, (i - 1) * 64);
  }
  wipe(u, t);
  return out.slice(0, dkLen);
}

/* ---------------------------------------------------------------- secp256k1 */
const P = 0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2fn;
const N = 0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n;
const Gx = 0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798n;
const Gy = 0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8n;

const mod = (a, m = P) => ((a % m) + m) % m;

/** модульное возведение в степень */
function powMod(base, exp, m) {
  let r = 1n; base = mod(base, m);
  while (exp > 0n) {
    if (exp & 1n) r = (r * base) % m;
    base = (base * base) % m;
    exp >>= 1n;
  }
  return r;
}
const invMod = (a, m = P) => {
  // расширенный алгоритм Евклида: на порядки быстрее, чем a^(m-2) mod m
  let r0 = mod(a, m);
  if (r0 === 0n) throw new Error('invMod: РґРµР»РµРЅРёРµ РЅР° РЅРѕР»СЊ');
  let r1 = m, s0 = 1n, s1 = 0n;
  while (r1 !== 0n) {
    const q = r0 / r1;
    [r0, r1] = [r1, r0 - q * r1];
    [s0, s1] = [s1, s0 - q * s1];
  }
  if (r0 !== 1n) throw new Error('invMod: СЌР»РµРјРµРЅС‚ РЅРµ РѕР±СЂР°С‚РёРј');
  return mod(s0, m);
};

/** INF = (0, 1, 0) в якобиевых координатах */
const INF = [0n, 1n, 0n];

function jDouble(p) {
  const [X, Y, Z] = p;
  if (Z === 0n || Y === 0n) return INF;
  const A = (X * X) % P, B = (Y * Y) % P, C = (B * B) % P;
  const D = mod(2n * ((mod(X + B) ** 2n) - A - C));
  const E = (3n * A) % P, FF = (E * E) % P;
  const X3 = mod(FF - 2n * D);
  const Y3 = mod(E * mod(D - X3) - 8n * C);
  const Z3 = mod(2n * Y * Z);
  return [X3, Y3, Z3];
}
/** смешанное сложение: p якобиева, q аффинная */
function jAddAffine(p, q) {
  if (p[2] === 0n) return [q[0], q[1], 1n];
  if (q === null) return p;
  const [X1, Y1, Z1] = p; const [x2, y2] = q;
  const Z1Z1 = (Z1 * Z1) % P;
  const U2 = (x2 * Z1Z1) % P;
  const S2 = (((y2 * Z1) % P) * Z1Z1) % P;
  const H = mod(U2 - X1);
  const R = mod(S2 - Y1);
  if (H === 0n) return R === 0n ? jDouble(p) : INF;
  const HH = (H * H) % P, HHH = (H * HH) % P, V = (X1 * HH) % P;
  const X3 = mod(R * R - HHH - 2n * V);
  const Y3 = mod(R * mod(V - X3) - Y1 * HHH);
  const Z3 = (((Z1 * H) % P) * 1n) % P;
  return [X3, Y3, Z3];
}
/** якобиева -> аффинная (единственное обращение по модулю за всё умножение) */
function jToAffine(p) {
  if (p[2] === 0n) return null;
  if (p[2] === 1n) return [p[0], p[1]];
  const zi = invMod(p[2]);
  const zi2 = (zi * zi) % P;
  const zi3 = (zi2 * zi) % P;
  return [(p[0] * zi2) % P, (p[1] * zi3) % P];
}

/** предвычисленные нечётные кратные G: G, 3G, 5G, ... 15G (аффинные) */
const G_TABLE = (() => {
  const t = [[Gx, Gy]];                                   // 1·G
  const g2 = jToAffine(jDouble([Gx, Gy, 1n]));            // 2·G
  for (let i = 1; i < 8; i++) t.push(jToAffine(jAddAffine([t[i - 1][0], t[i - 1][1], 1n], g2)));
  return t;
})();

/**
 * k * G по 4-битному окну (wNAF): 64 окна по 4 удвоения + 1 сложение.
 * Обращение по модулю — только одно, в самом конце. Это ~в 300 раз быстрее,
 * чем наивная лестница с переводом в аффинные координаты на каждом шаге.
 */
function pointMultiplyG(k) {
  let kk = mod(k, N);
  if (kk === 0n) return null;
  const naf = [];
  while (kk > 0n) {
    if (kk & 1n) {
      let z = Number(kk & 15n);
      if (z > 7) z -= 16;                    // -8..7, нечётное
      naf.push(z);
      kk -= BigInt(z);
    } else naf.push(0);
    kk >>= 1n;
  }
  let acc = INF;
  for (let i = naf.length - 1; i >= 0; i--) {
    acc = jDouble(acc);
    const z = naf[i];
    if (z === 0) continue;
    const idx = Math.abs(z) >> 1;
    const pt = G_TABLE[idx];
    acc = jAddAffine(acc, z > 0 ? pt : [pt[0], mod(-pt[1])]);
  }
  return jToAffine(acc);
}

/** k * произвольная точка (для остальных нужд; таблицы нет, но тоже быстро) */
function pointMultiply(k, pt) {
  if (!pt) return null;
  if (pt[0] === Gx && pt[1] === Gy) return pointMultiplyG(k);
  let kk = mod(k, N);
  if (kk === 0n) return null;
  let acc = INF;
  let base = [pt[0], pt[1], 1n];
  while (kk > 0n) {
    if (kk & 1n) acc = jAddAffine(acc, jToAffine(base));
    base = jDouble(base);
    kk >>= 1n;
    if (base[2] === 0n) break;
  }
  return jToAffine(acc);
}

/** сложение двух аффинных точек (может вернуть null = точка на бесконечности) */
function pointAdd(a, b) {
  if (!a) return b;
  if (!b) return a;
  if (a[0] === b[0]) {
    if (mod(a[1] + b[1]) === 0n) return null;              // P + (-P) = ∞
    return jToAffine(jDouble([a[0], a[1], 1n]));           // удвоение
  }
  const lambda = mod((b[1] - a[1]) * invMod(b[0] - a[0]));
  const x3 = mod(lambda * lambda - a[0] - b[0]);
  const y3 = mod(lambda * mod(a[0] - x3) - a[1]);
  return [x3, y3];
}
const G = [Gx, Gy];
/** возведение точки в степень (alias для читаемости) */
const pointPow = pointMultiply;

/** проверка, что точка лежит на кривой */
function isOnCurve(pt) {
  if (!pt) return false;
  const [x, y] = pt;
  if (x <= 0n || x >= P || y <= 0n || y >= P) return false;
  return mod(y * y - x * x * x - 7n) === 0n;
}

function bigintToBytes32(n) {
  const out = new Uint8Array(32);
  for (let i = 31; i >= 0; i--) { out[i] = Number(n & 0xffn); n >>= 8n; }
  return out;
}
function bytesToBigint(b) {
  let n = 0n;
  for (let i = 0; i < b.length; i++) n = (n << 8n) | BigInt(b[i]);
  return n;
}
/** 33-байтовый сжатый публичный ключ */
function serializePubkey(pt) {
  if (!pt) throw new Error('serializePubkey: точка на бесконечности');
  return concatBytes(new Uint8Array([pt[1] & 1n ? 0x03 : 0x02]), bigintToBytes32(pt[0]));
}
/** разбор сжатого/несжатого публичного ключа -> аффинная точка */
function parsePubkey(bytes) {
  if (bytes.length === 33) {
    const prefix = bytes[0];
    if (prefix !== 2 && prefix !== 3) throw new Error('parsePubkey: неверный префикс');
    const x = bytesToBigint(bytes.slice(1));
    if (x >= P) throw new Error('parsePubkey: x РІРЅРµ РїРѕР»СЏ');
    const y2 = mod(x * x * x + 7n);
    // y = (y2)^((P+1)/4) — P ≡ 3 (mod 4)
    let y = powMod(y2, (P + 1n) / 4n, P);
    if (mod(y * y) !== y2) throw new Error('parsePubkey: точка не на кривой');
    if ((y & 1n) !== BigInt(prefix & 1)) y = mod(-y);
    return [x, y];
  }
  if (bytes.length === 65 && bytes[0] === 4) {
    const x = bytesToBigint(bytes.slice(1, 33));
    const y = bytesToBigint(bytes.slice(33, 65));
    const pt = [x, y];
    if (!isOnCurve(pt)) throw new Error('parsePubkey: точка не на кривой');
    return pt;
  }
  throw new Error('parsePubkey: РЅРµРїРѕРґРґРµСЂР¶РёРІР°РµРјР°СЏ РґР»РёРЅР° ' + bytes.length);
}
const CURVE = { P, N, G, pointMultiply, pointAdd, serializePubkey, parsePubkey, isOnCurve };

/* ------------------------------------------------------------ Base58Check */
const B58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
function base58Encode(bytes) {
  let n = bytesToBigint(bytes);
  let out = '';
  while (n > 0n) { out = B58[Number(n % 58n)] + out; n /= 58n; }
  for (let i = 0; i < bytes.length && bytes[i] === 0; i++) out = '1' + out;
  return out;
}
function base58Decode(str) {
  let n = 0n;
  for (const ch of str) {
    const idx = B58.indexOf(ch);
    if (idx < 0) throw new Error('base58: РЅРµРІРµСЂРЅС‹Р№ СЃРёРјРІРѕР» ' + ch);
    n = n * 58n + BigInt(idx);
  }
  const bytes = [];
  while (n > 0n) { bytes.unshift(Number(n & 0xffn)); n >>= 8n; }
  let zeros = 0;
  for (let i = 0; i < str.length && str[i] === '1'; i++) zeros++;
  return new Uint8Array([...new Array(zeros).fill(0), ...bytes]);
}
function base58checkEncode(payload) {
  const checksum = sha256d(payload).slice(0, 4);
  return base58Encode(concatBytes(payload, checksum));
}
function base58checkDecode(str) {
  const raw = base58Decode(str);
  const payload = raw.slice(0, -4);
  const cs = raw.slice(-4);
  const expect = sha256d(payload).slice(0, 4);
  for (let i = 0; i < 4; i++) if (cs[i] !== expect[i]) throw new Error('base58check: РЅРµРІРµСЂРЅР°СЏ РєРѕРЅС‚СЂРѕР»СЊРЅР°СЏ СЃСѓРјРјР°');
  return payload;
}

/* ---------------------------------------------------------------- Bech32 */
const CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
const BECH32_CONST = 1;
const BECH32M_CONST = 0x2bc830a3;

function bech32Polymod(values) {
  const GEN = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
  let chk = 1;
  for (const v of values) {
    const top = chk >>> 25;
    chk = ((chk & 0x1ffffff) << 5) ^ v;
    for (let i = 0; i < 5; i++) if ((top >>> i) & 1) chk ^= GEN[i];
  }
  return chk;
}
function bech32HrpExpand(hrp) {
  const out = [];
  for (const c of hrp) out.push(c.charCodeAt(0) >> 5);
  out.push(0);
  for (const c of hrp) out.push(c.charCodeAt(0) & 31);
  return out;
}
function convertBits(data, from, to, pad) {
  let acc = 0, bits = 0;
  const out = [];
  const maxv = (1 << to) - 1;
  for (const value of data) {
    if (value < 0 || value >> from !== 0) throw new Error('convertBits: Р·РЅР°С‡РµРЅРёРµ РІРЅРµ РґРёР°РїР°Р·РѕРЅР°');
    acc = (acc << from) | value;
    bits += from;
    while (bits >= to) { bits -= to; out.push((acc >> bits) & maxv); }
  }
  if (pad) { if (bits > 0) out.push((acc << (to - bits)) & maxv); }
  else if (bits >= from || ((acc << (to - bits)) & maxv)) throw new Error('convertBits: некорректный padding');
  return out;
}
function bech32Encode(hrp, data, spec = 'bech32') {
  const constVal = spec === 'bech32m' ? BECH32M_CONST : BECH32_CONST;
  const values = [...bech32HrpExpand(hrp), ...data];
  const polymod = bech32Polymod([...values, 0, 0, 0, 0, 0, 0]) ^ constVal;
  const checksum = [];
  for (let i = 0; i < 6; i++) checksum.push((polymod >>> (5 * (5 - i))) & 31);
  return hrp + '1' + [...data, ...checksum].map((d) => CHARSET[d]).join('');
}
function bech32Decode(str) {
  if (str.length > 90) throw new Error('bech32: СЃР»РёС€РєРѕРј РґР»РёРЅРЅР°СЏ СЃС‚СЂРѕРєР°');
  if (str !== str.toLowerCase() && str !== str.toUpperCase()) throw new Error('bech32: смешанный регистр');
  const s = str.toLowerCase();
  const pos = s.lastIndexOf('1');
  if (pos < 1 || pos + 7 > s.length) throw new Error('bech32: РЅРµС‚ СЂР°Р·РґРµР»РёС‚РµР»СЏ');
  const hrp = s.slice(0, pos);
  const data = [];
  for (const c of s.slice(pos + 1)) {
    const v = CHARSET.indexOf(c);
    if (v < 0) throw new Error('bech32: РЅРµРІРµСЂРЅС‹Р№ СЃРёРјРІРѕР»');
    data.push(v);
  }
  const pm = bech32Polymod([...bech32HrpExpand(hrp), ...data]);
  const spec = pm === BECH32_CONST ? 'bech32' : pm === BECH32M_CONST ? 'bech32m' : null;
  if (!spec) throw new Error('bech32: РЅРµРІРµСЂРЅР°СЏ РєРѕРЅС‚СЂРѕР»СЊРЅР°СЏ СЃСѓРјРјР°');
  return { hrp, data: data.slice(0, -6), spec };
}
/** bech32-адрес segwit: [version, ...program] */
function segwitEncode(hrp, version, program) {
  const data = [version, ...convertBits([...program], 8, 5, true)];
  return bech32Encode(hrp, data, version === 0 ? 'bech32' : 'bech32m');
}
function segwitDecode(hrp, addr) {
  const { hrp: h, data, spec } = bech32Decode(addr);
  if (h !== hrp) throw new Error('segwit: РЅРµРІРµСЂРЅС‹Р№ hrp');
  const version = data[0];
  if (version > 16) throw new Error('segwit: неверная версия');
  const program = Uint8Array.from(convertBits(data.slice(1), 5, 8, false));
  if (version === 0 && spec !== 'bech32') throw new Error('segwit: v0 С‚СЂРµР±СѓРµС‚ bech32');
  if (version > 0 && spec !== 'bech32m') throw new Error('segwit: v1+ С‚СЂРµР±СѓРµС‚ bech32m');
  if (program.length < 2 || program.length > 40) throw new Error('segwit: неверная длина программы');
  if (version === 0 && program.length !== 20 && program.length !== 32) throw new Error('segwit: v0 РґР»РёРЅР° 20/32');
  return { version, program, spec };
}

/* --------------------------------------------------------------- CashAddr */
function cashaddrEncode(prefix, typeBits, hash) {
  const sizeBits = hash.length === 20 ? 0 : hash.length === 24 ? 1 : hash.length === 28 ? 2
    : hash.length === 32 ? 3 : hash.length === 40 ? 4 : hash.length === 48 ? 5
    : hash.length === 56 ? 6 : hash.length === 64 ? 7 : (() => { throw new Error('cashaddr: РЅРµРІРµСЂРЅР°СЏ РґР»РёРЅР° С…РµС€Р°'); })();
  const versionByte = (typeBits << 3) | sizeBits;
  const payload = [versionByte, ...hash];
  const data5 = convertBits(payload, 8, 5, true);
  const prefixVals = [...prefix].map((c) => c.charCodeAt(0) & 31);
  const GEN = [0x98f2bc8e61n, 0x79b76d99e2n, 0xf33e5fb3c4n, 0xae2eabe2a8n, 0x1e4f43e470n];
  const polymod = (values) => {
    let chk = 1n;
    for (const v of values) {
      const top = chk >> 35n;
      chk = ((chk & 0x07ffffffffn) << 5n) ^ BigInt(v);
      for (let i = 0; i < 5; i++) if ((top >> BigInt(i)) & 1n) chk ^= GEN[i];
    }
    return chk;
  };
  const chk = polymod([...prefixVals, 0, ...data5, 0, 0, 0, 0, 0, 0, 0, 0]) ^ 1n;
  const checksum = [];
  for (let i = 0; i < 8; i++) checksum.push(Number((chk >> BigInt(5 * (7 - i))) & 31n));
  return prefix + ':' + [...data5, ...checksum].map((w) => CHARSET[w]).join('');
}
function cashaddrDecode(addr) {
  const s = addr.toLowerCase();
  const pos = s.indexOf(':');
  const prefix = pos >= 0 ? s.slice(0, pos) : 'bitcoincash';
  const body = pos >= 0 ? s.slice(pos + 1) : s;
  const data = [...body].map((c) => {
    const v = CHARSET.indexOf(c);
    if (v < 0) throw new Error('cashaddr: РЅРµРІРµСЂРЅС‹Р№ СЃРёРјРІРѕР»');
    return v;
  });
  if (data.length < 8) throw new Error('cashaddr: слишком короткий адрес');
  const payload5 = data.slice(0, -8);
  const checksum5 = data.slice(-8);
  const prefixVals = [...prefix].map((c) => c.charCodeAt(0) & 31);
  const GEN = [0x98f2bc8e61n, 0x79b76d99e2n, 0xf33e5fb3c4n, 0xae2eabe2a8n, 0x1e4f43e470n];
  // проверка по BCH-спеке: polymod(expand(prefix) ++ data ++ checksum) должен дать 0
  let chk = 1n;
  for (const v of [...prefixVals, 0, ...payload5, ...checksum5]) {
    const top = chk >> 35n;
    chk = ((chk & 0x07ffffffffn) << 5n) ^ BigInt(v);
    for (let i = 0; i < 5; i++) if ((top >> BigInt(i)) & 1n) chk ^= GEN[i];
  }
  // проверка по BCH-спеке: polymod(expand(prefix) ++ data5 ++ checksum) должен дать 1
  // (create_checksum = polymod(...) ^ 1, поэтому при верном checksum итог равен 1, а не 0)
  if (chk !== 1n) throw new Error('cashaddr: РЅРµРІРµСЂРЅР°СЏ РєРѕРЅС‚СЂРѕР»СЊРЅР°СЏ СЃСѓРјРјР°');
  const payload = convertBits(payload5, 5, 8, false);
  const versionByte = payload[0];
  const typeBits = versionByte >> 3;
  const sizeBits = versionByte & 7;
  const sizeMap = [20, 24, 28, 32, 40, 48, 56, 64];
  const hash = Uint8Array.from(payload.slice(1));
  if (hash.length !== sizeMap[sizeBits]) throw new Error('cashaddr: РґР»РёРЅР° С…РµС€Р° РЅРµ СЃРѕРІРїР°РґР°РµС‚ СЃ version byte');
  return { prefix, typeBits, hash, type: typeBits === 0 ? 'P2PKH' : typeBits === 1 ? 'P2SH' : 'unknown' };
}



// ===================== src/bip39-english.mjs =====================
const WORDLIST = ["abandon","ability","able","about","above","absent","absorb","abstract","absurd","abuse","access","accident","account","accuse","achieve","acid","acoustic","acquire","across","act","action","actor","actress","actual","adapt","add","addict","address","adjust","admit","adult","advance","advice","aerobic","affair","afford","afraid","again","age","agent","agree","ahead","aim","air","airport","aisle","alarm","album","alcohol","alert","alien","all","alley","allow","almost","alone","alpha","already","also","alter","always","amateur","amazing","among","amount","amused","analyst","anchor","ancient","anger","angle","angry","animal","ankle","announce","annual","another","answer","antenna","antique","anxiety","any","apart","apology","appear","apple","approve","april","arch","arctic","area","arena","argue","arm","armed","armor","army","around","arrange","arrest","arrive","arrow","art","artefact","artist","artwork","ask","aspect","assault","asset","assist","assume","asthma","athlete","atom","attack","attend","attitude","attract","auction","audit","august","aunt","author","auto","autumn","average","avocado","avoid","awake","aware","away","awesome","awful","awkward","axis","baby","bachelor","bacon","badge","bag","balance","balcony","ball","bamboo","banana","banner","bar","barely","bargain","barrel","base","basic","basket","battle","beach","bean","beauty","because","become","beef","before","begin","behave","behind","believe","below","belt","bench","benefit","best","betray","better","between","beyond","bicycle","bid","bike","bind","biology","bird","birth","bitter","black","blade","blame","blanket","blast","bleak","bless","blind","blood","blossom","blouse","blue","blur","blush","board","boat","body","boil","bomb","bone","bonus","book","boost","border","boring","borrow","boss","bottom","bounce","box","boy","bracket","brain","brand","brass","brave","bread","breeze","brick","bridge","brief","bright","bring","brisk","broccoli","broken","bronze","broom","brother","brown","brush","bubble","buddy","budget","buffalo","build","bulb","bulk","bullet","bundle","bunker","burden","burger","burst","bus","business","busy","butter","buyer","buzz","cabbage","cabin","cable","cactus","cage","cake","call","calm","camera","camp","can","canal","cancel","candy","cannon","canoe","canvas","canyon","capable","capital","captain","car","carbon","card","cargo","carpet","carry","cart","case","cash","casino","castle","casual","cat","catalog","catch","category","cattle","caught","cause","caution","cave","ceiling","celery","cement","census","century","cereal","certain","chair","chalk","champion","change","chaos","chapter","charge","chase","chat","cheap","check","cheese","chef","cherry","chest","chicken","chief","child","chimney","choice","choose","chronic","chuckle","chunk","churn","cigar","cinnamon","circle","citizen","city","civil","claim","clap","clarify","claw","clay","clean","clerk","clever","click","client","cliff","climb","clinic","clip","clock","clog","close","cloth","cloud","clown","club","clump","cluster","clutch","coach","coast","coconut","code","coffee","coil","coin","collect","color","column","combine","come","comfort","comic","common","company","concert","conduct","confirm","congress","connect","consider","control","convince","cook","cool","copper","copy","coral","core","corn","correct","cost","cotton","couch","country","couple","course","cousin","cover","coyote","crack","cradle","craft","cram","crane","crash","crater","crawl","crazy","cream","credit","creek","crew","cricket","crime","crisp","critic","crop","cross","crouch","crowd","crucial","cruel","cruise","crumble","crunch","crush","cry","crystal","cube","culture","cup","cupboard","curious","current","curtain","curve","cushion","custom","cute","cycle","dad","damage","damp","dance","danger","daring","dash","daughter","dawn","day","deal","debate","debris","decade","december","decide","decline","decorate","decrease","deer","defense","define","defy","degree","delay","deliver","demand","demise","denial","dentist","deny","depart","depend","deposit","depth","deputy","derive","describe","desert","design","desk","despair","destroy","detail","detect","develop","device","devote","diagram","dial","diamond","diary","dice","diesel","diet","differ","digital","dignity","dilemma","dinner","dinosaur","direct","dirt","disagree","discover","disease","dish","dismiss","disorder","display","distance","divert","divide","divorce","dizzy","doctor","document","dog","doll","dolphin","domain","donate","donkey","donor","door","dose","double","dove","draft","dragon","drama","drastic","draw","dream","dress","drift","drill","drink","drip","drive","drop","drum","dry","duck","dumb","dune","during","dust","dutch","duty","dwarf","dynamic","eager","eagle","early","earn","earth","easily","east","easy","echo","ecology","economy","edge","edit","educate","effort","egg","eight","either","elbow","elder","electric","elegant","element","elephant","elevator","elite","else","embark","embody","embrace","emerge","emotion","employ","empower","empty","enable","enact","end","endless","endorse","enemy","energy","enforce","engage","engine","enhance","enjoy","enlist","enough","enrich","enroll","ensure","enter","entire","entry","envelope","episode","equal","equip","era","erase","erode","erosion","error","erupt","escape","essay","essence","estate","eternal","ethics","evidence","evil","evoke","evolve","exact","example","excess","exchange","excite","exclude","excuse","execute","exercise","exhaust","exhibit","exile","exist","exit","exotic","expand","expect","expire","explain","expose","express","extend","extra","eye","eyebrow","fabric","face","faculty","fade","faint","faith","fall","false","fame","family","famous","fan","fancy","fantasy","farm","fashion","fat","fatal","father","fatigue","fault","favorite","feature","february","federal","fee","feed","feel","female","fence","festival","fetch","fever","few","fiber","fiction","field","figure","file","film","filter","final","find","fine","finger","finish","fire","firm","first","fiscal","fish","fit","fitness","fix","flag","flame","flash","flat","flavor","flee","flight","flip","float","flock","floor","flower","fluid","flush","fly","foam","focus","fog","foil","fold","follow","food","foot","force","forest","forget","fork","fortune","forum","forward","fossil","foster","found","fox","fragile","frame","frequent","fresh","friend","fringe","frog","front","frost","frown","frozen","fruit","fuel","fun","funny","furnace","fury","future","gadget","gain","galaxy","gallery","game","gap","garage","garbage","garden","garlic","garment","gas","gasp","gate","gather","gauge","gaze","general","genius","genre","gentle","genuine","gesture","ghost","giant","gift","giggle","ginger","giraffe","girl","give","glad","glance","glare","glass","glide","glimpse","globe","gloom","glory","glove","glow","glue","goat","goddess","gold","good","goose","gorilla","gospel","gossip","govern","gown","grab","grace","grain","grant","grape","grass","gravity","great","green","grid","grief","grit","grocery","group","grow","grunt","guard","guess","guide","guilt","guitar","gun","gym","habit","hair","half","hammer","hamster","hand","happy","harbor","hard","harsh","harvest","hat","have","hawk","hazard","head","health","heart","heavy","hedgehog","height","hello","helmet","help","hen","hero","hidden","high","hill","hint","hip","hire","history","hobby","hockey","hold","hole","holiday","hollow","home","honey","hood","hope","horn","horror","horse","hospital","host","hotel","hour","hover","hub","huge","human","humble","humor","hundred","hungry","hunt","hurdle","hurry","hurt","husband","hybrid","ice","icon","idea","identify","idle","ignore","ill","illegal","illness","image","imitate","immense","immune","impact","impose","improve","impulse","inch","include","income","increase","index","indicate","indoor","industry","infant","inflict","inform","inhale","inherit","initial","inject","injury","inmate","inner","innocent","input","inquiry","insane","insect","inside","inspire","install","intact","interest","into","invest","invite","involve","iron","island","isolate","issue","item","ivory","jacket","jaguar","jar","jazz","jealous","jeans","jelly","jewel","job","join","joke","journey","joy","judge","juice","jump","jungle","junior","junk","just","kangaroo","keen","keep","ketchup","key","kick","kid","kidney","kind","kingdom","kiss","kit","kitchen","kite","kitten","kiwi","knee","knife","knock","know","lab","label","labor","ladder","lady","lake","lamp","language","laptop","large","later","latin","laugh","laundry","lava","law","lawn","lawsuit","layer","lazy","leader","leaf","learn","leave","lecture","left","leg","legal","legend","leisure","lemon","lend","length","lens","leopard","lesson","letter","level","liar","liberty","library","license","life","lift","light","like","limb","limit","link","lion","liquid","list","little","live","lizard","load","loan","lobster","local","lock","logic","lonely","long","loop","lottery","loud","lounge","love","loyal","lucky","luggage","lumber","lunar","lunch","luxury","lyrics","machine","mad","magic","magnet","maid","mail","main","major","make","mammal","man","manage","mandate","mango","mansion","manual","maple","marble","march","margin","marine","market","marriage","mask","mass","master","match","material","math","matrix","matter","maximum","maze","meadow","mean","measure","meat","mechanic","medal","media","melody","melt","member","memory","mention","menu","mercy","merge","merit","merry","mesh","message","metal","method","middle","midnight","milk","million","mimic","mind","minimum","minor","minute","miracle","mirror","misery","miss","mistake","mix","mixed","mixture","mobile","model","modify","mom","moment","monitor","monkey","monster","month","moon","moral","more","morning","mosquito","mother","motion","motor","mountain","mouse","move","movie","much","muffin","mule","multiply","muscle","museum","mushroom","music","must","mutual","myself","mystery","myth","naive","name","napkin","narrow","nasty","nation","nature","near","neck","need","negative","neglect","neither","nephew","nerve","nest","net","network","neutral","never","news","next","nice","night","noble","noise","nominee","noodle","normal","north","nose","notable","note","nothing","notice","novel","now","nuclear","number","nurse","nut","oak","obey","object","oblige","obscure","observe","obtain","obvious","occur","ocean","october","odor","off","offer","office","often","oil","okay","old","olive","olympic","omit","once","one","onion","online","only","open","opera","opinion","oppose","option","orange","orbit","orchard","order","ordinary","organ","orient","original","orphan","ostrich","other","outdoor","outer","output","outside","oval","oven","over","own","owner","oxygen","oyster","ozone","pact","paddle","page","pair","palace","palm","panda","panel","panic","panther","paper","parade","parent","park","parrot","party","pass","patch","path","patient","patrol","pattern","pause","pave","payment","peace","peanut","pear","peasant","pelican","pen","penalty","pencil","people","pepper","perfect","permit","person","pet","phone","photo","phrase","physical","piano","picnic","picture","piece","pig","pigeon","pill","pilot","pink","pioneer","pipe","pistol","pitch","pizza","place","planet","plastic","plate","play","please","pledge","pluck","plug","plunge","poem","poet","point","polar","pole","police","pond","pony","pool","popular","portion","position","possible","post","potato","pottery","poverty","powder","power","practice","praise","predict","prefer","prepare","present","pretty","prevent","price","pride","primary","print","priority","prison","private","prize","problem","process","produce","profit","program","project","promote","proof","property","prosper","protect","proud","provide","public","pudding","pull","pulp","pulse","pumpkin","punch","pupil","puppy","purchase","purity","purpose","purse","push","put","puzzle","pyramid","quality","quantum","quarter","question","quick","quit","quiz","quote","rabbit","raccoon","race","rack","radar","radio","rail","rain","raise","rally","ramp","ranch","random","range","rapid","rare","rate","rather","raven","raw","razor","ready","real","reason","rebel","rebuild","recall","receive","recipe","record","recycle","reduce","reflect","reform","refuse","region","regret","regular","reject","relax","release","relief","rely","remain","remember","remind","remove","render","renew","rent","reopen","repair","repeat","replace","report","require","rescue","resemble","resist","resource","response","result","retire","retreat","return","reunion","reveal","review","reward","rhythm","rib","ribbon","rice","rich","ride","ridge","rifle","right","rigid","ring","riot","ripple","risk","ritual","rival","river","road","roast","robot","robust","rocket","romance","roof","rookie","room","rose","rotate","rough","round","route","royal","rubber","rude","rug","rule","run","runway","rural","sad","saddle","sadness","safe","sail","salad","salmon","salon","salt","salute","same","sample","sand","satisfy","satoshi","sauce","sausage","save","say","scale","scan","scare","scatter","scene","scheme","school","science","scissors","scorpion","scout","scrap","screen","script","scrub","sea","search","season","seat","second","secret","section","security","seed","seek","segment","select","sell","seminar","senior","sense","sentence","series","service","session","settle","setup","seven","shadow","shaft","shallow","share","shed","shell","sheriff","shield","shift","shine","ship","shiver","shock","shoe","shoot","shop","short","shoulder","shove","shrimp","shrug","shuffle","shy","sibling","sick","side","siege","sight","sign","silent","silk","silly","silver","similar","simple","since","sing","siren","sister","situate","six","size","skate","sketch","ski","skill","skin","skirt","skull","slab","slam","sleep","slender","slice","slide","slight","slim","slogan","slot","slow","slush","small","smart","smile","smoke","smooth","snack","snake","snap","sniff","snow","soap","soccer","social","sock","soda","soft","solar","soldier","solid","solution","solve","someone","song","soon","sorry","sort","soul","sound","soup","source","south","space","spare","spatial","spawn","speak","special","speed","spell","spend","sphere","spice","spider","spike","spin","spirit","split","spoil","sponsor","spoon","sport","spot","spray","spread","spring","spy","square","squeeze","squirrel","stable","stadium","staff","stage","stairs","stamp","stand","start","state","stay","steak","steel","stem","step","stereo","stick","still","sting","stock","stomach","stone","stool","story","stove","strategy","street","strike","strong","struggle","student","stuff","stumble","style","subject","submit","subway","success","such","sudden","suffer","sugar","suggest","suit","summer","sun","sunny","sunset","super","supply","supreme","sure","surface","surge","surprise","surround","survey","suspect","sustain","swallow","swamp","swap","swarm","swear","sweet","swift","swim","swing","switch","sword","symbol","symptom","syrup","system","table","tackle","tag","tail","talent","talk","tank","tape","target","task","taste","tattoo","taxi","teach","team","tell","ten","tenant","tennis","tent","term","test","text","thank","that","theme","then","theory","there","they","thing","this","thought","three","thrive","throw","thumb","thunder","ticket","tide","tiger","tilt","timber","time","tiny","tip","tired","tissue","title","toast","tobacco","today","toddler","toe","together","toilet","token","tomato","tomorrow","tone","tongue","tonight","tool","tooth","top","topic","topple","torch","tornado","tortoise","toss","total","tourist","toward","tower","town","toy","track","trade","traffic","tragic","train","transfer","trap","trash","travel","tray","treat","tree","trend","trial","tribe","trick","trigger","trim","trip","trophy","trouble","truck","true","truly","trumpet","trust","truth","try","tube","tuition","tumble","tuna","tunnel","turkey","turn","turtle","twelve","twenty","twice","twin","twist","two","type","typical","ugly","umbrella","unable","unaware","uncle","uncover","under","undo","unfair","unfold","unhappy","uniform","unique","unit","universe","unknown","unlock","until","unusual","unveil","update","upgrade","uphold","upon","upper","upset","urban","urge","usage","use","used","useful","useless","usual","utility","vacant","vacuum","vague","valid","valley","valve","van","vanish","vapor","various","vast","vault","vehicle","velvet","vendor","venture","venue","verb","verify","version","very","vessel","veteran","viable","vibrant","vicious","victory","video","view","village","vintage","violin","virtual","virus","visa","visit","visual","vital","vivid","vocal","voice","void","volcano","volume","vote","voyage","wage","wagon","wait","walk","wall","walnut","want","warfare","warm","warrior","wash","wasp","waste","water","wave","way","wealth","weapon","wear","weasel","weather","web","wedding","weekend","weird","welcome","west","wet","whale","what","wheat","wheel","when","where","whip","whisper","wide","width","wife","wild","will","win","window","wine","wing","wink","winner","winter","wire","wisdom","wise","wish","witness","wolf","woman","wonder","wood","wool","word","work","world","worry","worth","wrap","wreck","wrestle","wrist","write","wrong","yard","year","yellow","you","young","youth","zebra","zero","zone","zoo"];



// ===================== src/multisig.mjs =====================
// ============================================================================
//  multisig.mjs — 2-of-3 мультисиг для UTXO-блокчейнов
//  BIP-39 (мнемоника) + BIP-32 (HD-ключи) + BIP-48 (пути мультисига)
//  + BIP-67 (сортировка ключей) + P2WSH / P2SH-P2WSH / P2SH / CashAddr
//  Никаких внешних зависимостей — только ./core.mjs
// ============================================================================



const HARDENED = 0x80000000;

/* ========================================================================
 *  Сети (UTXO). Все параметры — в одном месте, легко добавить новую монету.
 *  coinType — SLIP-44, keyNet — версии расширенных ключей (xpub/ypub/zpub и т.п.)
 * ====================================================================== */
const NETWORKS = [
  {
    id: 'bitcoin', name: 'Bitcoin', symbol: 'BTC', coinType: 0, popular: true,
    hrp: 'bc', p2pkhVer: 0x00, p2shVer: 0x05, wif: 0x80,
    keyNet: { xpub: 0x0488b21e, ypub: 0x049d7cb2, zpub: 0x04b24746, xprv: 0x0488ade4, yprv: 0x049d7878, zprv: 0x04b2430c },
    explorers: ['mempool.space', 'blockstream.info', 'blockchair.com'],
  },
  {
    id: 'bitcoin-testnet', name: 'Bitcoin Testnet3', symbol: 'tBTC', coinType: 1, testnet: true,
    hrp: 'tb', p2pkhVer: 0x6f, p2shVer: 0xc4, wif: 0xef,
    keyNet: { xpub: 0x043587cf, ypub: 0x044a5262, zpub: 0x045f1cf6, xprv: 0x04358394, yprv: 0x044a4e28, zprv: 0x045f18bc },
    explorers: ['mempool.space/testnet', 'blockstream.info/testnet'],
    faucets: ['https://mempool.space/testnet/faucet', 'https://coinfaucet.eu/en/btc-testnet/'],
  },
  {
    id: 'bitcoin-testnet4', name: 'Bitcoin Testnet4', symbol: 'tBTC4', coinType: 1, testnet: true,
    hrp: 'tb', p2pkhVer: 0x6f, p2shVer: 0xc4, wif: 0xef,
    keyNet: { xpub: 0x043587cf, ypub: 0x044a5262, zpub: 0x045f1cf6, xprv: 0x04358394, yprv: 0x044a4e28, zprv: 0x045f18bc },
    explorers: ['mempool.space/testnet4'],
    faucets: ['https://testnet.help/ru/btcfaucet/testnet4', 'https://mempool.space/testnet4/faucet'],
  },
  {
    id: 'signet', name: 'Bitcoin Signet', symbol: 'sBTC', coinType: 1, testnet: true,
    hrp: 'tb', p2pkhVer: 0x6f, p2shVer: 0xc4, wif: 0xef,
    keyNet: { xpub: 0x043587cf, ypub: 0x044a5262, zpub: 0x045f1cf6, xprv: 0x04358394, yprv: 0x044a4e28, zprv: 0x045f18bc },
    explorers: ['mempool.space/signet'],
    faucets: ['https://signetfaucet.com', 'https://mempool.space/signet/faucet'],
  },
  {
    id: 'litecoin', name: 'Litecoin', symbol: 'LTC', coinType: 2, popular: true,
    hrp: 'ltc', p2pkhVer: 0x30, p2shVer: 0x32, wif: 0xb0,
    keyNet: { xpub: 0x0488b21e, xprv: 0x0488ade4, ypub: 0x01b26ef6, yprv: 0x01b26792, zpub: 0x04b24746, zprv: 0x04b2430c },
    explorers: ['litecoinspace.org', 'blockchair.com/litecoin', 'blockcypher.com'],
  },
  {
    id: 'dogecoin', name: 'Dogecoin', symbol: 'DOGE', coinType: 3, popular: true,
    hrp: 'doge', p2pkhVer: 0x1e, p2shVer: 0x16, wif: 0x9e,
    keyNet: { xpub: 0x02facafd, xprv: 0x02fac398, ypub: 0x02facafd, yprv: 0x02fac398, zpub: 0x02facafd, zprv: 0x02fac398 },
    keyNote: 'Dogecoin не имеет отдельных ypub/zpub — везде dgub/dgpv',
    explorers: ['blockchair.com/dogecoin', 'blockcypher.com'],
  },
  {
    id: 'dash', name: 'Dash', symbol: 'DASH', coinType: 5, popular: true,
    hrp: 'dash', p2pkhVer: 0x4c, p2shVer: 0x10, wif: 0xcc,
    keyNet: { xpub: 0x0488b21e, xprv: 0x0488ade4, ypub: 0x0488b21e, yprv: 0x0488ade4, zpub: 0x0488b21e, zprv: 0x0488ade4 },
    keyNote: 'Dash использует стандартные xpub',
    explorers: ['blockchair.com/dash', 'blockcypher.com'],
  },
  {
    id: 'bitcoin-cash', name: 'Bitcoin Cash', symbol: 'BCH', coinType: 145, cashaddr: 'bitcoincash', popular: true,
    hrp: 'bc', p2pkhVer: 0x00, p2shVer: 0x05, wif: 0x80,
    keyNet: { xpub: 0x0488b21e, xprv: 0x0488ade4, ypub: 0x0488b21e, yprv: 0x0488ade4, zpub: 0x0488b21e, zprv: 0x0488ade4 },
    keyNote: 'BCH: адреса в формате CashAddr, ключи — стандартные xpub',
    explorers: ['blockchair.com/bitcoin-cash'],
  },
  {
    id: 'ecash', name: 'eCash', symbol: 'XEC', coinType: 899, cashaddr: 'ecash',
    hrp: 'bc', p2pkhVer: 0x00, p2shVer: 0x05, wif: 0x80,
    keyNet: { xpub: 0x0488b21e, xprv: 0x0488ade4, ypub: 0x0488b21e, yprv: 0x0488ade4, zpub: 0x0488b21e, zprv: 0x0488ade4 },
    keyNote: 'eCash: адреса в формате CashAddr (префикс ecash)',
    explorers: ['blockchair.com/ecash'],
  },
  {
    id: 'zcash', name: 'Zcash (прозрачные адреса)', symbol: 'ZEC', coinType: 133,
    hrp: 'zc', zcash: 'main',
    // у Zcash ДВУХбайтовые префиксы адресов: mainnet 0x1CB8/0x1CBD, testnet 0x1D25/0x1CBA
    p2pkhVer: [0x1c, 0xb8], p2shVer: [0x1c, 0xbd], wif: 0x80,
    keyNet: { xpub: 0x0488b21e, xprv: 0x0488ade4, ypub: 0x0488b21e, yprv: 0x0488ade4, zpub: 0x0488b21e, zprv: 0x0488ade4 },
    keyNote: 'Zcash: только прозрачные (transparent) адреса; щитовые (z-addr) не поддерживаются',
    explorers: ['blockchair.com/zcash'],
  },
  {
    id: 'zcash-testnet', name: 'Zcash Testnet', symbol: 'tZEC', coinType: 1, testnet: true,
    hrp: 'zt', zcash: 'test',
    p2pkhVer: [0x1d, 0x25], p2shVer: [0x1c, 0xba], wif: 0xef,
    keyNet: { xpub: 0x043587cf, xprv: 0x04358394, ypub: 0x043587cf, yprv: 0x04358394, zpub: 0x043587cf, zprv: 0x04358394 },
    keyNote: 'Zcash testnet: только прозрачные адреса',
    explorers: [],
  },
];

const getNetwork = (id) => {
  const n = NETWORKS.find((x) => x.id === id);
  if (!n) throw new Error('Неизвестная сеть: ' + id);
  return n;
};

/** Типы скриптов мультисига, которые поддерживаются */
const SCRIPT_TYPES = [
  { id: 'p2wsh', name: 'P2WSH (native segwit)', bip48: 2, kind: 'segwit', ext: 'zpub', note: 'современный стандарт, самая низкая комиссия' },
  { id: 'p2sh-p2wsh', name: 'P2SH-P2WSH (nested segwit)', bip48: 1, kind: 'segwit-nested', ext: 'ypub', note: 'совместим со старыми сервисами' },
  { id: 'p2sh', name: 'P2SH (legacy)', bip48: 1, kind: 'legacy', ext: 'xpub', note: 'для монет без segwit: DOGE, DASH, BCH' },
];

const getScriptType = (id) => {
  const t = SCRIPT_TYPES.find((x) => x.id === id);
  if (!t) throw new Error('Неизвестный тип скрипта: ' + id);
  return t;
};

/** Какие типы скриптов поддерживает сеть (у BCH/eCash/doge/dash/zcash segwit нет) */
function scriptTypesFor(template) {
  if (template.cashaddr || template.zcash) return ['p2sh'];
  if (template.id === 'dogecoin' || template.id === 'dash') return ['p2sh'];
  return ['p2wsh', 'p2sh-p2wsh', 'p2sh'];
}

/**
 * Префикс версии адреса -> байты.
 * У большинства монет он однобайтовый (0x05), но у Zcash — двухбайтовый (0x1CBD).
 */
const verBytes = (v) => (Array.isArray(v) ? v : [v]);

/* ========================================================================
 *  BIP-39: мнемоника
 * ====================================================================== */
function generateMnemonic(strength = 256) {
  if (strength % 32 !== 0 || strength < 128 || strength > 256) throw new Error('strength: 128..256, кратно 32');
  const entropy = new Uint8Array(strength / 8);
  if (typeof globalThis.crypto?.getRandomValues === 'function') globalThis.crypto.getRandomValues(entropy);
  else throw new Error('Нет источника случайности (crypto.getRandomValues)');
  return entropyToMnemonic(entropy);
}
function entropyToMnemonic(entropy) {
  const entBits = entropy.length * 8;
  const csBits = entBits / 32;
  const hash = sha256(entropy);
  let bits = '';
  for (const b of entropy) bits += b.toString(2).padStart(8, '0');
  for (let i = 0; i < csBits; i++) bits += ((hash[i >> 3] >> (7 - (i & 7))) & 1).toString();
  const words = [];
  for (let i = 0; i < bits.length; i += 11) words.push(WORDLIST[parseInt(bits.slice(i, i + 11), 2)]);
  return words.join(' ');
}
function mnemonicToEntropy(mnemonic) {
  const words = normalizeMnemonic(mnemonic).split(' ');
  const entBits = (words.length * 11 * 32) / 33;
  const csBits = entBits / 32;
  let bits = '';
  for (const w of words) {
    const idx = WORDLIST.indexOf(w);
    if (idx < 0) throw new Error('Слова нет в BIP-39 словаре: ' + w);
    bits += idx.toString(2).padStart(11, '0');
  }
  const entropy = new Uint8Array(entBits / 8);
  for (let i = 0; i < entropy.length; i++) entropy[i] = parseInt(bits.slice(i * 8, i * 8 + 8), 2);
  const expect = sha256(entropy);
  for (let i = 0; i < csBits; i++) {
    const bit = (expect[i >> 3] >> (7 - (i & 7))) & 1;
    if (bit !== Number(bits[entBits + i])) throw new Error('Неверная контрольная сумма мнемоники');
  }
  return entropy;
}
function normalizeMnemonic(m) {
  return String(m).normalize('NFKD').trim().toLowerCase().replace(/\s+/g, ' ');
}
function validateMnemonic(m) {
  try {
    const words = normalizeMnemonic(m).split(' ');
    if (![12, 15, 18, 21, 24].includes(words.length)) return false;
    mnemonicToEntropy(m);
    return true;
  } catch { return false; }
}
/** seed = PBKDF2-HMAC-SHA512(mnemonic, "mnemonic"+passphrase, 2048) */
function mnemonicToSeed(mnemonic, passphrase = '') {
  const mn = normalizeMnemonic(mnemonic);
  const salt = utf8ToBytes('mnemonic' + String(passphrase).normalize('NFKD'));
  return pbkdf2Sha512(utf8ToBytes(mn), salt, 2048, 64);
}

/* ========================================================================
 *  BIP-32: HD-ключи (своя реализация, без зависимостей)
 * ====================================================================== */
function ser32(n) {
  const b = new Uint8Array(4);
  new DataView(b.buffer).setUint32(0, n >>> 0, false);
  return b;
}
function fingerprintOf(pub33) { return hash160(pub33).slice(0, 4); }

class HDKey {
  constructor({ privateKey = null, publicKey = null, chainCode, depth = 0, index = 0, parentFingerprint = new Uint8Array(4), keyNet }) {
    this.privateKey = privateKey;
    this.publicKey = publicKey;
    this.chainCode = chainCode;
    this.depth = depth;
    this.index = index;
    this.parentFingerprint = parentFingerprint;
    this.keyNet = keyNet || { xprv: 0x0488ade4, xpub: 0x0488b21e };
  }
  static fromMasterSeed(seed, keyNet) {
    const I = hmacSha512(utf8ToBytes('Bitcoin seed'), seed);
    const il = I.slice(0, 32), ir = I.slice(32, 64);
    const k = bytesToBigint(il);
    if (k === 0n || k >= CURVE.N) throw new Error('BIP-32: неверный мастер-ключ');
    return new HDKey({ privateKey: il, publicKey: serializePubkey(pointMultiply(k, CURVE.G)), chainCode: ir, depth: 0, index: 0, keyNet });
  }
  get isPrivate() { return !!this.privateKey; }
  /** Публичная версия ключа */
  toPublic() {
    return new HDKey({
      publicKey: this.publicKey, chainCode: this.chainCode, depth: this.depth,
      index: this.index, parentFingerprint: this.parentFingerprint,
      keyNet: this.keyNet,
    });
  }
  /** Дочерний приватный ключ (или публичный, если приватного нет и индекс non-hardened) */
  deriveChild(index) {
    const hardened = (index & HARDENED) !== 0;
    if (!this.isPrivate) {
      if (hardened) throw new Error('deriveChild: hardened-индекс требует приватного ключа');
      return this.deriveChildPublic(index);
    }
    const data = hardened
      ? concatBytes(new Uint8Array([0]), this.privateKey, ser32(index))
      : concatBytes(this.publicKey, ser32(index));
    const I = hmacSha512(this.chainCode, data);
    const il = bytesToBigint(I.slice(0, 32));
    if (il >= CURVE.N) throw new Error('BIP-32: IL >= n, попробуйте другой индекс');
    const child = (il + bytesToBigint(this.privateKey)) % CURVE.N;
    if (child === 0n) throw new Error('BIP-32: нулевой дочерний ключ');
    return new HDKey({
      privateKey: bigintToBytes32(child),
      publicKey: serializePubkey(pointMultiply(child, CURVE.G)),
      chainCode: I.slice(32, 64),
      depth: this.depth + 1,
      index,
      parentFingerprint: fingerprintOf(this.publicKey),
      keyNet: this.keyNet,
    });
  }
  /** Дочерний публичный ключ (только non-hardened) */
  deriveChildPublic(index) {
    if (index & HARDENED) throw new Error('deriveChildPublic: hardened-индекс невозможен без приватного ключа');
    const I = hmacSha512(this.chainCode, concatBytes(this.publicKey, ser32(index)));
    const il = bytesToBigint(I.slice(0, 32));
    if (il >= CURVE.N) throw new Error('BIP-32: IL >= n');
    const parent = parsePubkey(this.publicKey);
    const child = pointAdd(pointMultiply(il, CURVE.G), parent);
    if (!child) throw new Error('BIP-32: дочерний ключ = бесконечность');
    return new HDKey({
      publicKey: serializePubkey(child),
      chainCode: I.slice(32, 64),
      depth: this.depth + 1,
      index,
      parentFingerprint: fingerprintOf(this.publicKey),
      keyNet: this.keyNet,
    });
  }
  /** Производный путь "m/48'/0'/0'/2'" */
  derive(path) {
    const parts = String(path).split('/');
    if (parts[0] !== 'm') throw new Error('Путь должен начинаться с "m"');
    let node = this;
    for (const p of parts.slice(1)) {
      if (p === '') continue;
      const hard = p.endsWith("'") || p.endsWith('h') || p.endsWith('H');
      const n = parseInt(hard ? p.slice(0, -1) : p, 10);
      if (!Number.isInteger(n) || n < 0 || n >= HARDENED) throw new Error('Неверный элемент пути: ' + p);
      node = node.deriveChild(hard ? n + HARDENED : n);
    }
    return node;
  }
  /** Сериализация в xprv/ypub/... */
  toExtendedKey(format = 'xprv') {
    const versions = this.keyNet || {};
    const want = format.startsWith('x') ? (format === 'xprv' ? versions.xprv ?? 0x0488ade4 : versions.xpub ?? 0x0488b21e)
      : format === 'yprv' ? versions.yprv ?? 0x049d7878 : format === 'ypub' ? versions.ypub ?? 0x049d7cb2
      : format === 'zprv' ? versions.zprv ?? 0x04b2430c : format === 'zpub' ? versions.zpub ?? 0x04b24746
      : (() => { throw new Error('Неизвестный формат ключа: ' + format); })();
    const isPriv = format.endsWith('prv');
    const keyData = isPriv
      ? concatBytes(new Uint8Array([0]), this.privateKey)
      : this.publicKey;
    if (isPriv && !this.isPrivate) throw new Error('Нет приватного ключа');
    const payload = concatBytes(
      ser32(want),
      new Uint8Array([this.depth & 0xff]),
      this.parentFingerprint,
      ser32(this.index),
      this.chainCode,
      keyData,
    );
    return base58checkEncode(payload);
  }
  static fromExtendedKey(str) {
    const raw = base58checkDecode(str);
    if (raw.length !== 78) throw new Error('Некорректная длина расширенного ключа');
    const view = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
    const version = view.getUint32(0, false);
    const depth = raw[4];
    const parentFingerprint = raw.slice(5, 9);
    const index = view.getUint32(9, false);
    const chainCode = raw.slice(13, 45);
    const keyData = raw.slice(45, 78);
    const KNOWN = {
      0x0488b21e: 'xpub', 0x0488ade4: 'xprv', 0x049d7cb2: 'ypub', 0x049d7878: 'yprv',
      0x04b24746: 'zpub', 0x04b2430c: 'zprv', 0x043587cf: 'xpub', 0x04358394: 'xprv',
      0x044a5262: 'ypub', 0x044a4e28: 'yprv', 0x045f1cf6: 'zpub', 0x045f18bc: 'zprv',
      0x02facafd: 'xpub', 0x02fac398: 'xprv', 0x01b26ef6: 'ypub', 0x01b26792: 'yprv',
    };
    const kind = KNOWN[version];
    if (!kind) throw new Error('Неизвестная версия расширенного ключа: 0x' + version.toString(16));
    let privateKey = null, publicKey = null;
    if (keyData[0] === 0) {
      privateKey = keyData.slice(1);
      const k = bytesToBigint(privateKey);
      if (k === 0n || k >= CURVE.N) throw new Error('Некорректный приватный ключ');
      publicKey = serializePubkey(pointMultiply(k, CURVE.G));
    } else {
      publicKey = keyData;
      parsePubkey(publicKey); // проверка, что точка валидна
    }
    return new HDKey({ privateKey, publicKey, chainCode, depth, index, parentFingerprint, keyNet: { xpub: version, xprv: version } });
  }
  /** WIF для приватного ключа */
  toWIF(prefix = 0x80) {
    if (!this.isPrivate) throw new Error('Нет приватного ключа');
    return base58checkEncode(concatBytes(new Uint8Array([prefix]), this.privateKey, new Uint8Array([0x01])));
  }
}

/* ========================================================================
 *  BIP-48: путь мультисига  m/48'/coin'/account'/scriptType'
 * ====================================================================== */
function bip48Path(network, scriptTypeId, account = 0) {
  const net = typeof network === 'string' ? getNetwork(network) : network;
  const st = getScriptType(scriptTypeId);
  return `m/48'/${net.coinType}'/${account}'/${st.bip48}'`;
}

/**
 * Кэш seed по мнемонике. PBKDF2 (2048 итераций) — самая дорогая операция
 * во всей программе, а seed зависит только от мнемоники и passphrase, но НЕ
 * от сети. Без кэша он считался бы заново для каждой сети и каждого типа
 * скрипта (в 16 раз больше работы, чем нужно).
 */
const _seedCache = new Map();
function cachedMnemonicToSeed(mnemonic, passphrase = '') {
  const key = normalizeMnemonic(mnemonic) + '\u0000' + String(passphrase).normalize('NFKD');
  let s = _seedCache.get(key);
  if (!s) {
    s = mnemonicToSeed(mnemonic, passphrase);
    if (_seedCache.size > 32) _seedCache.clear();
    _seedCache.set(key, s);
  }
  return s;
}
function clearSeedCache() { _seedCache.clear(); }

/** Из сида -> аккаунтный ключ BIP-48 */
function deriveAccountKey({ seed, mnemonic, passphrase = '', network = 'bitcoin', scriptType = 'p2wsh', account = 0 }) {
  const net = typeof network === 'string' ? getNetwork(network) : network;
  const s = seed || cachedMnemonicToSeed(mnemonic, passphrase);
  const root = HDKey.fromMasterSeed(s, net.keyNet);
  const path = bip48Path(net, scriptType, account);
  const node = root.derive(path);
  return { node, path, root, network: net, scriptType };
}

/**
 * Предрасчёт аккаунтных ключей: для каждой ветки BIP-48 (1' и 2') считается
 * ровно один раз на косайнера, а не на каждую сеть — путь зависит только от
 * coinType и ветки, а seed вообще от сети не зависит.
 * Возвращает Map: ключ "coinType|branch|cosignerIndex" -> HDKey.
 */
function precomputeAccounts(cosigners, { account = 0 } = {}) {
  const nodes = new Map();
  for (const c of cosigners) {
    const seed = cachedMnemonicToSeed(c.mnemonic, c.passphrase || '');
    for (const branch of [1, 2]) {
      for (const coinType of [...new Set(NETWORKS.map((n) => n.coinType))]) {
        nodes.set(`${coinType}|${branch}|${c.index}`,
          HDKey.fromMasterSeed(seed).derive(`m/48'/${coinType}'/${account}'/${branch}'`));
      }
    }
  }
  return nodes;
}

/* ========================================================================
 *  BIP-67: лексикографическая сортировка публичных ключей
 * ====================================================================== */
const sortPubkeysBip67 = (pubkeys) =>
  [...pubkeys].map((p) => (typeof p === 'string' ? hexToBytes(p) : p))
    .sort((a, b) => { for (let i = 0; i < 33; i++) if (a[i] !== b[i]) return a[i] - b[i]; return 0; });

/** Проверка, что ключи уже отсортированы (нужно для дескрипторов sortedmulti) */
const isSortedBip67 = (pubkeys) => {
  const hexes = pubkeys.map((p) => (typeof p === 'string' ? p.toLowerCase() : bytesToHex(p)));
  const sorted = [...hexes].sort();
  return hexes.every((h, i) => h === sorted[i]);
};

/* ========================================================================
 *  Скрипт мультисига и адреса
 * ====================================================================== */
const OP_CHECKMULTISIG = 0xae;

/** witness/script: OP_m <push key1><push key2><push key3> OP_n OP_CHECKMULTISIG (ключи по BIP-67)
 *  ВАЖНО: каждый публичный ключ в скрипте — это data-push, поэтому перед 33 байтами
 *  идёт байт длины 0x21. Без него скрипт неисполним (так делает и Bitcoin Core, и bitcoinjs-lib). */
function buildMultisigScript(threshold, pubkeys) {
  if (threshold < 1 || threshold > 15) throw new Error('threshold: 1..15');
  if (pubkeys.length < 1 || pubkeys.length > 16) throw new Error('количество ключей: 1..16');
  if (threshold > pubkeys.length) throw new Error('threshold больше числа ключей');
  const sorted = typeof pubkeys[0] === 'string' ? pubkeys.map(hexToBytes) : pubkeys;
  for (const p of sorted) {
    if (p.length !== 33) throw new Error('нужны сжатые публичные ключи (33 байта), получено ' + p.length);
    if (p[0] !== 2 && p[0] !== 3) throw new Error('неверный префикс публичного ключа: 0x' + p[0].toString(16));
  }
  const pushes = sorted.map((p) => concatBytes(new Uint8Array([p.length]), p));
  return concatBytes(
    new Uint8Array([0x50 + threshold]),
    ...pushes,
    new Uint8Array([0x50 + sorted.length, OP_CHECKMULTISIG]),
  );
}

/** Адрес мультисига + все хеши */
function multisigAddress(template, threshold, pubkeys, scriptTypeId) {
  const net = typeof template === 'string' ? getNetwork(template) : template;
  const st = getScriptType(scriptTypeId);
  const script = buildMultisigScript(threshold, pubkeys);
  if (st.kind === 'segwit') return { address: segwitEncode(net.hrp, 0, sha256(script)), script, hash: sha256(script), kind: 'p2wsh' };
  if (st.kind === 'segwit-nested') {
    const redeem = concatBytes(new Uint8Array([0x00, 0x20]), sha256(script));
    return { address: base58checkEncode(concatBytes(new Uint8Array([net.p2shVer]), hash160(redeem))), script, redeemScript: redeem, hash: hash160(redeem), kind: 'p2sh-p2wsh' };
  }
  const h = hash160(script);
  if (net.cashaddr) return { address: cashaddrEncode(net.cashaddr, 1, h), script, hash: h, kind: 'p2sh', cashaddrType: 1 };
  return { address: base58checkEncode(concatBytes(new Uint8Array(verBytes(net.p2shVer)), h)), script, hash: h, kind: 'p2sh' };
}

/** P2PKH-адрес отдельного косайнера (куда ему удобно докидывать свою долю) */
function p2pkhAddress(template, pub33) {
  const net = typeof template === 'string' ? getNetwork(template) : template;
  const h = hash160(typeof pub33 === 'string' ? hexToBytes(pub33) : pub33);
  if (net.cashaddr) return cashaddrEncode(net.cashaddr, 0, h);
  return base58checkEncode(concatBytes(new Uint8Array(verBytes(net.p2pkhVer)), h));
}

/* ========================================================================
 *  Дескриптор (output descriptor) с контрольной суммой
 * ====================================================================== */
const DESC_CHARSET = '0123456789()[],\'/*abcdefgh@:$%{}IJKLMNOPQRSTUVWXYZ&+-.;<=>?!^_|~ijklmnopqrstuvwxyzABCDEFGH`#"\\ ';
const DESC_INPUT_CHARSET = "0123456789()[],'/*abcdefgh@:$%{}IJKLMNOPQRSTUVWXYZ&+-.;<=>?!^_|~ijklmnopqrstuvwxyzABCDEFGH`#\"\\ ";
const DESC_CHECKSUM_CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';

function descPolyMod(c, val) {
  const c0 = c >> 35;
  c = ((c & 0x7ffffffff) << 5) ^ val;
  if (c0 & 1) c ^= 0xf5dee51989;
  if (c0 & 2) c ^= 0xa9fdca3312;
  if (c0 & 4) c ^= 0x1bab10e32d;
  if (c0 & 8) c ^= 0x3706b1677a;
  if (c0 & 16) c ^= 0x644d626ffd;
  return c >>> 0;
}
function descriptorChecksum(desc) {
  // c — 37-битная величина, поэтому считаем в BigInt (в JS << / >>> работают только с 32 битами)
  let c = 1n, cls = 0n, clscount = 0;
  const poly = (c0, val) => {
    const top = c0 >> 35n;
    let x = ((c0 & 0x7ffffffffn) << 5n) ^ BigInt(val);
    if (top & 1n) x ^= 0xf5dee51989n;
    if (top & 2n) x ^= 0xa9fdca3312n;
    if (top & 4n) x ^= 0x1bab10e32dn;
    if (top & 8n) x ^= 0x3706b1677an;
    if (top & 16n) x ^= 0x644d626ffdn;
    return x; // Core здесь НЕ маскирует значение
  };
  for (const ch of desc) {
    const pos = DESC_INPUT_CHARSET.indexOf(ch);
    if (pos === -1) return null;
    c = poly(c, pos & 31);
    cls = cls * 3n + BigInt(pos >> 5);
    if (++clscount === 3) { c = poly(c, Number(cls)); cls = 0n; clscount = 0; }
  }
  if (clscount > 0) c = poly(c, Number(cls));
  for (let j = 0; j < 8; j++) c = poly(c, 0);
  c ^= 1n;
  // 8 групп по 5 бит, старшая — первая (никакого маскирования: Core работает в uint64)
  let out = '';
  for (let j = 0; j < 8; j++) out += DESC_CHECKSUM_CHARSET[Number((c >> BigInt(5 * (7 - j))) & 31n)];
  return out;
}
function addDescriptorChecksum(desc) {
  const cs = descriptorChecksum(desc);
  return cs ? `${desc}#${cs}` : desc;
}

/* ========================================================================
 *  Сборка всего кошелька: 3 косайнера -> 2-of-3 в каждой выбранной сети
 * ====================================================================== */
/**
 * @param {object} opts
 * @param {Array}  opts.cosigners  [{ label, mnemonic, passphrase }] — обычно 3 штуки
 * @param {string[]} opts.networkIds
 * @param {number} opts.threshold  по умолчанию 2
 * @param {function} [opts.onProgress]  (шаг, всего, имяСети) — для индикатора в UI
 */
function createMultisigWallet({ cosigners, networkIds, threshold = 2, account = 0, onProgress = null, networkOverride = null, extraNetworks = [] }) {
  if (!Array.isArray(cosigners) || cosigners.length < 2) throw new Error('Нужно минимум 2 косайнера');
  if (threshold < 1 || threshold > cosigners.length) throw new Error('Порог должен быть от 1 до числа косайнеров');
  if (threshold !== 2 || cosigners.length !== 3) {
    // не запрещаем, но эта сборка оптимизирована под 2-из-3
  }
  // Позволяем подмешать свою сеть (например regtest для интеграционных тестов)
  // или полностью заменить список. На работу с обычными сетями не влияет.
  const catalog = networkOverride
    ? [networkOverride, ...NETWORKS]
    : extraNetworks.length ? [...extraNetworks, ...NETWORKS] : NETWORKS;
  const getNet = (id) => {
    const n = catalog.find((x) => x.id === id);
    if (!n) throw new Error('Неизвестная сеть: ' + id);
    return n;
  };
  const ids = networkIds && networkIds.length ? networkIds : catalog.map((n) => n.id);
  const wallets = [];
  let step = 1;
  // seed (PBKDF2, самая дорогая операция) считается один раз на косайнера
  const seeds = cosigners.map((c) => cachedMnemonicToSeed(c.mnemonic, c.passphrase || ''));
  // аккаунтные ключи зависят только от (coinType, ветка BIP-48, аккаунт) — кэшируем и их
  const acctCache = new Map();
  const acctKey = (coinType, branch, i) => {
    const key = `${coinType}|${branch}|${i}`;
    let n = acctCache.get(key);
    if (!n) {
      n = HDKey.fromMasterSeed(seeds[i]).derive(`m/48'/${coinType}'/${account}'/${branch}'`);
      acctCache.set(key, n);
    }
    return n;
  };
  for (const id of ids) {
    const net = getNet(id);
    if (onProgress) onProgress(step++, ids.length, net.name);
    const types = scriptTypesFor(net);
    for (const stId of types) {
      const st = getScriptType(stId);
      const cos = cosigners.map((c, i) => {
        const node = acctKey(net.coinType, st.bip48, i);
        const path = `m/48'/${net.coinType}'/${account}'/${st.bip48}'`;
        return {
          index: i + 1,
          label: c.label || `Косайнер ${i + 1}`,
          path,
          fingerprint: bytesToHex(hash160(node.publicKey).slice(0, 4)),
          accountXpub: node.toExtendedKey(st.ext === 'xpub' ? 'xpub' : st.ext),
          accountXpubRaw: node.toExtendedKey('xpub'),
          accountXprv: node.toExtendedKey(st.ext === 'xpub' ? 'xprv' : st.ext.replace('pub', 'prv')),
          derivedPubkey: bytesToHex(node.publicKey),
          xpubNode: node.toPublic(),
          wif: node.toWIF(net.wif),
        };
      });
      const cosignerPubs = cos.map((c) => c.derivedPubkey);          // hex-строки (33 байта)
      const sortedPub = sortPubkeysBip67(cosignerPubs);               // Uint8Array[] по BIP-67
      const sortedHex = sortedPub.map((p) => bytesToHex(p));
      const sortedOk = isSortedBip67(cosignerPubs);

      // --- АККУНАТНЫЙ уровень: адрес из аккаунтных ключей (без цепочки/индекса).
      // Это валидный, но нестандартный адрес; показываем его отдельно для справки.
      const acctLevel = multisigAddress(net, threshold, sortedPub, stId);

      // --- СТАНДАРТНЫЙ путь: первый адрес приёма BIP-48 = <аккаунт>/0/0
      const receivePubs = cos.map((c) => bytesToHex(c.xpubNode.deriveChild(0).deriveChild(0).publicKey));
      const firstRecv = multisigAddress(net, threshold, sortPubkeysBip67(receivePubs), stId);

      // Дескриптор конкретного адреса: multi() требует порядок BIP-67,
      // sortedmulti() сортирует сам -> можно оставить исходный порядок
      const keyExprs = sortedOk ? sortedHex : cosignerPubs;
      const multiFn = sortedOk ? 'multi' : 'sortedmulti';
      const bare = `${multiFn}(${threshold},${keyExprs.join(',')})`;
      const descBody = st.kind === 'segwit' ? `wsh(${bare})`
        : st.kind === 'segwit-nested' ? `sh(wsh(${bare}))`
        : `sh(${bare})`;
      const descriptor = addDescriptorChecksum(descBody);
      const cosignerP2pkh = cos.map((c) => p2pkhAddress(net, c.derivedPubkey));
      wallets.push({
        networkId: net.id, networkName: net.name, symbol: net.symbol, testnet: !!net.testnet,
        scriptType: stId, scriptTypeName: st.name, kind: firstRecv.kind,
        threshold, of: cosigners.length,
        // основной адрес — первый адрес приёма по BIP-48
        address: firstRecv.address,
        scriptHex: bytesToHex(firstRecv.script), scriptHash: bytesToHex(firstRecv.hash),
        redeemScriptHex: firstRecv.redeemScript ? bytesToHex(firstRecv.redeemScript) : null,
        receivePubkeys: receivePubs,
        addressPath: `${bip48Path(net, stId, account)}/0/0`,
        // справочно: адрес из аккаунтных ключей (без /0/0)
        accountLevelAddress: acctLevel.address,
        accountLevelScriptHex: bytesToHex(acctLevel.script),
        accountLevelScriptHash: bytesToHex(acctLevel.hash),
        accountLevelDescriptor: addDescriptorChecksum(st.kind === 'segwit' ? `wsh(${multiFn}(${threshold},${keyExprs.join(',')}))`
          : st.kind === 'segwit-nested' ? `sh(wsh(${multiFn}(${threshold},${keyExprs.join(',')})))`
          : `sh(${multiFn}(${threshold},${keyExprs.join(',')}))`),
        descriptor, descriptorBody: descBody,
        bip48Path: bip48Path(net, stId, account),
        accountIndex: account,
        cosigners: cos.map((c, i) => ({
          index: c.index, label: c.label, path: c.path, fingerprint: c.fingerprint,
          xpub: c.accountXpub, xpubRaw: c.accountXpubRaw, xprv: c.accountXprv,
          multisigPubkey: c.derivedPubkey, p2pkh: cosignerP2pkh[i], wif: c.wif,
          hasPriv: true,
        })),
        sortedPubkeys: sortedPub,
        sorted: sortedOk,
        explorers: net.explorers || [],
        faucets: net.faucets || [],
      });
    }
  }
  return {
    createdAt: new Date().toISOString(),
    scheme: { threshold, total: cosigners.length, bip48: true, bip67: true },
    account,
    cosigners: cosigners.map((c, i) => ({ index: i + 1, label: c.label || `Косайнер ${i + 1}`, hasMnemonic: !!c.mnemonic })),
    wallets,
  };
}

/* ========================================================================
 *  Деривация адресов приёма/сдачи из аккаунтного xpub (для кошелька)
 * ====================================================================== */
/**
 * @param {object} wallet   запись из createMultisigWallet
 * @param {number} chain    0 = приём, 1 = сдача
 * @param {number} count    сколько адресов
 * @param {object} xpubNodes массив узлов HDKey (account-level, public) по косайнерам
 */
function deriveAddresses(wallet, xpubNodes, { chain = 0, from = 0, count = 5 } = {}) {
  const net = getNetwork(wallet.networkId);
  const out = [];
  for (let i = from; i < from + count; i++) {
    const pubs = xpubNodes.map((node) => bytesToHex(node.deriveChild(chain).deriveChild(i).publicKey));
    const { address, script, hash, kind } = multisigAddress(net, wallet.threshold, sortPubkeysBip67(pubs), wallet.scriptType);
    out.push({ index: i, chain, path: `${wallet.bip48Path}/${chain}/${i}`, address, scriptHex: bytesToHex(script), scriptHash: bytesToHex(hash), kind, pubkeys: pubs });
  }
  return out;
}

/** Аккаунтные ПУБЛИЧНЫЕ узлы из записанных xpub (для деривации без приватных ключей) */
function xpubNodesFromWallet(wallet) {
  return wallet.cosigners.map((c) => HDKey.fromExtendedKey(c.xpubRaw || c.xpub));
}

/* ========================================================================
 *  Экспорт/импорт
 * ====================================================================== */
function toDescriptorExport(wallet) {
  return {
    descriptor: wallet.descriptor,
    accountDescriptor: accountDescriptor(wallet),
    network: wallet.networkId,
    scriptType: wallet.scriptType,
    threshold: `${wallet.threshold}-of-${wallet.of}`,
    address: wallet.address,
    bip48Path: wallet.bip48Path,
    xpubs: wallet.cosigners.map((c, i) => ({ cosigner: i + 1, xpub: c.xpub, xpubRaw: c.xpubRaw, fingerprint: c.fingerprint })),
  };
}

/**
 * «Аккаунтный» дескриптор с wildcard — именно его импортируют Sparrow / BlueWallet / Electrum / Specter.
 * Использует аккаунтные xpub из BIP-48 и путь /0/* (внешняя цепочка).
 */
function accountDescriptor(wallet, chain = 0) {
  const net = getNetwork(wallet.networkId);
  const st = getScriptType(wallet.scriptType);
  const coin = net.coinType, acc = wallet.accountIndex, branch = st.bip48;
  const keys = wallet.cosigners.map((c) => `[${c.fingerprint}/48'/${coin}'/${acc}'/${branch}']${c.xpubRaw}/${chain}/*`);
  const bare = `sortedmulti(${wallet.threshold},${keys.join(',')})`;
  const body = st.kind === 'segwit' ? `wsh(${bare})`
    : st.kind === 'segwit-nested' ? `sh(wsh(${bare}))`
    : `sh(${bare})`;
  return addDescriptorChecksum(body);
}

function toColdcardMultisigFile(wallet, name = 'multisig-2of3') {
  const net = getNetwork(wallet.networkId);
  const st = getScriptType(wallet.scriptType);
  const policy = {
    name,
    addressType: wallet.scriptType === 'p2wsh' ? 'P2WSH' : wallet.scriptType === 'p2sh-p2wsh' ? 'P2SH-P2WSH' : 'P2SH',
    threshold: wallet.threshold,
    xpubs: wallet.cosigners.map((c) =>
      `[${c.fingerprint}/48'/${net.coinType}'/${wallet.accountIndex}'/${st.bip48}']${c.xpubRaw}/0/*`),
  };
  return JSON.stringify(policy, null, 2);
}



// ===================== src/explorers.mjs =====================
// ============================================================================
//  explorers.mjs — проверка адресов в публичных блокчейн-обозревателях
//  Работает в браузере (fetch + CORS) и в Node.js 18+.
// ============================================================================



/** адреса API для каждой сети (проверены на доступность и CORS) */
const EXPLORER_API = {
  bitcoin: { esplora: 'https://mempool.space/api', extra: 'https://blockstream.info/api', web: 'https://mempool.space' },
  'bitcoin-testnet': { esplora: 'https://mempool.space/testnet/api', extra: 'https://blockstream.info/testnet/api', web: 'https://mempool.space/testnet' },
  'bitcoin-testnet4': { esplora: 'https://mempool.space/testnet4/api', web: 'https://mempool.space/testnet4' },
  signet: { esplora: 'https://mempool.space/signet/api', web: 'https://mempool.space/signet' },
  litecoin: { esplora: 'https://litecoinspace.org/api', web: 'https://litecoinspace.org' },
  dogecoin: { blockcypher: 'https://api.blockcypher.com/v1/doge/main', web: 'https://blockchair.com/dogecoin' },
  dash: { blockcypher: 'https://api.blockcypher.com/v1/dash/main', web: 'https://blockchair.com/dash' },
  'bitcoin-cash': { blockchair: 'https://api.blockchair.com/bitcoin-cash', web: 'https://blockchair.com/bitcoin-cash' },
  ecash: { blockchair: 'https://api.blockchair.com/ecash', web: 'https://blockchair.com/ecash' },
  zcash: { blockchair: 'https://api.blockchair.com/zcash', web: 'https://blockchair.com/zcash' },
  'zcash-testnet': { web: null },
};

function explorerUrls(wallet) {
  const api = EXPLORER_API[wallet.networkId] || {};
  const addr = wallet.address;
  const web = api.web || '';
  return {
    address: web ? `${web}/address/${encodeURIComponent(addr)}` : null,
    testnetFaucet: wallet.networkId === 'bitcoin-testnet' ? 'https://mempool.space/testnet/faucet'
      : wallet.networkId === 'signet' ? 'https://mempool.space/signet/faucet' : null,
  };
}

async function getJson(url, timeoutMs = 20000) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    const res = await fetch(url, { signal: ctrl ? ctrl.signal : undefined, headers: { accept: 'application/json' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally { if (timer) clearTimeout(timer); }
}
async function getText(url, timeoutMs = 20000) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    const res = await fetch(url, { signal: ctrl ? ctrl.signal : undefined });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally { if (timer) clearTimeout(timer); }
}

/* -------------------------------------------------------------------------
 *  Локальный разбор адреса -> хеш скрипта (не требует сети)
 * ---------------------------------------------------------------------- */
function scriptHashFromAddress(networkId, address) {
  const net = getNetwork(networkId);
  if (address.toLowerCase().startsWith(net.hrp + '1')) {
    const d = segwitDecode(net.hrp, address);
    return { type: d.version === 0 ? 'wsh' : 'witness-v' + d.version, scriptHash: bytesToHex(d.program), program: d.program };
  }
  if (net.cashaddr && address.toLowerCase().startsWith(net.cashaddr + ':')) {
    const d = cashaddrDecode(address);
    return { type: d.typeBits === 1 ? 'p2sh' : 'p2pkh', scriptHash: bytesToHex(d.hash), program: d.hash };
  }
  const p = base58checkDecode(address);
  // префикс версии может быть двухбайтовым (Zcash: 0x1CB8 / 0x1CBD)
  const vb = (v) => (Array.isArray(v) ? v : [v]);
  const startsWith = (ver) => vb(ver).every((byte, i) => p[i] === byte);
  const verLen = vb(net.p2shVer).length;
  return {
    type: startsWith(net.p2shVer) ? 'p2sh' : startsWith(net.p2pkhVer) ? 'p2pkh'
      : 'unknown(' + bytesToHex(p.slice(0, verLen)) + ')',
    scriptHash: bytesToHex(p.slice(verLen)), program: p.slice(verLen),
  };
}

/* -------------------------------------------------------------------------
 *  Проверка формата адреса: пересобираем скрипт из pubkey и сверяем хеш
 * ---------------------------------------------------------------------- */
function verifyAddressLocally(wallet) {
  const net = getNetwork(wallet.networkId);
  const pubs = sortPubkeysBip67(wallet.receivePubkeys || wallet.sortedPubkeys.map(bytesToHex));
  const script = buildMultisigScript(wallet.threshold, pubs);
  const parsed = scriptHashFromAddress(wallet.networkId, wallet.address);
  let expected, expectedKind;
  if (wallet.scriptType === 'p2wsh') { expected = bytesToHex(sha256(script)); expectedKind = 'wsh'; }
  else if (wallet.scriptType === 'p2sh-p2wsh') {
    expected = bytesToHex(hash160(Uint8Array.from([0x00, 0x20, ...sha256(script)])));
    expectedKind = 'p2sh';
  } else { expected = bytesToHex(hash160(script)); expectedKind = 'p2sh'; }
  return {
    ok: parsed.scriptHash === expected && parsed.type === expectedKind,
    address: wallet.address,
    network: wallet.networkId,
    addressType: parsed.type,
    scriptHashFromAddress: parsed.scriptHash,
    scriptHashFromOwnKeys: expected,
    witnessScript: bytesToHex(script),
    scriptSize: script.length,
    note: wallet.scriptType === 'p2sh-p2wsh'
      ? 'P2SH-P2WSH: адрес хеширует redeem-скрипт (0x0020||sha256(witness))'
      : wallet.scriptType === 'p2wsh' ? 'P2WSH: адрес = bech32(sha256(witness script))'
      : 'P2SH: адрес = base58check(hash160(script))',
  };
}

/* -------------------------------------------------------------------------
 *  Опрос обозревателя
 * ---------------------------------------------------------------------- */
const satToBtc = (s) => (Number(s) / 1e8).toFixed(8);

async function esploraAddress(base, address) {
  const [info, utxos] = await Promise.all([
    getJson(`${base}/address/${address}`),
    getJson(`${base}/address/${address}/utxo`),
  ]);
  const chain = info.chain_stats || {}, mem = info.mempool_stats || {};
  const funded = (chain.funded_txo_sum || 0) + (mem.funded_txo_sum || 0);
  const spent = (chain.spent_txo_sum || 0) + (mem.spent_txo_sum || 0);
  return {
    known: true,
    txCount: (chain.txo_count || 0) + (mem.txo_count || 0),
    received: funded, spent, balance: funded - spent,
    utxoCount: (utxos || []).length,
    utxos: (utxos || []).map((u) => ({ txid: u.txid, vout: u.vout, value: u.value })),
    source: base,
  };
}

async function blockcypherAddress(base, address) {
  const j = await getJson(`${base}/addrs/${address}/full?limit=50`);
  const received = j.total_received || 0, sent = j.total_sent || 0;
  const utxos = (j.txrefs || []).filter((t) => !t.spent).map((t) => ({ txid: t.tx_hash, vout: t.tx_output_n, value: t.value }));
  return {
    known: j.total_received !== undefined || j.n_tx !== undefined,
    txCount: j.n_tx || 0, received, spent: sent, balance: j.balance !== undefined ? j.balance : received - sent,
    utxoCount: utxos.length, utxos, source: base, addressRaw: j.address,
  };
}

async function blockchairAddress(base, address) {
  // blockchair для BCH/XEC: дашборд по адресу
  const net = base.includes('ecash') ? 'ecash' : 'bitcoin-cash';
  const j = await getJson(`${base}/dashboards/address/${encodeURIComponent(address)}?limit=10`);
  const d = j.data && j.data[address] ? j.data[address] : (j.data ? Object.values(j.data)[0] : null);
  if (!d) return { known: false, source: base, raw: j };
  const a = d.address || {};
  return {
    known: true,
    txCount: a.transaction_count || 0,
    received: a.received || 0, spent: a.spent || 0, balance: (a.received || 0) - (a.spent || 0),
    utxoCount: a.unspent_output_count || 0,
    utxos: [], source: base, scriptHexExplorer: (d.utxo || [])[0]?.script_hex || null,
  };
}

/** Главная функция: узнать, что обозреватель знает про адрес */
async function checkAddressOnChain(wallet) {
  const api = EXPLORER_API[wallet.networkId];
  if (!api) return { supported: false, reason: 'нет обозревателя для этой сети' };
  const addr = wallet.address;
  const attempts = [];
  const tries = [];
  if (api.esplora) tries.push(['esplora', () => esploraAddress(api.esplora, addr)]);
  if (api.extra) tries.push(['esplora2', () => esploraAddress(api.extra, addr)]);
  if (api.blockcypher) tries.push(['blockcypher', () => blockcypherAddress(api.blockcypher, addr)]);
  if (api.blockchair) tries.push(['blockchair', () => blockchairAddress(api.blockchair, addr)]);
  for (const [name, fn] of tries) {
    try {
      const r = await fn();
      return { supported: true, ...r, provider: name, explorerWeb: explorerUrls(wallet).address };
    } catch (e) { attempts.push(`${name}: ${e.message}`); }
  }
  return { supported: true, known: null, error: attempts.join(' | '), explorerWeb: explorerUrls(wallet).address };
}

/* -------------------------------------------------------------------------
 *  Проверка транзакции: реально ли она платит на наш адрес и нашим скриптом
 * ---------------------------------------------------------------------- */
async function checkTxPaysAddress(wallet, txid) {
  const api = EXPLORER_API[wallet.networkId];
  if (!api?.esplora) return { supported: false, reason: 'для этой сети нет esplora-обозревателя' };
  const bases = [api.esplora, api.extra].filter(Boolean);
  let lastErr = null;
  for (const base of bases) {
    try {
      const tx = await getJson(`${base}/tx/${txid}`);
      const want = scriptHashFromAddress(wallet.networkId, wallet.address);
      const expectedWitness = bytesToHex(buildMultisigScript(wallet.threshold,
        sortPubkeysBip67(wallet.receivePubkeys || wallet.sortedPubkeys.map(bytesToHex))));
      const outputs = (tx.vout || []).map((o) => {
        const spk = o.scriptpubkey || '';
        // P2WSH: 0x0020 || sha256  |  P2SH: 0xa914 || hash160  |  P2PKH: 0x76a914
        let hash = null, type = 'other';
        if (spk.startsWith('0020')) { hash = spk.slice(4, 68); type = 'wsh'; }
        else if (spk.startsWith('a914')) { hash = spk.slice(4, 44); type = 'p2sh'; }
        else if (spk.startsWith('76a914')) { hash = spk.slice(6, 46); type = 'p2pkh'; }
        return {
          n: o.vout !== undefined ? o.vout : o.n, value: o.value, scriptpubkey: spk, type, hash,
          address: o.scriptpubkey_address || null,
          matchesUs: hash === want.scriptHash || o.scriptpubkey_address === wallet.address,
        };
      });
      const paid = outputs.filter((o) => o.matchesUs);
      // если транзакция тратит наш P2WSH — можно достать сам witness script из входа
      let witnessScriptFromSpend = null;
      if (tx.vin && tx.vin.length) {
        for (const vin of tx.vin) {
          if (!vin.witness || !vin.witness.length) continue;
          const cand = vin.witness[vin.witness.length - 1];
          if (cand && cand.length > 20) {
            const b = hexToBytes(cand);
            if (bytesToHex(sha256(b)) === want.scriptHash) witnessScriptFromSpend = cand;
          }
        }
      }
      return {
        supported: true, provider: base, txid, confirmed: !!tx.status?.confirmed,
        blockHeight: tx.status?.block_height || null, fee: tx.fee,
        outputs, paidToUs: paid.length > 0, paidAmount: paid.reduce((s, o) => s + (o.value || 0), 0),
        witnessScriptExpected: expectedWitness,
        witnessScriptFromSpend,
        witnessScriptMatches: witnessScriptFromSpend ? witnessScriptFromSpend === expectedWitness : null,
      };
    } catch (e) { lastErr = e; }
  }
  return { supported: true, error: String(lastErr && lastErr.message) };
}

/** Текущая высота блока (для отчёта «сеть жива») */
async function tipHeight(networkId) {
  const api = EXPLORER_API[networkId];
  try {
    if (api?.esplora) return Number((await getText(`${api.esplora}/blocks/tip/height`)).trim());
    if (api?.blockcypher) return (await getJson(api.blockcypher)).height ?? null;
    if (api?.blockchair) {
      const net = api.blockchair.includes('ecash') ? 'ecash' : 'bitcoin-cash';
      const j = await getJson(`https://api.blockchair.com/${net}/stats`);
      return j?.data?.blocks ?? null;
    }
  } catch { return null; }
  return null;
}

/** Тестовые монеты: куда идти за ними (у публичных кранов есть captcha, поэтому вручную) */
function faucetInfo(wallet) {
  if (wallet.networkId === 'bitcoin-testnet') return {
    available: true, url: 'https://mempool.space/testnet/faucet',
    alternatives: ['https://coinfaucet.eu/en/btc-testnet/', 'https://bitcoinfaucet.uo1.net/'],
  };
  if (wallet.networkId === 'signet') return { available: true, url: 'https://mempool.space/signet/faucet', alternatives: ['https://signetfaucet.com'] };
  return { available: false };
}


return {
  enc: enc,
  dec: dec,
  concatBytes: concatBytes,
  bytesToHex: bytesToHex,
  hexToBytes: hexToBytes,
  utf8ToBytes: utf8ToBytes,
  wipe: wipe,
  K256: K256,
  sha256: sha256,
  sha256d: sha256d,
  K512: K512,
  MASK64: MASK64,
  rotr64: rotr64,
  ROUND_SHIFTS: ROUND_SHIFTS,
  _w512: _w512,
  sha512: sha512,
  RL: RL,
  RR: RR,
  SL: SL,
  SR: SR,
  KL: KL,
  KR: KR,
  rol32: rol32,
  ripemd160: ripemd160,
  hash160: hash160,
  hmac: hmac,
  hmacSha256: hmacSha256,
  hmacSha512: hmacSha512,
  pbkdf2Sha512: pbkdf2Sha512,
  P: P,
  N: N,
  Gx: Gx,
  Gy: Gy,
  mod: mod,
  powMod: powMod,
  invMod: invMod,
  INF: INF,
  jDouble: jDouble,
  jAddAffine: jAddAffine,
  jToAffine: jToAffine,
  G_TABLE: G_TABLE,
  pointMultiplyG: pointMultiplyG,
  pointMultiply: pointMultiply,
  pointAdd: pointAdd,
  G: G,
  pointPow: pointPow,
  isOnCurve: isOnCurve,
  bigintToBytes32: bigintToBytes32,
  bytesToBigint: bytesToBigint,
  serializePubkey: serializePubkey,
  parsePubkey: parsePubkey,
  CURVE: CURVE,
  B58: B58,
  base58Encode: base58Encode,
  base58Decode: base58Decode,
  base58checkEncode: base58checkEncode,
  base58checkDecode: base58checkDecode,
  CHARSET: CHARSET,
  BECH32_CONST: BECH32_CONST,
  BECH32M_CONST: BECH32M_CONST,
  bech32Polymod: bech32Polymod,
  bech32HrpExpand: bech32HrpExpand,
  convertBits: convertBits,
  bech32Encode: bech32Encode,
  bech32Decode: bech32Decode,
  segwitEncode: segwitEncode,
  segwitDecode: segwitDecode,
  cashaddrEncode: cashaddrEncode,
  cashaddrDecode: cashaddrDecode,
  WORDLIST: WORDLIST,
  HARDENED: HARDENED,
  NETWORKS: NETWORKS,
  getNetwork: getNetwork,
  SCRIPT_TYPES: SCRIPT_TYPES,
  getScriptType: getScriptType,
  scriptTypesFor: scriptTypesFor,
  verBytes: verBytes,
  generateMnemonic: generateMnemonic,
  entropyToMnemonic: entropyToMnemonic,
  mnemonicToEntropy: mnemonicToEntropy,
  normalizeMnemonic: normalizeMnemonic,
  validateMnemonic: validateMnemonic,
  mnemonicToSeed: mnemonicToSeed,
  ser32: ser32,
  fingerprintOf: fingerprintOf,
  HDKey: HDKey,
  bip48Path: bip48Path,
  _seedCache: _seedCache,
  cachedMnemonicToSeed: cachedMnemonicToSeed,
  clearSeedCache: clearSeedCache,
  deriveAccountKey: deriveAccountKey,
  precomputeAccounts: precomputeAccounts,
  sortPubkeysBip67: sortPubkeysBip67,
  isSortedBip67: isSortedBip67,
  OP_CHECKMULTISIG: OP_CHECKMULTISIG,
  buildMultisigScript: buildMultisigScript,
  multisigAddress: multisigAddress,
  p2pkhAddress: p2pkhAddress,
  DESC_CHARSET: DESC_CHARSET,
  DESC_INPUT_CHARSET: DESC_INPUT_CHARSET,
  DESC_CHECKSUM_CHARSET: DESC_CHECKSUM_CHARSET,
  descPolyMod: descPolyMod,
  descriptorChecksum: descriptorChecksum,
  addDescriptorChecksum: addDescriptorChecksum,
  createMultisigWallet: createMultisigWallet,
  deriveAddresses: deriveAddresses,
  xpubNodesFromWallet: xpubNodesFromWallet,
  toDescriptorExport: toDescriptorExport,
  accountDescriptor: accountDescriptor,
  toColdcardMultisigFile: toColdcardMultisigFile,
  EXPLORER_API: EXPLORER_API,
  explorerUrls: explorerUrls,
  getJson: getJson,
  getText: getText,
  scriptHashFromAddress: scriptHashFromAddress,
  verifyAddressLocally: verifyAddressLocally,
  satToBtc: satToBtc,
  esploraAddress: esploraAddress,
  blockcypherAddress: blockcypherAddress,
  blockchairAddress: blockchairAddress,
  checkAddressOnChain: checkAddressOnChain,
  checkTxPaysAddress: checkTxPaysAddress,
  tipHeight: tipHeight,
  faucetInfo: faucetInfo
};
})();

/* ---------------------------------------------------- публичный API UTXO --- */
/* ============================================================================
 *  UTXO API — то, чем пользуется интерфейс и ИИ-агент.
 *
 *  Все функции синхронные, кроме тех, что ходят в сеть:
 *    UTXO.balance / UTXO.balances / UTXO.utxos — читают блокчейн
 *    UTXO.send с { send: true }               — отправляет транзакцию
 *
 *  При ошибке бросается Error с русским текстом — его можно показывать
 *  пользователю как есть.
 * ==========================================================================*/
const UTXO = (function () {
  const VERSION = '1.0';
  const SCRIPT_LABEL = { p2wsh: 'P2WSH', 'p2sh-p2wsh': 'P2SH-P2WSH', p2sh: 'P2SH' };

  const API = {
    bitcoin: 'https://mempool.space/api',
    'bitcoin-testnet': 'https://mempool.space/testnet/api',
    'bitcoin-testnet4': 'https://mempool.space/testnet4/api',
    signet: 'https://mempool.space/signet/api',
    litecoin: 'https://litecoinspace.org/api',
  };
  const WEB = {
    bitcoin: 'https://mempool.space', 'bitcoin-testnet': 'https://mempool.space/testnet',
    'bitcoin-testnet4': 'https://mempool.space/testnet4', signet: 'https://mempool.space/signet',
    litecoin: 'https://litecoinspace.org', dogecoin: 'https://blockchair.com/dogecoin',
    dash: 'https://blockchair.com/dash', 'bitcoin-cash': 'https://blockchair.com/bitcoin-cash',
    ecash: 'https://blockchair.com/ecash', zcash: 'https://blockchair.com/zcash',
  };
  const DEFAULT_NETS = ['bitcoin', 'litecoin', 'dogecoin', 'dash', 'bitcoin-cash', 'ecash', 'zcash'];

  let DEFAULT_ADDRESS_COUNT = 5;   // сколько адресов приёма считать по умолчанию

  const json = async (url, opts) => {
    const r = await fetch(url, opts);
    if (!r.ok) throw new Error(`Сеть ответила ${r.status} (${url})`);
    const t = await r.text();
    try { return JSON.parse(t); } catch { return t; }
  };
  const hx = (u8) => bytesToHex(u8);
  const isSegwitOnly = (id) => !['bitcoin', 'bitcoin-testnet', 'bitcoin-testnet4', 'signet', 'litecoin'].includes(id);

  /* ======================================================== создание кошелька */
  /**
   * Создать 2-из-3 кошелёк.
   * @param {object} [o]
   *   mnemonic   — одна своя мнемоника: из неё детерминированно выводятся 3 косайнера
   *   mnemonics  — три своих мнемоники (используются как есть)
   *   networks   — список сетей, по умолчанию 7 основных
   *   threshold  — порог, по умолчанию 2
   *   account    — индекс аккаунта BIP-48, по умолчанию 0
   *   addresses  — сколько адресов приёма посчитать сразу (0 = ни одного)
   * @returns {object} кошелёк
   */
  function createWallet(o) {
    o = o || {};
    const threshold = o.threshold || 2;
    const account = o.account || 0;
    const wantAddrs = o.addresses === undefined ? 0 : o.addresses;   // подробности считаем лениво
    const requested = (o.networks && o.networks.length ? o.networks : DEFAULT_NETS);
    const nets = requested.filter((id) => NETWORKS.some((n) => n.id === id));
    if (!nets.length) throw new Error('Не выбрано ни одной поддерживаемой сети');

    const cosigners = buildCosigners(o);
    const w = createMultisigWallet({ cosigners, networkIds: nets, threshold, account });

    const wallet = {
      id: 'utxo-' + hx(sha256(new TextEncoder().encode(cosigners.map((c) => c.mnemonic).join('|')))).slice(0, 12),
      version: VERSION,
      createdAt: new Date().toISOString(),
      threshold, total: cosigners.length, account, networks: nets,
      /** ВНИМАНИЕ: секрет. Не отправляйте на сервер и не храните в облаке. */
      mnemonics: cosigners.map((c) => c.mnemonic),
      entries: [],
      byId: Object.create(null),
      /** кэш исходных записей — для деривации адресов и подписи */
      raw: w.wallets,
    };

    for (const e of w.wallets) {
      const item = {
        id: `${e.networkId}:${e.scriptType}`,
        networkId: e.networkId, network: e.networkName, symbol: e.symbol, testnet: !!e.testnet,
        scriptType: e.scriptType, scriptTypeLabel: SCRIPT_LABEL[e.scriptType],
        threshold, total: e.of,
        address: e.address, path: e.addressPath,
        explorer: WEB[e.networkId] ? `${WEB[e.networkId]}/address/${e.address}` : null,
        ready: false,
      };
      Object.defineProperty(item, '_e', { value: e, enumerable: false });
      wallet.entries.push(item);
      wallet.byId[item.id] = item;
    }
    // подробности (ключи, WIF, дескриптор) считаем сразу только для первой сети,
    // иначе на слабом телефоне кнопка «создать» будет думать несколько секунд
    if (wallet.entries[0]) detail(wallet, wallet.entries[0].id, wantAddrs);
    return wallet;
  }

  /** 3 косайнера: свои, из одной мнемоники или новые */
  function buildCosigners(o) {
    if (Array.isArray(o.mnemonics) && o.mnemonics.length >= 2) {
      return o.mnemonics.slice(0, 3).map((m, i) => ({ label: `Косайнер ${String.fromCharCode(65 + i)}`, mnemonic: String(m).trim() }));
    }
    if (o.mnemonic) {
      const base = mnemonicToSeed(String(o.mnemonic).trim());
      const tag = new TextEncoder().encode('clandai-utxo-cosigner');
      return [0, 1, 2].map((i) => {
        const out = new Uint8Array(32);
        for (let k = 0; k < 32; k++) out[k] = base[k] ^ tag[k % tag.length] ^ ((i + 1) * 31);
        return { label: `Косайнер ${String.fromCharCode(65 + i)}`, mnemonic: entropyToMnemonic(out) };
      });
    }
    return [0, 1, 2].map((i) => ({ label: `Косайнер ${String.fromCharCode(65 + i)}`, mnemonic: generateMnemonic(256) }));
  }

  /* ============================================================= подробности */
  /**
   * Досчитать и вернуть полные данные записи: witness script, дескриптор,
   * все три ключа (приватные и публичные), личные адреса косайнеров.
   * @param {object} wallet
   * @param {string} entryId  например 'bitcoin:p2wsh'
   * @param {number} [addrCount] сколько адресов приёма посчитать
   */
  function detail(wallet, entryId, addrCount) {
    const item = wallet.byId[entryId];
    if (!item) throw new Error('Нет такой записи: ' + entryId + '. Доступны: ' + Object.keys(wallet.byId).join(', '));
    if (item.ready && addrCount === undefined) return item;
    const e = item._e;
    item.witnessScript = e.scriptHex;
    item.scriptHash = e.scriptHash;
    item.redeemScript = e.redeemScriptHex || null;
    item.accountPath = e.bip48Path;
    // ВАЖНО: below — адрес ПРИЁМА (первый адрес пути /0/0).
    // Ключи в item.cosigners — аккаунтного уровня, поэтому из них собирается
    // аккаунтный адрес (accountAddress). Это разные, но оба правильные адреса
    // одного кошелька; сверка verifyAddress сравнивает одноимённое.
    item.addressPath = e.addressPath;
    item.accountAddress = e.accountLevelAddress;
    item.accountScriptHex = e.accountLevelScriptHex;
    item.accountScriptHash = e.accountLevelScriptHash;
    item.descriptor = accountDescriptor(e);
    item.descriptorThisAddress = e.accountLevelDescriptor;
    item.bip67Sorted = e.sorted;
    item.cosigners = e.cosigners.map((c) => ({
      index: c.index,
      label: c.label,
      fingerprint: c.fingerprint,      // 4 байта, чтобы узнавать ключ на других устройствах
      path: c.path,                    // m/48'/coin'/account'/branch'
      publicKey: c.multisigPubkey,     // 33 байта — этот ключ входит в мультисиг
      xpub: c.xpub,                    // для импорта в кошелёк наблюдения
      address: c.p2pkh,                // личный адрес косайнера (докинуть свою долю)
      // СЕКРЕТЫ:
      xprv: c.xprv,                    // приватный ключ уровня аккаунта
      wif: c.wif,                      // приватный ключ в формате WIF
    }));
    const n = addrCount === undefined ? DEFAULT_ADDRESS_COUNT : addrCount;
    item.addresses = n > 0 ? receiveAddresses(e, n) : [];
    item.ready = true;
    return item;
  }

  /** адреса приёма одной записи (цепочка 0) */
  function receiveAddresses(e, count) {
    return deriveAddresses(e, xpubNodesFromWallet(e), { chain: 0, from: 0, count })
      .map((a) => ({ index: a.index, path: a.path, address: a.address }));
  }

  /** Список адресов приёма (по сети или по всем) */
  function addresses(wallet, networkId, count) {
    const n = count || DEFAULT_ADDRESS_COUNT;
    return wallet.entries
      .filter((it) => !networkId || it.networkId === networkId)
      .map((it) => {
        detail(wallet, it.id, 0);
        return {
          id: it.id, network: it.network, symbol: it.symbol, scriptType: it.scriptType,
          address: it.address, addresses: receiveAddresses(it._e, n),
        };
      });
  }

  /* ================================================================ проверка */
  /**
   * Сверить сохранённые данные с тем, что получается из публичных ключей.
   * Ключи в cosigners — аккаунтного уровня (m/48'/coin'/account'/branch'),
   * поэтому из них собирается аккаунтный адрес и witness script.
   * Порядок косайнеров не важен: ключи сортируются по BIP-67.
   */
  function verifyAddress(entry) {
    const net = getNetwork(entry.networkId);
    const pubs = sortPubkeysBip67(entry.cosigners.map((c) => c.publicKey));
    const script = buildMultisigScript(entry.threshold, pubs);
    const a = multisigAddress(net, entry.threshold, pubs, entry.scriptType);
    return {
      ok: a.address === entry.accountAddress && hx(script) === entry.accountScriptHex,
      addressRebuilt: a.address, addressStored: entry.accountAddress,
      scriptRebuilt: hx(script), scriptStored: entry.accountScriptHex,
      note: 'сверяется аккаунтный адрес; адрес приёма — это первый адрес пути /0/0',
    };
  }

  /* =============================================================== блокчейн */
  const apiFor = (networkId) => API[networkId] || null;

  async function balance(entry) {
    const base = apiFor(entry.networkId);
    if (!base) return { supported: false, reason: 'для этой сети нет обозревателя', balance: 0, symbol: entry.symbol };
    const info = await json(`${base}/address/${entry.address}`);
    const ch = info.chain_stats || {}, mp = info.mempool_stats || {};
    const funded = (ch.funded_txo_sum || 0) + (mp.funded_txo_sum || 0);
    const spent = (ch.spent_txo_sum || 0) + (mp.spent_txo_sum || 0);
    return {
      supported: true, symbol: entry.symbol,
      balance: funded - spent, received: funded, spent,
      txCount: (ch.txo_count || 0) + (mp.txo_count || 0),
      pending: (mp.funded_txo_sum || 0) > 0 || (mp.spent_txo_sum || 0) > 0,
      explorer: entry.explorer,
    };
  }

  /** Балансы по всем записям (параллельно). Суммы в разных монетах не складываются. */
  async function balances(wallet) {
    const res = await Promise.all(wallet.entries.map(async (e) => {
      try { return Object.assign({ id: e.id, network: e.network }, await balance(e)); }
      catch (err) { return { id: e.id, network: e.network, symbol: e.symbol, supported: true, error: err.message, balance: 0 }; }
    }));
    return res;
  }

  async function utxos(entry) {
    const base = apiFor(entry.networkId);
    if (!base) throw new Error('Для этой сети нет обозревателя');
    const list = await json(`${base}/address/${entry.address}/utxo`);
    return list.map((u) => ({ txid: u.txid, vout: u.vout, value: u.value, height: u.status && u.status.block_height }));
  }

  /* ================================================================ отправка */
  /**
   * Подписать (и при желании отправить) трату 2 подписями из 3.
   * @param {object} o
   *   wallet    — результат createWallet
   *   entryId   — например 'bitcoin:p2wsh'
   *   to        — адрес получателя
   *   amount    — сумма в sat; если не указать — всё минус комиссия
   *   fee       — комиссия в sat, по умолчанию 1000
   *   cosigners — номера подписывающих ключей, по умолчанию [1,2]
   *   send      — true: сразу отправить в сеть
   */
  async function send(o) {
    const entry = o.wallet.byId[o.entryId];
    if (!entry) throw new Error('Нет такой записи: ' + o.entryId);
    detail(o.wallet, o.entryId, 0);
    const base = apiFor(entry.networkId);
    if (!base) throw new Error('Для этой сети отправка не поддерживается');
    const list = await utxos(entry);
    if (!list.length) throw new Error('На адресе нет монет — сначала пополните его');
    const total = list.reduce((s, u) => s + BigInt(u.value), 0n);
    const fee = BigInt(o.fee === undefined ? 1000 : o.fee);
    const amount = o.amount === undefined ? total - fee : BigInt(o.amount);
    if (amount <= 0n || amount + fee > total) {
      throw new Error(`Недостаточно средств: есть ${total} sat, нужно ${amount + fee} sat`);
    }
    const net = getNetwork(entry.networkId);
    const branch = entry.scriptType === 'p2wsh' ? 2 : 1;
    const idxs = (o.cosigners || [1, 2]).map((n) => n - 1);
    const signers = idxs.map((i) => {
      const node = HDKey.fromMasterSeed(mnemonicToSeed(o.wallet.mnemonics[i]))
        .derive(`m/48'/${net.coinType}'/${o.wallet.account}'/${branch}'`).deriveChild(0).deriveChild(0);
      return { cosignerIndex: i + 1, privateKey: node.privateKey };
    });
    const res = signMultisigSpend({
      wallet: entry._e, network: net,
      utxos: list.map((u) => ({ txid: u.txid, vout: u.vout, value: u.value })),
      outputs: [{ address: o.to, value: amount }], signers, fee,
    });
    const out = {
      txid: res.txid, raw: res.raw, vsize: res.vsize,
      fee: Number(fee), amount: Number(amount), to: o.to,
      signedBy: signers.map((s) => s.cosignerIndex),
      warning: 'Проверьте адрес получателя и сумму: отправка необратима.',
    };
    if (o.send) {
      const txid = await json(`${base}/tx`, { method: 'POST', headers: { 'content-type': 'text/plain' }, body: res.raw });
      out.sent = true;
      out.networkTxid = typeof txid === 'string' ? txid : out.txid;
      out.explorer = WEB[entry.networkId] ? `${WEB[entry.networkId]}/tx/${out.txid}` : null;
    }
    return out;
  }

  /* ================================================================= утилиты */
  function networks() {
    return NETWORKS.map((n) => ({
      id: n.id, name: n.name, symbol: n.symbol, testnet: !!n.testnet,
      explorer: WEB[n.id] || null,
      hasExplorer: !!API[n.id],
      scriptTypes: isSegwitOnly(n.id) ? ['p2sh'] : ['p2wsh', 'p2sh-p2wsh', 'p2sh'],
      coinType: n.coinType,
    }));
  }
  function newMnemonic(words) { return generateMnemonic(words === 12 ? 128 : 256); }
  function isValidMnemonic(m) { try { return validateMnemonic(m); } catch { return false; } }
  function configure(opts) {
    if (opts && typeof opts.defaultAddressCount === 'number') DEFAULT_ADDRESS_COUNT = opts.defaultAddressCount;
    return { defaultAddressCount: DEFAULT_ADDRESS_COUNT };
  }

  return {
    version: VERSION,
    createWallet, detail, addresses, verifyAddress,
    balance, balances, utxos, send,
    networks, newMnemonic, isValidMnemonic, configure,
    scriptTypes: SCRIPT_LABEL,
  };
})();


  root.UTXO = UTXO;
  if (typeof module !== 'undefined' && module.exports) module.exports = UTXO;
})(typeof globalThis !== 'undefined' ? globalThis : this);
