/* =========================================================================
   wallet.js — слой операций кошелька.

   Разделение ответственности:
     guard-digests.js  — «что подписать»
     guard-ops.js      — «что отправить»
     guard-signer.js   — «чем подписать»
     guard-errors.js   — «почему отказано»
     wallet.js         — СВЯЗКА: какой порог подписей нужен, какой nonce,
                         что показать человеку перед подтверждением, как
                         разобрать отказ.

   Транспорт (отправка транзакции) НЕ здесь: в браузере его даёт ethers,
   в тестах — прямой RPC. wallet.js отвечает только за СЕМАНТИКУ Guard-а,
   поэтому он проверяем без сети.

   Пороги НЕ хардкодятся: клиент читает их с цепи (это публичные константы
   HOT_THRESHOLD / CRITICAL_THRESHOLD / HOT_OWNERS / TOTAL_OWNERS), а до
   подключения пользуется значениями из ABI (guard-constants.js).
   ========================================================================= */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) {
        module.exports = factory(
            require('./guard-digests.js'), require('./guard-ops.js'),
            require('./guard-signer.js'), require('./guard-errors.js'),
            require('./guard-constants.js')
        );
    } else {
        root.GuardWallet = factory(root.GuardDigests, root.GuardOps, root.GuardSigner,
                                   root.GuardErrors, root.GuardConstants);
    }
})(typeof self !== 'undefined' ? self : this, function (D, O, S, E, C) {
    'use strict';

    // ---------------------------------------------------------------------
    // Режимы авторизации
    // ---------------------------------------------------------------------

    /// @dev Обычные операции: 2 из 3 Hot. Критические: 3 из 5 и хотя бы один Cold.
    var MODE = { HOT: 'hot', CRITICAL: 'critical' };

    /// @dev План подписей. Пороги берутся из констант контракта; если цепь
    ///      недоступна — из значений ABI (guard-constants.js).
    function signerPlan(mode, limits) {
        var l = limits || {};
        var hotThreshold = Number(l.HOT_THRESHOLD != null ? l.HOT_THRESHOLD : 2);
        var critThreshold = Number(l.CRITICAL_THRESHOLD != null ? l.CRITICAL_THRESHOLD : 3);
        var total = Number(l.TOTAL_OWNERS != null ? l.TOTAL_OWNERS : 5);
        if (mode === MODE.CRITICAL) return { mode: mode, need: critThreshold, needCold: true, available: total };
        return { mode: MODE.HOT, need: hotThreshold, needCold: false, available: total };
    }

    /// @dev Собирает подписи из набора ключей по плану.
    ///      keys — массив приватных ключей владельцев; coldKeys — индексы Cold.
    ///      Возвращает { signatures, used, plan } либо бросает с объяснением.
    function collectSignatures(digest, keys, plan, coldFlags) {
        var sigs = [];
        var used = [];
        var coldUsed = false;
        for (var i = 0; i < keys.length && sigs.length < plan.need; i++) {
            sigs.push(S.sign(digest, BigInt(keys[i])));
            used.push(S.addressOf(BigInt(keys[i])));
            if (coldFlags && coldFlags[i]) coldUsed = true;
        }
        if (sigs.length < plan.need) {
            throw new Error('нужно подписей: ' + plan.need + ', дано ключей: ' + keys.length);
        }
        if (plan.needCold && !coldUsed) {
            throw new Error('критическая операция требует хотя бы один Cold-ключ');
        }
        return { signatures: sigs, used: used, plan: plan };
    }

    // ---------------------------------------------------------------------
    // Человеческое описание операции (для подтверждения пользователем)
    // ---------------------------------------------------------------------

    function short(addr) {
        if (typeof addr !== 'string' || addr.length < 12) return String(addr);
        return addr.slice(0, 6) + '…' + addr.slice(-4);
    }

    var KIND_LABEL = { 0: 'натив', 1: 'ERC-20', 2: 'ERC-721', 3: 'ERC-1155' };

    var describe = {
        transfer: function (a) {
            return 'Перевод ' + a.amount + ' токена ' + short(a.token) + ' на ' + short(a.recipient);
        },
        transferNative: function (a) {
            return 'Перевод ' + a.amount + ' wei натива на ' + short(a.recipient);
        },
        executeOnContract: function (a) {
            return 'Вызов ' + short(a.target) + ' с расходом ' + a.amount + ' токена ' + short(a.token);
        },
        approveOnContract: function (a) {
            return 'Разрешение ' + short(a.spender) + ' на ' + a.amount + ' токена ' + short(a.token);
        },
        emergencySweepAsset: function (a) {
            return 'АВАРИЙНЫЙ вывод ' + (KIND_LABEL[a.kind] || ('вид ' + a.kind)) +
                (a.kind === 2 || a.kind === 3 ? ' #' + a.id : '') +
                ' актива ' + short(a.asset) + ' на заранее заданный адрес';
        },
        agentOnContract: function (a) {
            return 'Агент ' + short(a.agent) + ' вызывает ' + short(a.target) +
                ' на ' + a.amount + ' токена ' + short(a.token);
        },
        subscribe: function (a) {
            return 'Оформление подписки (план ' + a.plan + ')';
        },
        cancelRecovery: function (a) {
            return 'ОТМЕНА восстановления доступа, запрос #' + a.requestId;
        }
    };

    // ---------------------------------------------------------------------
    // Кошелёк
    // ---------------------------------------------------------------------

    /// @dev config: { chainId, guard, policyOps }
    ///      rpc — необязательный объект с call(method, params) для чтения цепи.
    function create(config, rpc) {
        if (!config || !config.guard) throw new Error('нужен адрес guard');
        var chainId = Number(config.chainId);
        if (!chainId) throw new Error('нужен chainId');

        var domainSeparator = D.domainSeparator(chainId, config.guard);
        var limits = null;      // прочитанные с цепи константы
        var nonces = {};        // scope -> следующий nonce (локальный учёт)

        function nextNonce(scope) {
            if (!nonces[scope]) {
                // Начальное значение — время: оно монотонно и не пересекается
                // с нонсами, выданными другими сессиями.
                nonces[scope] = Math.floor(Date.now() / 1000);
            }
            var n = nonces[scope]++;
            return n;
        }

        /// @dev Пометить nonce израсходованным. ВАЖНО: неудачная операция
        ///      nonce НЕ расходует (состояние откатывается), поэтому
        ///      увеличивать счётчик можно только после успеха.
        function commitNonce(scope, nonce) {
            var cur = Number(nonce);
            if (!nonces[scope] || nonces[scope] <= cur) nonces[scope] = cur + 1;
        }

        /// @dev Подтянуть пороги с цепи. Молча оставляет значения из ABI,
        ///      если цепи нет — кошелёк обязан работать и офлайн.
        async function refreshLimits(ownerRegistry) {
            if (!rpc || !rpc.call) return limits;
            var addr = ownerRegistry || config.ownerRegistry;
            if (!addr) return limits;
            var names = ['HOT_THRESHOLD', 'CRITICAL_THRESHOLD', 'HOT_OWNERS', 'TOTAL_OWNERS'];
            var got = {};
            for (var i = 0; i < names.length; i++) {
                var sel = C.SELECTORS[names[i]];
                if (!sel) continue;
                try {
                    var res = await rpc.call('eth_call', [{ to: addr, data: sel }, 'latest']);
                    var word = (res || '').replace(/^0x/, '');
                    if (word.length >= 64) got[names[i]] = C.parse('uint256', word.slice(0, 64));
                } catch (e) { /* нет цепи — остаёмся на значениях из ABI */ }
            }
            if (Object.keys(got).length) limits = got;
            return limits;
        }

        function getLimits() { return limits; }

        // ---- операции ----

        function transfer(p) {
            var plan = signerPlan(MODE.HOT, limits);
            var digest = D.digest.transfer(domainSeparator, p.wallet, p.token, p.recipient, p.amount, p.nonce, p.deadline);
            var col = p.signatures ? null : collectSignatures(digest, p.keys, plan, p.coldFlags);
            var sigs = p.signatures || col.signatures;
            return {
                to: config.guard, value: 0n, digest: digest, mode: plan.mode,
                signers: col ? col.used : [],
                description: describe.transfer(p),
                data: O.encodeCall(O.SIG.transfer, [p.wallet, p.token, p.recipient, p.amount, p.nonce, p.deadline, sigs])
            };
        }

        function transferNative(p) {
            var plan = signerPlan(MODE.HOT, limits);
            var digest = D.digest.nativeTransfer(domainSeparator, p.wallet, p.recipient, p.amount, p.nonce, p.deadline);
            var col = p.signatures ? null : collectSignatures(digest, p.keys, plan, p.coldFlags);
            var sigs = p.signatures || col.signatures;
            return {
                to: config.guard, value: 0n, digest: digest, mode: plan.mode,
                signers: col ? col.used : [],
                description: describe.transferNative(p),
                data: O.encodeCall(O.SIG.transferNative, [p.wallet, p.recipient, p.amount, p.nonce, p.deadline, sigs])
            };
        }

        function executeOnContract(p) {
            var plan = signerPlan(MODE.HOT, limits);
            var digest = D.digest.executeOnContract(
                domainSeparator, p.mainWallet, p.wallet, p.target, p.token, p.amount, p.data, p.nonce, p.deadline
            );
            var col = p.signatures ? null : collectSignatures(digest, p.keys, plan, p.coldFlags);
            var sigs = p.signatures || col.signatures;
            return {
                to: config.guard, value: 0n, digest: digest, mode: plan.mode,
                signers: col ? col.used : [],
                description: describe.executeOnContract(p),
                data: O.encodeCall(O.SIG.executeOnContract, [
                    p.wallet, p.target, p.token, p.amount, p.data, p.nonce, p.deadline, p.strictSignature || '0x', sigs
                ])
            };
        }

        /// @dev Аварийный вывод — КРИТИЧЕСКАЯ операция (3/5 + Cold).
        ///      Получатель в аргументах ОТСУТСТВУЕТ: контракт берёт сохранённый
        ///      recoveryTarget, подменить его нельзя.
        function sweepAsset(p) {
            var plan = signerPlan(MODE.CRITICAL, limits);
            var digest = D.digest.sweepAsset(
                domainSeparator, p.wallet, p.asset, p.kind, p.id, p.amount, p.recipient, p.nonce, p.deadline
            );
            var col = p.signatures ? null : collectSignatures(digest, p.keys, plan, p.coldFlags);
            var sigs = p.signatures || col.signatures;
            return {
                to: config.guard, value: 0n, digest: digest, mode: plan.mode,
                signers: col ? col.used : [],
                description: describe.emergencySweepAsset(p),
                data: O.encodeCall(O.SIG.emergencySweepAsset, [
                    p.wallet, p.asset, p.kind, p.id, p.amount, p.nonce, p.deadline, sigs
                ])
            };
        }

        /// @dev Операция агента. Если сумма выше cosignAbove, контракт потребует
        ///      подписи владельцев — клиент обязан их приложить, иначе отказ.
        function agentOnContract(p) {
            var digest = D.digest.agentOnContract(
                domainSeparator, p.mainWallet, p.agent, p.wallet, p.target, p.token, p.amount,
                p.data, p.nonce, p.deadline
            );
            var agentSig = p.agentSignature || S.sign(digest, BigInt(p.agentKey));
            var cosigs = p.cosignatures || [];
            if (p.needsCosign && (!cosigs.length)) {
                throw new Error('операция выше порога: нужна подпись владельцев (cosignAbove)');
            }
            return {
                to: config.guard, value: 0n, digest: digest, mode: 'agent',
                signers: [S.addressOf(BigInt(p.agentKey))],
                description: describe.agentOnContract(p),
                data: O.encodeCall(O.SIG.executeAsAgent, [
                    p.agent, p.wallet, p.target, p.token, p.amount, p.data,
                    p.nonce, p.deadline, agentSig, cosigs, p.strictSignature || '0x'
                ])
            };
        }

        function cancelRecovery(p) {
            var plan = signerPlan(MODE.CRITICAL, limits);
            var digest = D.digest.policyAddrs(
                domainSeparator, p.mainWallet, 48, 1, p.recovery, '0x' + '0'.repeat(40),
                p.requestId, 0, p.nonce, p.deadline
            );
            var col = p.signatures ? null : collectSignatures(digest, p.keys, plan, p.coldFlags);
            var sigs = p.signatures || col.signatures;
            return {
                to: config.policyOps || config.guard, value: 0n, digest: digest, mode: plan.mode,
                signers: col ? col.used : [],
                description: describe.cancelRecovery(p),
                data: O.encodeCall(O.SIG.cancelRecoveryRequest, [
                    p.recovery, p.requestId, p.nonce, p.deadline, sigs
                ])
            };
        }

        // ---- проверка перед отправкой ----

        /// @dev Сухой прогон через eth_call: узнаём отказ ДО траты газа и
        ///      показываем человеку причину, а не hex.
        async function simulate(tx, from) {
            if (!rpc || !rpc.call) return { ok: true, note: 'нет соединения — прогон пропущен' };
            try {
                await rpc.call('eth_call', [{ from: from, to: tx.to, data: tx.data }, 'latest']);
                return { ok: true };
            } catch (e) {
                var data = extractRevertData(e);
                return { ok: false, reason: E.explain(data), raw: data };
            }
        }

        return {
            config: config,
            domainSeparator: domainSeparator,
            MODE: MODE,
            signerPlan: function (mode) { return signerPlan(mode, limits); },
            getLimits: getLimits,
            refreshLimits: refreshLimits,
            nextNonce: nextNonce,
            commitNonce: commitNonce,
            describe: describe,
            short: short,
            prepare: {
                transfer: transfer,
                transferNative: transferNative,
                executeOnContract: executeOnContract,
                sweepAsset: sweepAsset,
                agentOnContract: agentOnContract,
                cancelRecovery: cancelRecovery
            },
            simulate: simulate
        };
    }

    /// @dev Достаём revert-данные из разных форм ответа узла.
    function extractRevertData(err) {
        if (!err) return '0x';
        if (typeof err === 'string') return err;
        var d = err.data || err.error || err.cause;
        if (typeof d === 'string') return d;
        if (d && typeof d.data === 'string') return d.data;
        if (d && d.data && typeof d.data.data === 'string') return d.data.data;
        return '0x';
    }

    return {
        MODE: MODE,
        create: create,
        signerPlan: signerPlan,
        collectSignatures: collectSignatures,
        describe: describe,
        short: short,
        extractRevertData: extractRevertData
    };
});
