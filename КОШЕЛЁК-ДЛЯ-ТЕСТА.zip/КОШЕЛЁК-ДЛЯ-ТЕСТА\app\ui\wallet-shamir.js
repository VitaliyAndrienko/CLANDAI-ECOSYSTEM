/* =========================================================================
   wallet-shamir.js — пороговая схема вместо XOR, в дизайне заказчика.

   Заказчик попросил: пользователь выбирает ТОЛЬКО число частей, без порогов.
   Порог считается сам по правилу «больше половины»:
       2 -> 2,  3 -> 2,  4 -> 3,  5 -> 3,  6 -> 4

   Шифрование, Argon2id и пароль из трёх факторов — ФУНКЦИИ ЗАКАЗЧИКА
   (encryptAES / argon2Key / buildBackupPassword). Меняется только разбиение:
   вместо XOR двух долей — пороговая схема из client/vault.js (проверена
   104 автопроверками, включая перебор всех сочетаний долей).

   Файлы называются clandai-1.json, clandai-2.json, … по числу частей.
   ========================================================================= */

(function () {
    'use strict';

    function need(n) { return Math.ceil((n + 1) / 2); }
    function el(id) { return document.getElementById(id); }
    function partsEl() { return el('reg-parts'); }

    function refreshNote() {
        if (!partsEl() || !el('reg-parts-note')) return;
        var n = parseInt(partsEl().value, 10);
        el('reg-parts-note').textContent =
            '\u0427\u0442\u043e\u0431\u044b \u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c \u043a\u043e\u0448\u0435\u043b\u0451\u043a, \u043f\u043e\u043d\u0430\u0434\u043e\u0431\u044f\u0442\u0441\u044f \u043b\u044e\u0431\u044b\u0435 ' +
            need(n) + ' \u0438\u0437 ' + n + ' \u0447\u0430\u0441\u0442\u0435\u0439.';
    }
    if (partsEl()) { partsEl().onchange = refreshNote; refreshNote(); }

    /// @dev Создание частей отдельно от скачивания: так это можно ПРОВЕРИТЬ,
    ///      не записывая файлы на диск.
    window.__clandaiBuildShares = async function () {
        var seed = state.reg.seed;
        if (!seed) throw new Error('\u043d\u0435\u0442 \u0441\u0438\u0434-\u0444\u0440\u0430\u0437\u044b');
        var n = parseInt(partsEl().value, 10);
        var k = need(n);
        var raw = GuardVault.splitSecret(new TextEncoder().encode(seed), k, n,
            function (m) { return crypto.getRandomValues(new Uint8Array(m)); });
        var pwd = buildBackupPassword(state.reg.questions, state.reg.answers, state.reg.pattern, state.reg.pin);
        var out = [];
        for (var i = 0; i < raw.length; i++) {
            var sa = crypto.getRandomValues(new Uint8Array(16));
            var key = await argon2Key(pwd, sa);
            var aad = 'shamir:' + raw[i].x;
            var c = await encryptAES(bufToB64(raw[i].y), key, aad);
            out.push({
                version: 9, type: 'clandai-shamir-share',
                share: raw[i].x, x: raw[i].x, threshold: k, total: n,
                address: state.meta.address || (state.vault && state.vault.address),
                salt: bufToB64(sa), iv: c.iv, data: c.data, aad: aad,
                questions: [].concat(state.reg.questions),
                hasPassphrase: state.reg.usePassphrase,
                createdAt: new Date().toISOString(),
                fileName: 'clandai-' + (i + 1) + '.json'
            });
        }
        return out;
    };

    /// @dev Сборка частей обратно в фразу. Используется и восстановлением,
    ///      и самопроверкой — один код, одна логика.
    window.__clandaiCombineShares = async function (files, answers, pattern, pin) {
        var pwd = buildBackupPassword(files[0].questions, answers, pattern, pin);
        var points = [];
        for (var i = 0; i < files.length; i++) {
            var key = await argon2Key(pwd, b64ToBuf(files[i].salt));
            var b64 = await decryptAES(files[i].iv, files[i].data, key, files[i].aad || ('shamir:' + files[i].x));
            points.push({ x: files[i].x, y: b64ToBuf(b64) });
        }
        return new TextDecoder().decode(GuardVault.combineSecret(points));
    };

    el('btn-download-backup').onclick = async function () {
        showLoading('ARGON2ID + \u0427\u0410\u0421\u0422\u0418...');
        try {
            var list = await window.__clandaiBuildShares();
            for (var i = 0; i < list.length; i++) {
                if (!window.__noDownloads) downloadJson(list[i], list[i].fileName);
                await new Promise(function (r) { setTimeout(r, 250); });
            }
            var host = el('reg-done-file-1').parentElement;
            host.innerHTML = '';
            list.forEach(function (s) {
                var d = document.createElement('div');
                d.textContent = s.fileName;
                host.appendChild(d);
            });
            hideLoading();
            toast('\u2713 ' + list.length + ' \u0447\u0430\u0441\u0442\u0435\u0439');
        } catch (e) { hideLoading(); toast('\u041e\u0448\u0438\u0431\u043a\u0430: ' + e.message, true); }
    };

    // ---------------- восстановление из нескольких частей ----------------

    var multi = el('restore-multi-input');
    state.restore.files = [];

    el('btn-restore-multi').onclick = function () { multi.click(); };

    multi.onchange = async function () {
        var names = [], files = [];
        for (var i = 0; i < multi.files.length; i++) {
            var f = multi.files[i];
            try {
                var j = JSON.parse(await f.text());
                if (j.type !== 'clandai-shamir-share' && j.type !== 'clandai-backup') continue;
                files.push(j);
                names.push(f.name);
            } catch (e) { /* \u043d\u0435 JSON \u2014 \u043f\u0440\u043e\u043f\u0443\u0441\u043a\u0430\u0435\u043c */ }
        }
        state.restore.files = files;
        el('restore-multi-names').textContent = names.join(', ') || '\u0444\u0430\u0439\u043b\u044b \u043d\u0435 \u0440\u0430\u0441\u043f\u043e\u0437\u043d\u0430\u043d\u044b';
        if (!files.length) return;

        // вопросы берём из самих частей: пользователь писал их сам
        var qs = files[0].questions || [];
        var host = el('restore-q-fields');
        host.innerHTML = '';
        qs.forEach(function (q) {
            var d = document.createElement('div');
            d.className = 'field';
            var l = document.createElement('label');
            l.textContent = q;
            var inp = document.createElement('input');
            inp.className = 'r-answer';
            d.appendChild(l); d.appendChild(inp);
            host.appendChild(d);
        });
        toast('\u0427\u0430\u0441\u0442\u0435\u0439: ' + files.length +
              (files[0].total ? (' \u0438\u0437 ' + files[0].total) : '') +
              (files[0].threshold ? (' \u2014 \u043d\u0443\u0436\u043d\u043e ' + files[0].threshold) : ''));
    };

    el('btn-restore-go').onclick = async function () {
        var files = state.restore.files || [];
        if (!files.length) { toast('\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0444\u0430\u0439\u043b\u044b-\u0447\u0430\u0441\u0442\u0438', true); return; }
        var first = files[0];
        var k = first.threshold || 2;
        if (files.length < k) { toast('\u041d\u0443\u0436\u043d\u043e \u043c\u0438\u043d\u0438\u043c\u0443\u043c ' + k + ' \u0447\u0430\u0441\u0442\u0435\u0439, \u0432\u044b\u0431\u0440\u0430\u043d\u043e ' + files.length, true); return; }
        for (var i = 1; i < files.length; i++) {
            if (String(files[i].address).toLowerCase() !== String(first.address).toLowerCase()) {
                toast('\u0427\u0430\u0441\u0442\u0438 \u043e\u0442 \u0440\u0430\u0437\u043d\u044b\u0445 \u043a\u043e\u0448\u0435\u043b\u044c\u043a\u043e\u0432', true); return;
            }
        }
        var answers = [].slice.call(document.querySelectorAll('#restore-q-fields .r-answer'))
            .map(function (i) { return i.value.trim(); });
        if (answers.some(function (x) { return !x; })) { toast('\u041e\u0442\u0432\u0435\u0442\u044c\u0442\u0435 \u043d\u0430 \u0432\u0441\u0435 \u0432\u043e\u043f\u0440\u043e\u0441\u044b', true); return; }
        if (!state.restore.pattern || state.restore.pattern.length < 4) { toast('\u041d\u0430\u0440\u0438\u0441\u0443\u0439\u0442\u0435 \u0433\u0440\u0430\u0444\u0438\u0447\u0435\u0441\u043a\u0438\u0439 \u043f\u0430\u0440\u043e\u043b\u044c', true); return; }
        var pin = el('restore-pin').value.trim();
        if (pin.length !== 9) { toast('9 \u0446\u0438\u0444\u0440', true); return; }

        showLoading('ARGON2ID + \u0427\u0410\u0421\u0422\u0418...');
        try {
            var seed = await window.__clandaiCombineShares(files, answers, state.restore.pattern, pin);
            if (!ethers.Mnemonic.isValidMnemonic(seed)) {
                throw new Error('\u0424\u0440\u0430\u0437\u0430 \u043d\u0435 \u0441\u043e\u0448\u043b\u0430\u0441\u044c: \u043f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u043e\u0442\u0432\u0435\u0442\u044b, \u0433\u0440\u0430\u0444\u0438\u0447\u0435\u0441\u043a\u0438\u0439 \u043f\u0430\u0440\u043e\u043b\u044c \u0438 PIN');
            }
            var pp = '';
            if (first.hasPassphrase) { pp = await promptPassphrase(); if (pp === null) throw new Error('Cancelled'); }
            var w = pp ? ethers.HDNodeWallet.fromPhrase(seed, pp) : ethers.HDNodeWallet.fromPhrase(seed);
            if (w.address.toLowerCase() !== String(first.address).toLowerCase()) {
                throw new Error('\u041d\u0435\u0432\u0435\u0440\u043d\u0430\u044f \u043f\u0430\u0440\u043e\u043b\u044c\u043d\u0430\u044f \u0444\u0440\u0430\u0437\u0430');
            }
            var ps = crypto.getRandomValues(new Uint8Array(16));
            var pk = await argon2Key(buildPinPassword(pin), ps);
            var pc = await encryptAES(seed, pk, 'vault');
            var vault = {
                version: 9, type: 'clandai-local', address: first.address,
                salt: bufToB64(ps), iv: pc.iv, data: pc.data, aad: pc.aad,
                questions: [].concat(first.questions), hasPassphrase: first.hasPassphrase,
                createdAt: new Date().toISOString()
            };
            saveVault(vault);
            state.vault = vault;
            state.meta.questions = [].concat(first.questions);
            state.meta.address = first.address;
            state.meta.hasPassphrase = first.hasPassphrase;
            saveMeta();
            buildProvider();
            attachWallet(seed, first.address, pp);
            hideLoading();
            show('view-wallet');
            toast('\u2713 \u0412\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e');
        } catch (e) {
            hideLoading();
            console.error(e);
            toast(e.message === 'AUTH_TAG_MISMATCH'
                ? '\u0424\u0430\u0439\u043b \u043f\u043e\u0432\u0440\u0435\u0436\u0434\u0451\u043d'
                : (e.message || '\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0435 \u0434\u0430\u043d\u043d\u044b\u0435'), true);
        }
    };
})();