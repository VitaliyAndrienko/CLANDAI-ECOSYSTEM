/* =========================================================================
   guard-digests.js — EIP-712 digest-и операций SmartWalletGuard.

   Зачем отдельный модуль: каждый вызов Guard-а требует подписи владельцев
   над digest-ом, который контракт считает по СВОИМ правилам. Если клиент
   соберёт digest иначе — операция просто не пройдёт, и отлаживать это
   придётся на живом кошельке. Поэтому здесь:

     * keccak256 реализован локально (без CDN): для кошелька загружать
       крипто-код с внешнего CDN — это supply-chain риск;
     * порядок и типы полей повторяют contracts/GuardOps.sol ОДИН В К ОДИН;
     * tools/digest-vectors.js печатает векторы, а test/DigestParity.t.sol
       проверяет, что Solidity даёт ТЕ ЖЕ значения (побайтовое совпадение).

   Работает и в браузере (<script> -> window.GuardDigests), и в Node.
   ========================================================================= */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.GuardDigests = factory();
})(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    // =====================================================================
    // keccak256 (Ethereum: padding 0x01, НЕ NIST SHA3 с 0x06)
    // =====================================================================

    var MASK = (1n << 64n) - 1n;

    var RC = [
        0x0000000000000001n, 0x0000000000008082n, 0x800000000000808an, 0x8000000080008000n,
        0x000000000000808bn, 0x0000000080000001n, 0x8000000080008081n, 0x8000000000008009n,
        0x000000000000008an, 0x0000000000000088n, 0x0000000080008009n, 0x000000008000000an,
        0x000000008000808bn, 0x800000000000008bn, 0x8000000000008089n, 0x8000000000008003n,
        0x8000000000008002n, 0x8000000000000080n, 0x000000000000800an, 0x800000008000000an,
        0x8000000080008081n, 0x8000000000008080n, 0x0000000080000001n, 0x8000000080008008n
    ];

    // смещения rho, индексируются как x + 5*y
    var ROT = [
        0, 1, 62, 28, 27,
        36, 44, 6, 55, 20,
        3, 10, 43, 25, 39,
        41, 45, 15, 21, 8,
        18, 2, 61, 56, 14
    ];

    function rotl(v, n) {
        if (n === 0) return v & MASK;
        n = BigInt(n);
        return ((v << n) | (v >> (64n - n))) & MASK;
    }

    function keccakF(A) {
        for (var round = 0; round < 24; round++) {
            var C = new Array(5), i, x, y;

            // theta
            for (x = 0; x < 5; x++) {
                C[x] = A[x] ^ A[x + 5] ^ A[x + 10] ^ A[x + 15] ^ A[x + 20];
            }
            for (x = 0; x < 5; x++) {
                var D = C[(x + 4) % 5] ^ rotl(C[(x + 1) % 5], 1);
                for (y = 0; y < 5; y++) A[x + 5 * y] ^= D;
            }

            // rho + pi
            var B = new Array(25);
            for (y = 0; y < 5; y++) {
                for (x = 0; x < 5; x++) {
                    B[y + 5 * ((2 * x + 3 * y) % 5)] = rotl(A[x + 5 * y], ROT[x + 5 * y]);
                }
            }

            // chi
            for (y = 0; y < 5; y++) {
                for (x = 0; x < 5; x++) {
                    A[x + 5 * y] = B[x + 5 * y] ^ ((~B[(x + 1) % 5 + 5 * y] & MASK) & B[(x + 2) % 5 + 5 * y]);
                }
            }

            // iota
            A[0] ^= RC[round];
        }
    }

    function toBytes(input) {
        if (input instanceof Uint8Array) return input;
        if (typeof input === 'string') {
            var s = input.indexOf('0x') === 0 ? input.slice(2) : input;
            if (input.indexOf('0x') === 0) {
                var out = new Uint8Array(s.length / 2);
                for (var i = 0; i < out.length; i++) out[i] = parseInt(s.substr(i * 2, 2), 16);
                return out;
            }
            // UTF-8
            if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(input);
            var utf8 = unescape(encodeURIComponent(input));
            var b = new Uint8Array(utf8.length);
            for (var j = 0; j < utf8.length; j++) b[j] = utf8.charCodeAt(j);
            return b;
        }
        throw new Error('keccak256: unsupported input');
    }

    function keccak256(input) {
        var data = toBytes(input);
        var rate = 136; // байт для keccak-256
        var A = new Array(25).fill(0n);

        // Дополнение pad10*1: 0x01, нули, 0x80 в последнем байте блока.
        // ВАЖНО: при data.length % rate == 135 padLen == 1, и тогда 0x01 и 0x80
        // попадают в ОДИН байт (0x81). Добавлять целый лишний блок здесь нельзя —
        // это была реальная ошибка, из-за которой keccak расходился с Solidity
        // ровно на длинах вида 135 + 136*k.
        var padLen = rate - (data.length % rate);
        var padded = new Uint8Array(data.length + padLen);
        padded.set(data, 0);
        padded[data.length] = 0x01;
        padded[padded.length - 1] |= 0x80;

        for (var off = 0; off < padded.length; off += rate) {
            for (var i = 0; i < rate / 8; i++) {
                var lane = 0n;
                for (var k = 7; k >= 0; k--) {
                    lane = (lane << 8n) | BigInt(padded[off + i * 8 + k]);
                }
                A[i] ^= lane;
            }
            keccakF(A);
        }

        var out = new Uint8Array(32);
        for (var w = 0; w < 4; w++) {
            var v = A[w];
            for (var b = 0; b < 8; b++) {
                out[w * 8 + b] = Number(v & 0xffn);
                v >>= 8n;
            }
        }
        return out;
    }

    function hex(bytes) {
        var s = '0x';
        for (var i = 0; i < bytes.length; i++) s += bytes[i].toString(16).padStart(2, '0');
        return s;
    }

    function keccakHex(input) {
        return hex(keccak256(input));
    }

    // =====================================================================
    // Минимальный ABI-энкодер: все нужные типы — одно 32-байтовое слово
    // =====================================================================

    function word(value) {
        var out = new Uint8Array(32);
        var v = BigInt(value);
        for (var i = 31; i >= 0; i--) {
            out[i] = Number(v & 0xffn);
            v >>= 8n;
        }
        if (v !== 0n) throw new Error('value overflows 32 bytes');
        return out;
    }

    function addressWord(addr) {
        if (typeof addr !== 'string' || !/^0x[0-9a-fA-F]{40}$/.test(addr)) {
            throw new Error('bad address: ' + addr);
        }
        return word(BigInt(addr));
    }

    /// @dev bytes32(bytes20(a)) в Solidity ВЫРАВНИВАЕТ АДРЕС ВЛЕВО (20 байт + 12 нулей),
    ///      в отличие от abi.encode(address), который выравнивает вправо.
    ///      Порядок байт разный — путать нельзя, это ломает digest.
    function bytes20Word(addr) {
        var b = toBytes(addr);
        if (b.length !== 20) throw new Error('bad address: ' + addr);
        var out = new Uint8Array(32);
        out.set(b, 0);
        return out;
    }

    function bytes32Word(h) {
        var b = toBytes(h);
        if (b.length !== 32) throw new Error('bad bytes32');
        return b;
    }

    function concat(arrays) {
        var total = 0, i;
        for (i = 0; i < arrays.length; i++) total += arrays[i].length;
        var out = new Uint8Array(total), off = 0;
        for (i = 0; i < arrays.length; i++) { out.set(arrays[i], off); off += arrays[i].length; }
        return out;
    }

    /// @dev abi.encode для статических типов = конкатенация 32-байтовых слов.
    function abiEncode(words) { return concat(words); }

    // =====================================================================
    // Typehash-и: строки ОБЯЗАНЫ совпадать с contracts/GuardOps.sol
    // =====================================================================

    var T = {
        DOMAIN: keccak256('EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)'),
        TRANSFER: keccak256('Transfer(address wallet,address token,address recipient,uint256 amount,uint256 nonce,uint256 deadline)'),
        NATIVE_TRANSFER: keccak256('NativeTransfer(address wallet,address recipient,uint256 amount,uint256 nonce,uint256 deadline)'),
        SWEEP: keccak256('EmergencySweep(address wallet,address token,address recipient,uint256 nonce,uint256 deadline)'),
        SUBSCRIBE: keccak256('Subscribe(address mainWallet,uint8 plan,address paymentToken,uint256 price,address fromWallet,uint256 nonce,uint256 deadline)'),
        POLICY: keccak256('PolicyOp(address mainWallet,uint8 kind,uint8 op,bytes32 data1,bytes32 data2,uint256 value1,uint256 value2,uint256 nonce,uint256 deadline)'),
        POLICY_DEEP: keccak256('PolicyOpDeep(address mainWallet,uint8 kind,uint8 op,bytes32 data1,bytes32 data2,uint256 value1,uint256 value2,uint256 extra,uint256 nonce,uint256 deadline)'),
        OWNERS: keccak256('ChangeOwners(address mainWallet,bytes32 ownersHash,bytes32 isHotHash,uint256 nonce,uint256 deadline)'),
        MIGRATION: keccak256('Migration(address mainWallet,address newGuard,bytes32 migrationDataHash,uint256 nonce,uint256 executeAfter,uint256 deadline,bool emergency)'),
        CANCEL_MIGRATION: keccak256('CancelMigration(address mainWallet,address newGuard,uint256 nonce,uint256 deadline)'),
        ON_CONTRACT: keccak256('OnContract(address mainWallet,address wallet,address target,address token,uint256 amount,bytes32 dataHash,uint256 nonce,uint256 deadline)'),
        APPROVE: keccak256('ApproveOnContract(address mainWallet,address wallet,address spender,address token,uint256 amount,uint256 nonce,uint256 deadline)'),
        STRICT: keccak256('StrictApproval(bytes32 operationDigest)'),
        AGENT: keccak256('AgentOnContract(address mainWallet,address agent,address wallet,address target,address token,uint256 amount,bytes32 dataHash,uint256 nonce,uint256 deadline)'),
        SESSION_SCOPE: keccak256('SessionScope(address agent,address wallet,address target,address token,uint256 maxPerOp,uint256 maxTotal,uint64 expiresAt,uint256 cosignAbove,uint256 nonce,uint256 deadline)'),
        SWEEP_ASSET: keccak256('EmergencySweepAsset(address wallet,address asset,uint8 kind,uint256 id,uint256 amount,address recipient,uint256 nonce,uint256 deadline)')
    };

    var NAME_HASH = keccak256('SmartWalletGuard');
    var VERSION_HASH = keccak256('6.2.0');

    // =====================================================================
    // Домен и финальный digest
    // =====================================================================

    function domainSeparator(chainId, verifyingContract) {
        return keccakHex(abiEncode([
            T.DOMAIN, NAME_HASH, VERSION_HASH, word(chainId), addressWord(verifyingContract)
        ]));
    }

    function digestOf(ds, structHash) {
        return keccakHex(concat([toBytes('0x1901'), bytes32Word(ds), bytes32Word(structHash)]));
    }

    // =====================================================================
    // Структурные хеши (порядок = GuardOps.sol)
    // =====================================================================

    function h(typehash, words) { return keccakHex(abiEncode([typehash].concat(words))); }

    var hash = {
        transfer: function (wallet, token, recipient, amount, nonce, deadline) {
            return h(T.TRANSFER, [addressWord(wallet), addressWord(token), addressWord(recipient),
                                  word(amount), word(nonce), word(deadline)]);
        },
        nativeTransfer: function (wallet, recipient, amount, nonce, deadline) {
            return h(T.NATIVE_TRANSFER, [addressWord(wallet), addressWord(recipient),
                                         word(amount), word(nonce), word(deadline)]);
        },
        sweep: function (wallet, token, recipient, nonce, deadline) {
            return h(T.SWEEP, [addressWord(wallet), addressWord(token), addressWord(recipient),
                               word(nonce), word(deadline)]);
        },
        subscribe: function (mainWallet, plan, paymentToken, price, fromWallet, nonce, deadline) {
            return h(T.SUBSCRIBE, [addressWord(mainWallet), word(plan), addressWord(paymentToken),
                                   word(price), addressWord(fromWallet), word(nonce), word(deadline)]);
        },
        /// @dev policyHashAddrs: адреса кодируются как bytes32(bytes20(a)) — побайтово
        ///      это то же самое, что слово address.
        policyAddrs: function (mainWallet, kind, op, a, b, v1, v2, nonce, deadline) {
            // a и b кодируются как bytes32(bytes20(x)) -> ВЛЕВО, не как address
            return h(T.POLICY, [addressWord(mainWallet), word(kind), word(op), bytes20Word(a), bytes20Word(b),
                                word(v1), word(v2), word(nonce), word(deadline)]);
        },
        policyVals: function (mainWallet, kind, op, v1, v2, v3, v4, nonce, deadline) {
            return h(T.POLICY, [addressWord(mainWallet), word(kind), word(op), word(v1), word(v2),
                                word(v3), word(v4), word(nonce), word(deadline)]);
        },
        policyDeep: function (mainWallet, kind, op, data1, data2, v1, v2, extra, nonce, deadline) {
            return h(T.POLICY_DEEP, [addressWord(mainWallet), word(kind), word(op),
                                     bytes32Word(data1), bytes32Word(data2),
                                     word(v1), word(v2), word(extra), word(nonce), word(deadline)]);
        },
        changeOwners: function (mainWallet, ownersHash, isHotHash, nonce, deadline) {
            return h(T.OWNERS, [addressWord(mainWallet), bytes32Word(ownersHash), bytes32Word(isHotHash),
                                word(nonce), word(deadline)]);
        },
        migration: function (mainWallet, newGuard, migrationDataHash, nonce, executeAfter, deadline, emergency) {
            return h(T.MIGRATION, [addressWord(mainWallet), addressWord(newGuard),
                                   bytes32Word(migrationDataHash), word(nonce), word(executeAfter),
                                   word(deadline), word(emergency ? 1 : 0)]);
        },
        cancelMigration: function (mainWallet, newGuard, nonce, deadline) {
            return h(T.CANCEL_MIGRATION, [addressWord(mainWallet), addressWord(newGuard),
                                          word(nonce), word(deadline)]);
        },
        onContract: function (mainWallet, wallet, target, token, amount, dataHash, nonce, deadline) {
            return h(T.ON_CONTRACT, [addressWord(mainWallet), addressWord(wallet), addressWord(target),
                                     addressWord(token), word(amount), bytes32Word(dataHash),
                                     word(nonce), word(deadline)]);
        },
        approveOnContract: function (mainWallet, wallet, spender, token, amount, nonce, deadline) {
            return h(T.APPROVE, [addressWord(mainWallet), addressWord(wallet), addressWord(spender),
                                 addressWord(token), word(amount), word(nonce), word(deadline)]);
        },
        strictApproval: function (operationDigest) {
            return h(T.STRICT, [bytes32Word(operationDigest)]);
        },
        agent: function (mainWallet, agent, wallet, target, token, amount, dataHash, nonce, deadline) {
            return h(T.AGENT, [addressWord(mainWallet), addressWord(agent), addressWord(wallet),
                               addressWord(target), addressWord(token), word(amount),
                               bytes32Word(dataHash), word(nonce), word(deadline)]);
        },
        sessionScope: function (agent, wallet, target, token, maxPerOp, maxTotal, expiresAt, cosignAbove, nonce, deadline) {
            return h(T.SESSION_SCOPE, [addressWord(agent), addressWord(wallet), addressWord(target),
                                       addressWord(token), word(maxPerOp), word(maxTotal),
                                       word(expiresAt), word(cosignAbove), word(nonce), word(deadline)]);
        },
        sweepAsset: function (wallet, asset, kind, id, amount, recipient, nonce, deadline) {
            return h(T.SWEEP_ASSET, [addressWord(wallet), addressWord(asset), word(kind), word(id),
                                     word(amount), addressWord(recipient), word(nonce), word(deadline)]);
        }
    };

    // =====================================================================
    // Готовые digest-и для подписи
    // =====================================================================

    /// @dev dataHash считается как keccak256(calldata) — как в контракте.
    function calldataHash(data) { return keccakHex(data || '0x'); }

    var digest = {
        transfer: function (ds, wallet, token, recipient, amount, nonce, deadline) {
            return digestOf(ds, hash.transfer(wallet, token, recipient, amount, nonce, deadline));
        },
        nativeTransfer: function (ds, wallet, recipient, amount, nonce, deadline) {
            return digestOf(ds, hash.nativeTransfer(wallet, recipient, amount, nonce, deadline));
        },
        sweepAsset: function (ds, wallet, asset, kind, id, amount, recipient, nonce, deadline) {
            return digestOf(ds, hash.sweepAsset(wallet, asset, kind, id, amount, recipient, nonce, deadline));
        },
        executeOnContract: function (ds, mainWallet, wallet, target, token, amount, data, nonce, deadline) {
            return digestOf(ds, hash.onContract(mainWallet, wallet, target, token, amount,
                                                calldataHash(data), nonce, deadline));
        },
        agentOnContract: function (ds, mainWallet, agent, wallet, target, token, amount, data, nonce, deadline) {
            return digestOf(ds, hash.agent(mainWallet, agent, wallet, target, token, amount,
                                           calldataHash(data), nonce, deadline));
        },
        strictApproval: function (ds, operationDigest) {
            return digestOf(ds, hash.strictApproval(operationDigest));
        },
        subscribe: function (ds, mainWallet, plan, paymentToken, price, fromWallet, nonce, deadline) {
            return digestOf(ds, hash.subscribe(mainWallet, plan, paymentToken, price, fromWallet, nonce, deadline));
        },
        policyAddrs: function (ds, mainWallet, kind, op, a, b, v1, v2, nonce, deadline) {
            return digestOf(ds, hash.policyAddrs(mainWallet, kind, op, a, b, v1, v2, nonce, deadline));
        },
        policyDeep: function (ds, mainWallet, kind, op, data1, data2, v1, v2, extra, nonce, deadline) {
            return digestOf(ds, hash.policyDeep(mainWallet, kind, op, data1, data2, v1, v2, extra, nonce, deadline));
        },
        changeOwners: function (ds, mainWallet, ownersHash, isHotHash, nonce, deadline) {
            return digestOf(ds, hash.changeOwners(mainWallet, ownersHash, isHotHash, nonce, deadline));
        },
        migration: function (ds, mainWallet, newGuard, migrationDataHash, nonce, executeAfter, deadline, emergency) {
            return digestOf(ds, hash.migration(mainWallet, newGuard, migrationDataHash, nonce, executeAfter, deadline, emergency));
        },
        cancelMigration: function (ds, mainWallet, newGuard, nonce, deadline) {
            return digestOf(ds, hash.cancelMigration(mainWallet, newGuard, nonce, deadline));
        }
    };

    return {
        keccak256: keccakHex,
        keccak256Bytes: keccak256,
        abiEncode: abiEncode,
        word: word,
        addressWord: addressWord,
        bytes32Word: bytes32Word,
        bytes20Word: bytes20Word,
        concat: concat,
        TYPES: T,
        NICKNAME_DOMAIN: { name: 'SmartWalletGuard', version: '6.2.0' },
        domainSeparator: domainSeparator,
        digestOf: digestOf,
        calldataHash: calldataHash,
        hash: hash,
        digest: digest
    };
});
