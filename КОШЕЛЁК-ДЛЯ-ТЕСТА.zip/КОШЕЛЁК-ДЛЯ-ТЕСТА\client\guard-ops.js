/* =========================================================================
   guard-ops.js — сборка ВЫЗОВОВ операций SmartWalletGuard.

   guard-digests.js отвечает на вопрос «что подписать», guard-ops.js — на
   вопрос «что отправить»: селектор + ABI-кодирование аргументов.

   Почему generic-энкодер, а не 40 ручных функций: ошибку в порядке или
   количестве аргументов руками не видно (в этом проекте так ломалось трижды:
   approveOnContract — 7 вместо 8, subscribe — 5, setRecoveryTarget — op 20
   вместо 1). Здесь сигнатура задана СТРОКОЙ, ровно как в Solidity, и
   tools/op-vectors.js + test/CalldataParity.t.sol сверяют результат с
   abi.encodeWithSelector из самого контракта.

   Поддержаны типы: address, bool, uint8/uint64/uint256, bytes, bytes[],
   address[], bool[]. Для операций Guard-а этого достаточно.
   ========================================================================= */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) {
        module.exports = factory(require('./guard-digests.js'), require('./guard-ops-signatures.js'));
    } else {
        root.GuardOps = factory(root.GuardDigests, root.GuardOpsSignatures);
    }
})(typeof self !== 'undefined' ? self : this, function (D, GENERATED) {
    'use strict';

    // =====================================================================
    // Слова и байты
    // =====================================================================

    function toBytes(input) {
        if (input instanceof Uint8Array) return input;
        if (typeof input === 'string') {
            var s = input.slice(0, 2) === '0x' ? input.slice(2) : input;
            if (s.length % 2 !== 0) throw new Error('odd hex length');
            var out = new Uint8Array(s.length / 2);
            for (var i = 0; i < out.length; i++) out[i] = parseInt(s.substr(i * 2, 2), 16);
            return out;
        }
        if (Array.isArray(input)) return new Uint8Array(input);
        throw new Error('toBytes: unsupported');
    }

    function hexOf(bytes) {
        var s = '0x';
        for (var i = 0; i < bytes.length; i++) s += bytes[i].toString(16).padStart(2, '0');
        return s;
    }

    function padRight(bytes) {
        var rem = bytes.length % 32;
        if (rem === 0) return bytes;
        var out = new Uint8Array(bytes.length + (32 - rem));
        out.set(bytes, 0);
        return out;
    }

    // =====================================================================
    // Парсер сигнатуры
    // =====================================================================

    function parseSignature(sig) {
        var open = sig.indexOf('(');
        if (open < 0 || sig[sig.length - 1] !== ')') throw new Error('bad signature: ' + sig);
        var name = sig.slice(0, open);
        var inner = sig.slice(open + 1, sig.length - 1);
        var types = [];
        if (inner.length) {
            var depth = 0, cur = '';
            for (var i = 0; i < inner.length; i++) {
                var ch = inner[i];
                if (ch === '(') depth++;
                if (ch === ')') depth--;
                if (ch === ',' && depth === 0) { types.push(cur); cur = ''; }
                else cur += ch;
            }
            types.push(cur);
        }
        return { name: name, types: types, canonical: name + '(' + types.join(',') + ')' };
    }

    function selector(sig) {
        return '0x' + hexOf(D.keccak256Bytes(parseSignature(sig).canonical)).slice(2, 10);
    }

    // =====================================================================
    // Кодирование значений
    // =====================================================================

    function isDynamic(t) { return t === 'bytes' || t === 'string' || t.slice(-2) === '[]'; }

    function encodeValue(type, value) {
        if (type === 'address') {
            return { dynamic: false, head: D.addressWord(value) };
        }
        if (type === 'bool') {
            return { dynamic: false, head: D.word(value ? 1 : 0) };
        }
        if (/^uint\d*$/.test(type)) {
            var bits = type === 'uint' ? 256 : parseInt(type.slice(4), 10);
            var v = BigInt(value);
            if (v < 0n) throw new Error('negative ' + type);
            if (v >= (1n << BigInt(bits))) throw new Error('value out of range for ' + type);
            return { dynamic: false, head: D.word(v) };
        }
        if (type === 'bytes') {
            var b = toBytes(value);
            var tail = D.concat([D.word(b.length), padRight(b)]);
            return { dynamic: true, tail: tail };
        }
        if (type.slice(-2) === '[]') {
            var base = type.slice(0, -2);
            var items = value.map(function (v) { return encodeValue(base, v); });
            // ВАЖНО: массив динамический ВСЕГДА, но схема зависит от элемента.
            // Статические элементы (address[], bool[], uint256[]) кодируются
            // подряд, БЕЗ offset-ов; offset-ы нужны только для bytes[]/string[].
            if (!isDynamic(base)) {
                var words = items.map(function (it) { return it.head; });
                return { dynamic: true, tail: D.concat([D.word(items.length)].concat(words)) };
            }
            var innerTails = [];
            var tailLen = 0;
            var offsets = items.map(function (it) {
                var off = D.word(32 * items.length + tailLen);
                innerTails.push(it.tail);
                tailLen += it.tail.length;
                return off;
            });
            var head = D.concat([D.word(items.length)].concat(offsets));
            return { dynamic: true, tail: D.concat([head].concat(innerTails)) };
        }
        throw new Error('unsupported type: ' + type);
    }

    /// @dev abi.encode аргументов (offsets отсчитываются от начала блока аргументов).
    function encodeArgs(types, values) {
        if (types.length !== values.length) {
            throw new Error('argument count mismatch: ' + types.length + ' vs ' + values.length);
        }
        var headSize = 32 * types.length;
        var heads = [], tails = [], tailLen = 0;
        for (var i = 0; i < types.length; i++) {
            var enc = encodeValue(types[i], values[i]);
            if (enc.dynamic) {
                heads.push(D.word(headSize + tailLen));
                tails.push(enc.tail);
                tailLen += enc.tail.length;
            } else {
                heads.push(enc.head);
            }
        }
        return D.concat(heads.concat(tails));
    }

    /// @dev Полная calldata: селектор (4 байта) + abi.encode аргументов.
    function encodeCall(sig, args) {
        var p = parseSignature(sig);
        return selector(p.canonical) + hexOf(encodeArgs(p.types, args)).slice(2);
    }

    /// @dev Проверка, что набрано нужное число аргументов — до отправки.
    function checkArity(sig, args) {
        var p = parseSignature(sig);
        if (p.types.length !== args.length) {
            throw new Error(p.name + ': ожидается ' + p.types.length + ' аргументов, передано ' + args.length);
        }
        return true;
    }

    // =====================================================================
    // Сигнатуры операций (должны совпадать с контрактами)
    // =====================================================================

    /// @dev Сигнатуры АВТОГЕНЕРИРОВАНЫ из скомпилированного ABI
    ///      (tools/gen-op-signatures.js). Руками их набирать нельзя: за две
    ///      минуты написания этого файла так было допущено две ошибки.
    var SIG = GENERATED.SIG;
    var ORIGIN = GENERATED.ORIGIN;

    // =====================================================================
    // Сборка вызовов
    // =====================================================================

    /// @dev Общий вид: {to, data, value}. to — адрес контракта, который надо звать
    ///      (Guard для денежных операций, PolicyOps для операций политики).
    function call(to, sig, args) {
        checkArity(sig, args);
        return { to: to, data: encodeCall(sig, args), value: 0n };
    }

    /// @dev Операции, требующие подписи. Возвращает и calldata, и digest,
    ///      который надо подписать — сшивка guard-ops с guard-digests.
    function build(contracts, chainId) {
        var ds = D.domainSeparator(chainId, contracts.guard);
        var g = contracts.guard;
        var p = contracts.policyOps;

        return {
            domainSeparator: ds,

            transfer: function (wallet, token, recipient, amount, nonce, deadline, sigs) {
                var d = D.digest.transfer(ds, wallet, token, recipient, amount, nonce, deadline);
                return { to: g, data: encodeCall(SIG.transfer, [wallet, token, recipient, amount, nonce, deadline, sigs]), digest: d, value: 0n };
            },
            transferNative: function (wallet, recipient, amount, nonce, deadline, sigs) {
                var d = D.digest.nativeTransfer(ds, wallet, recipient, amount, nonce, deadline);
                return { to: g, data: encodeCall(SIG.transferNative, [wallet, recipient, amount, nonce, deadline, sigs]), digest: d, value: 0n };
            },
            executeOnContract: function (mainWallet, wallet, target, token, amount, data, nonce, deadline, strictSig, sigs) {
                var d = D.digest.executeOnContract(ds, mainWallet, wallet, target, token, amount, data, nonce, deadline);
                return { to: g, data: encodeCall(SIG.executeOnContract, [wallet, target, token, amount, data, nonce, deadline, strictSig, sigs]), digest: d, value: 0n };
            },
            agentOnContract: function (mainWallet, agent, wallet, target, token, amount, data, nonce, deadline, agentSig, cosigs, strictSig) {
                var d = D.digest.agentOnContract(ds, mainWallet, agent, wallet, target, token, amount, data, nonce, deadline);
                return { to: g, data: encodeCall(SIG.executeAsAgent, [agent, wallet, target, token, amount, data, nonce, deadline, agentSig, cosigs, strictSig]), digest: d, value: 0n };
            },
            emergencySweepAsset: function (wallet, asset, kind, id, amount, recipient, nonce, deadline, sigs) {
                var d = D.digest.sweepAsset(ds, wallet, asset, kind, id, amount, recipient, nonce, deadline);
                return { to: g, data: encodeCall(SIG.emergencySweepAsset, [wallet, asset, kind, id, amount, nonce, deadline, sigs]), digest: d, value: 0n };
            },
            /// @dev Operation-1 политики (два адреса).
            policyAddrs: function (mainWallet, kind, op, a, b, v1, v2, nonce, deadline, sigs) {
                var d = D.digest.policyAddrs(ds, mainWallet, kind, op, a, b, v1, v2, nonce, deadline);
                return { digest: d, mainWallet: mainWallet, kind: kind, op: op, a: a, b: b, v1: v1, v2: v2, nonce: nonce, deadline: deadline, sigs: sigs };
            },
            /// @dev Operation-2 политики (два «свободных» слова).
            policyDeep: function (mainWallet, kind, op, data1, data2, v1, v2, extra, nonce, deadline, sigs) {
                var d = D.digest.policyDeep(ds, mainWallet, kind, op, data1, data2, v1, v2, extra, nonce, deadline);
                return { digest: d, mainWallet: mainWallet, kind: kind, op: op, data1: data1, data2: data2, v1: v1, v2: v2, extra: extra, nonce: nonce, deadline: deadline, sigs: sigs };
            },
            /// @dev Запись в PolicyOps готовой calldata.
            policyCall: function (name, args) {
                if (!SIG[name]) throw new Error('unknown policy op: ' + name);
                return call(p, SIG[name], args);
            },
            guardCall: function (name, args) {
                if (!SIG[name]) throw new Error('unknown guard op: ' + name);
                return call(g, SIG[name], args);
            }
        };
    }

    return {
        SIG: SIG,
        ORIGIN: ORIGIN,
        selector: selector,
        parseSignature: parseSignature,
        encodeArgs: encodeArgs,
        encodeCall: encodeCall,
        checkArity: checkArity,
        call: call,
        build: build
    };
});
