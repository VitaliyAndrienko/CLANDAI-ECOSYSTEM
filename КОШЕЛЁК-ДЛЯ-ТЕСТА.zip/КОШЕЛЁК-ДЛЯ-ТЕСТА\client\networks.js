/* =========================================================================
   networks.js — реестр сетей кошелька. 82 сети.

   ЕДИНЫЙ ИСТОЧНИК ДАННЫХ О СЕТЯХ. Всё, что показывает кошелёк (список сетей,
   адреса, обозначения стандартов, логотипы), берётся ОТСЮДА, а не из разметки.
   Так данные можно менять динамически: софт правит массив, интерфейс
   перерисовывается сам.

   ПОЛЯ ЗАПИСИ СЕТИ
   ----------------
   id        — короткий ключ (используется в файлах, localStorage, логотипах)
   name      — название для интерфейса (может быть переведено через i18n)
   group     — раздел в списке: EVM / EVM L2 / EVM L1 / Bitcoin / UTXO / Ed25519 /
               Cardano / Starknet / Cosmos / Move / Other
   type      — как выводится адрес: evm | btc | bch | ed25519 | ton | stellar |
               algorand | tezos | hedera | monero | substrate | cardano |
               starknet | cosmos | injective | xrp | tron | waves | kaspa
   path      — путь производной, {i} заменяется на номер адреса
   sameAs    — если адрес совпадает с другой сетью (все EVM — один адрес)
   addrType  — для UTXO: p2pkh | p2sh | p2wpkh | p2tr
   hrp       — префикс адреса (bech32) или сети Cosmos
   p2pkhVer / p2shVer — версии байта для устаревших адресов
   ticker    — обозначение монеты сети
   standard  — обозначение токенов: ERC-20, BEP-20, TRC-20, SPL, …
   color     — фирменный цвет (для монограммы, если нет логотипа)
   slip44    — номер монеты в SLIP-0044 (для информации и проверок)
   popular   — показывать в начале списка
   note      — короткое пояснение
   ========================================================================= */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.GuardNetworks = factory();
})(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    /// @dev ПОРЯДОК ВАЖЕН: внутри группы сохраняется как есть.
    var LIST = [
        // ---------------- EVM ----------------
        { id: 'ethereum',   name: 'Ethereum',            group: 'EVM', type: 'evm', path: "m/44'/60'/0'/0/{i}", popular: true },
        { id: 'polygon',    name: 'Polygon',             group: 'EVM', type: 'evm', sameAs: 'ethereum', popular: true },
        { id: 'bsc',        name: 'BNB Chain',           group: 'EVM', type: 'evm', sameAs: 'ethereum', popular: true },
        { id: 'arbitrum',   name: 'Arbitrum',            group: 'EVM', type: 'evm', sameAs: 'ethereum' },
        { id: 'optimism',   name: 'Optimism',            group: 'EVM', type: 'evm', sameAs: 'ethereum' },
        { id: 'base',       name: 'Base',                group: 'EVM', type: 'evm', sameAs: 'ethereum' },
        { id: 'avalanche',  name: 'Avalanche C-Chain',   group: 'EVM', type: 'evm', sameAs: 'ethereum' },
        { id: 'fantom',     name: 'Fantom',              group: 'EVM', type: 'evm', sameAs: 'ethereum' },
        { id: 'gnosis',     name: 'Gnosis',              group: 'EVM', type: 'evm', sameAs: 'ethereum' },
        { id: 'celo',       name: 'Celo',                group: 'EVM', type: 'evm', sameAs: 'ethereum' },
        { id: 'blast',      name: 'Blast',               group: 'EVM L2', type: 'evm', sameAs: 'ethereum' },
        { id: 'linea',      name: 'Linea',               group: 'EVM L2', type: 'evm', sameAs: 'ethereum' },
        { id: 'mantle',     name: 'Mantle',              group: 'EVM L2', type: 'evm', sameAs: 'ethereum' },
        { id: 'scroll',     name: 'Scroll',              group: 'EVM L2', type: 'evm', sameAs: 'ethereum' },
        { id: 'zksync',     name: 'zkSync Era',          group: 'EVM L2', type: 'evm', sameAs: 'ethereum', note: 'EOA = EVM address' },
        { id: 'mode',       name: 'Mode Network',        group: 'EVM L2', type: 'evm', sameAs: 'ethereum' },
        { id: 'zora',       name: 'Zora',                group: 'EVM L2', type: 'evm', sameAs: 'ethereum' },
        { id: 'taiko',      name: 'Taiko',               group: 'EVM L2', type: 'evm', sameAs: 'ethereum' },
        { id: 'manta',      name: 'Manta Pacific',       group: 'EVM L2', type: 'evm', sameAs: 'ethereum' },
        { id: 'metis',      name: 'Metis',               group: 'EVM L2', type: 'evm', sameAs: 'ethereum' },
        { id: 'hyperliquid',name: 'Hyperliquid (HyperEVM)', group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'robinhood',  name: 'Robinhood Chain',     group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'berachain',  name: 'Berachain',           group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'monad',      name: 'Monad',               group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'kava',       name: 'Kava (EVM)',          group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'moonbeam',   name: 'Moonbeam',            group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'moonriver',  name: 'Moonriver',           group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'cronos',     name: 'Cronos',              group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'pulsechain', name: 'PulseChain',          group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'coredao',    name: 'Core DAO',            group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'flare',      name: 'Flare',               group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'songbird',   name: 'Songbird',            group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'kaia',       name: 'Kaia (Klaytn)',       group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'ronin',      name: 'Ronin Network',       group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'beam',       name: 'Beam (Avalanche)',    group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },
        { id: 'immutable',  name: 'Immutable zkEVM',     group: 'EVM L1', type: 'evm', sameAs: 'ethereum' },

        // ---------------- Bitcoin ----------------
        { id: 'btc-legacy', name: 'Bitcoin (Legacy)',        group: 'Bitcoin', type: 'btc', path: "m/44'/0'/0'/0/{i}", addrType: 'p2pkh',  hrp: 'bc', popular: true },
        { id: 'btc-segwit', name: 'Bitcoin (SegWit)',        group: 'Bitcoin', type: 'btc', path: "m/49'/0'/0'/0/{i}", addrType: 'p2sh',   hrp: 'bc', popular: true },
        { id: 'btc-native', name: 'Bitcoin (Native SegWit)', group: 'Bitcoin', type: 'btc', path: "m/84'/0'/0'/0/{i}", addrType: 'p2wpkh', hrp: 'bc', popular: true },
        { id: 'btc-tap',    name: 'Bitcoin (Taproot)',       group: 'Bitcoin', type: 'btc', path: "m/86'/0'/0'/0/{i}", addrType: 'p2tr',   hrp: 'bc' },

        // ---------------- UTXO ----------------
        { id: 'litecoin',  name: 'Litecoin',     group: 'UTXO', type: 'btc',   path: "m/84'/2'/0'/0/{i}", addrType: 'p2wpkh', hrp: 'ltc', p2pkhVer: 0x30, p2shVer: 0x32 },
        { id: 'dogecoin',  name: 'Dogecoin',     group: 'UTXO', type: 'btc',   path: "m/44'/3'/0'/0/{i}", addrType: 'p2pkh',  hrp: 'doge', p2pkhVer: 0x1e },
        { id: 'dash',      name: 'Dash',         group: 'UTXO', type: 'btc',   path: "m/44'/5'/0'/0/{i}", addrType: 'p2pkh',  hrp: 'dash', p2pkhVer: 0x4c },
        { id: 'bch',       name: 'Bitcoin Cash', group: 'UTXO', type: 'bch',   path: "m/44'/145'/0'/0/{i}" },
        { id: 'xec',       name: 'eCash',        group: 'UTXO', type: 'bch',   path: "m/44'/899'/0'/0/{i}" },
        { id: 'zec',       name: 'Zcash',        group: 'UTXO', type: 'btc',   path: "m/44'/133'/0'/0/{i}", addrType: 'p2pkh', p2pkhVer: 0x1c, p2shVer: 0x1c },
        { id: 'rvn',       name: 'Ravencoin',    group: 'UTXO', type: 'btc',   path: "m/44'/175'/0'/0/{i}", addrType: 'p2pkh', p2pkhVer: 0x3c },
        { id: 'kaspa',     name: 'Kaspa',        group: 'UTXO', type: 'kaspa', path: "m/44'/111111'/{i}'/0/0", popular: true, note: 'coin type 111111' },

        // ---------------- Ed25519 ----------------
        { id: 'solana',   name: 'Solana',        group: 'Ed25519', type: 'ed25519',  path: "m/44'/501'/{i}'/0'", popular: true },
        { id: 'near',     name: 'NEAR',          group: 'Ed25519', type: 'ed25519',  path: "m/44'/397'/{i}'" },
        { id: 'aptos',    name: 'Aptos',         group: 'Ed25519', type: 'ed25519',  path: "m/44'/637'/{i}'/0'/0'" },
        { id: 'sui',      name: 'Sui',           group: 'Ed25519', type: 'ed25519',  path: "m/44'/784'/{i}'/0'/0'" },
        { id: 'ton',      name: 'TON (V4R2)',    group: 'Ed25519', type: 'ton',      path: "m/44'/607'/{i}'", popular: true, note: 'SLIP-0010 · V4R2 · UQ' },
        { id: 'stellar',  name: 'Stellar (XLM)', group: 'Ed25519', type: 'stellar',  path: "m/44'/148'/{i}'" },
        { id: 'algorand', name: 'Algorand (ALGO)', group: 'Ed25519', type: 'algorand', path: "m/44'/283'/{i}'/0'/0'/0'" },
        { id: 'tezos',    name: 'Tezos (XTZ)',   group: 'Ed25519', type: 'tezos',    path: "m/44'/1729'/{i}'/0'" },
        { id: 'hedera',   name: 'Hedera (HBAR)', group: 'Ed25519', type: 'hedera',   path: "m/44'/3030'/{i}'/0'/0'" },
        { id: 'flow',     name: 'Flow',          group: 'Ed25519', type: 'ed25519',  path: "m/44'/539'/{i}'/0'/0'" },
        { id: 'monero',   name: 'Monero (XMR)',  group: 'Ed25519', type: 'monero',   popular: true, note: 'spend + view keys' },
        { id: 'polkadot', name: 'Polkadot (DOT)',group: 'Ed25519', type: 'substrate', path: "m/44'/354'/{i}'/0'/0'", popular: true },
        { id: 'kusama',   name: 'Kusama (KSM)',  group: 'Ed25519', type: 'substrate', path: "m/44'/434'/{i}'/0'/0'" },

        // ---------------- Cardano / Starknet ----------------
        { id: 'cardano',  name: 'Cardano (ADA)', group: 'Cardano',  type: 'cardano',  path: "m/1852'/1815'/{i}'/0/0", popular: true, note: 'CIP-1852' },
        { id: 'starknet', name: 'Starknet',      group: 'Starknet', type: 'starknet', path: "m/44'/9004'/0'/0/{i}", popular: true, note: 'Cairo VM' },

        // ---------------- Cosmos ----------------
        { id: 'cosmos',      name: 'Cosmos Hub', group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'cosmos', popular: true },
        { id: 'osmosis',     name: 'Osmosis',    group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'osmo' },
        { id: 'celestia',    name: 'Celestia',   group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'celestia' },
        { id: 'juno',        name: 'Juno',       group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'juno' },
        { id: 'secret',      name: 'Secret',     group: 'Cosmos', type: 'cosmos', path: "m/44'/529'/0'/0/{i}", hrp: 'secret' },
        { id: 'kujira',      name: 'Kujira',     group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'kujira' },
        { id: 'akash',       name: 'Akash',      group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'akash' },
        { id: 'stargaze',    name: 'Stargaze',   group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'stars' },
        { id: 'persistence', name: 'Persistence',group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'persistence' },
        { id: 'noble',       name: 'Noble',      group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'noble' },
        { id: 'dymension',   name: 'Dymension',  group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'dym' },
        { id: 'saga',        name: 'Saga',       group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'saga' },
        { id: 'sei',         name: 'Sei (Native)', group: 'Cosmos', type: 'cosmos', path: "m/44'/118'/0'/0/{i}", hrp: 'sei' },
        { id: 'thorchain',   name: 'THORChain',  group: 'Cosmos', type: 'cosmos', path: "m/44'/931'/0'/0/{i}", hrp: 'thor' },
        { id: 'injective',   name: 'Injective (Cosmos)', group: 'Cosmos', type: 'injective', path: "m/44'/60'/0'/0/{i}", hrp: 'inj', popular: true, note: 'eth_secp256k1 → inj1' },

        // ---------------- Move / прочее ----------------
        { id: 'movement', name: 'Movement', group: 'Move', type: 'evm', sameAs: 'ethereum' },
        { id: 'xrp',      name: 'XRP Ledger', group: 'Other', type: 'xrp',   path: "m/44'/144'/0'/0/{i}", popular: true },
        { id: 'tron',     name: 'Tron',       group: 'Other', type: 'tron',  path: "m/44'/195'/0'/0/{i}" },
        { id: 'waves',    name: 'Waves',      group: 'Other', type: 'waves', path: "m/44'/5741564'/{i}'/0'/0'" }
    ];

    /// @dev Обозначение токенов и фирменные данные. Ключ — id сети.
    ///      standard показывается рядом с сетью (как просил заказчик).
    var META = {
        ethereum:   { ticker: 'ETH',  standard: 'ERC-20',  color: '#627EEA', slip44: 60 },
        polygon:    { ticker: 'POL',  standard: 'ERC-20',  color: '#8247E5', slip44: 60 },
        bsc:        { ticker: 'BNB',  standard: 'BEP-20',  color: '#F0B90B', slip44: 60 },
        arbitrum:   { ticker: 'ETH',  standard: 'ERC-20',  color: '#2D374B', slip44: 60 },
        optimism:   { ticker: 'ETH',  standard: 'ERC-20',  color: '#FF0420', slip44: 60 },
        base:       { ticker: 'ETH',  standard: 'ERC-20',  color: '#0052FF', slip44: 60 },
        avalanche:  { ticker: 'AVAX', standard: 'ERC-20',  color: '#E84142', slip44: 9000 },
        fantom:     { ticker: 'S',    standard: 'ERC-20',  color: '#1969FF', slip44: 1007 },
        gnosis:     { ticker: 'xDAI', standard: 'ERC-20',  color: '#04795B', slip44: 700 },
        celo:       { ticker: 'CELO', standard: 'ERC-20',  color: '#FCFF52', slip44: 52752 },
        blast:      { ticker: 'ETH',  standard: 'ERC-20',  color: '#FCFC03', slip44: 60 },
        linea:      { ticker: 'ETH',  standard: 'ERC-20',  color: '#61DFFF', slip44: 60 },
        mantle:     { ticker: 'MNT',  standard: 'ERC-20',  color: '#000000', slip44: 60 },
        scroll:     { ticker: 'ETH',  standard: 'ERC-20',  color: '#FFEEDA', slip44: 60 },
        zksync:     { ticker: 'ETH',  standard: 'ERC-20',  color: '#8C8DFC', slip44: 60 },
        mode:       { ticker: 'ETH',  standard: 'ERC-20',  color: '#DFFE00', slip44: 60 },
        zora:       { ticker: 'ETH',  standard: 'ERC-20',  color: '#000000', slip44: 60 },
        taiko:      { ticker: 'ETH',  standard: 'ERC-20',  color: '#E81899', slip44: 60 },
        manta:      { ticker: 'ETH',  standard: 'ERC-20',  color: '#0AC5C3', slip44: 60 },
        metis:      { ticker: 'METIS',standard: 'ERC-20',  color: '#00DACC', slip44: 60 },
        hyperliquid:{ ticker: 'HYPE', standard: 'ERC-20',  color: '#97FCE4', slip44: 60 },
        robinhood:  { ticker: 'ETH',  standard: 'ERC-20',  color: '#00C805', slip44: 60 },
        berachain:  { ticker: 'BERA', standard: 'ERC-20',  color: '#FF6B00', slip44: 60 },
        monad:      { ticker: 'MON',  standard: 'ERC-20',  color: '#836EF9', slip44: 60 },
        kava:       { ticker: 'KAVA', standard: 'ERC-20',  color: '#FF564F', slip44: 459 },
        moonbeam:   { ticker: 'GLMR', standard: 'ERC-20',  color: '#53CBC9', slip44: 1284 },
        moonriver:  { ticker: 'MOVR', standard: 'ERC-20',  color: '#53CBC9', slip44: 1285 },
        cronos:     { ticker: 'CRO',  standard: 'ERC-20',  color: '#002D74', slip44: 394 },
        pulsechain: { ticker: 'PLS',  standard: 'ERC-20',  color: '#00A3FF', slip44: 60 },
        coredao:    { ticker: 'CORE', standard: 'ERC-20',  color: '#FF9500', slip44: 60 },
        flare:      { ticker: 'FLR',  standard: 'ERC-20',  color: '#E62058', slip44: 60 },
        songbird:   { ticker: 'SGB',  standard: 'ERC-20',  color: '#E62058', slip44: 60 },
        kaia:       { ticker: 'KAIA', standard: 'ERC-20',  color: '#00C2B3', slip44: 8217 },
        ronin:      { ticker: 'RON',  standard: 'ERC-20',  color: '#1273EA', slip44: 60 },
        beam:       { ticker: 'BEAM', standard: 'ERC-20',  color: '#00FFA3', slip44: 60 },
        immutable:  { ticker: 'IMX',  standard: 'ERC-20',  color: '#0D0D0D', slip44: 60 },

        'btc-legacy': { ticker: 'BTC', standard: 'P2PKH',  color: '#F7931A', slip44: 0 },
        'btc-segwit': { ticker: 'BTC', standard: 'P2SH',   color: '#F7931A', slip44: 0 },
        'btc-native': { ticker: 'BTC', standard: 'P2WPKH', color: '#F7931A', slip44: 0 },
        'btc-tap':    { ticker: 'BTC', standard: 'P2TR',   color: '#F7931A', slip44: 0 },

        litecoin: { ticker: 'LTC',  standard: 'P2WPKH', color: '#345D9D', slip44: 2 },
        dogecoin: { ticker: 'DOGE', standard: 'P2PKH',  color: '#C2A633', slip44: 3 },
        dash:     { ticker: 'DASH', standard: 'P2PKH',  color: '#008CE7', slip44: 5 },
        bch:      { ticker: 'BCH',  standard: 'CashAddr', color: '#8DC351', slip44: 145 },
        xec:      { ticker: 'XEC',  standard: 'CashAddr', color: '#0073E6', slip44: 899 },
        zec:      { ticker: 'ZEC',  standard: 'P2PKH',  color: '#F4B728', slip44: 133 },
        rvn:      { ticker: 'RVN',  standard: 'P2PKH',  color: '#384182', slip44: 175 },
        kaspa:    { ticker: 'KAS',  standard: 'kaspa:', color: '#70C7BA', slip44: 111111 },

        solana:   { ticker: 'SOL',  standard: 'SPL',    color: '#9945FF', slip44: 501 },
        near:     { ticker: 'NEAR', standard: 'NEP-141', color: '#000000', slip44: 397 },
        aptos:    { ticker: 'APT',  standard: 'FA',     color: '#000000', slip44: 637 },
        sui:      { ticker: 'SUI',  standard: 'Coin',   color: '#4DA2FF', slip44: 784 },
        ton:      { ticker: 'TON',  standard: 'Jetton', color: '#0098EA', slip44: 607 },
        stellar:  { ticker: 'XLM',  standard: 'SEP-41', color: '#7D00FF', slip44: 148 },
        algorand: { ticker: 'ALGO', standard: 'ASA',    color: '#000000', slip44: 283 },
        tezos:    { ticker: 'XTZ',  standard: 'FA2',    color: '#2C7DF7', slip44: 1729 },
        hedera:   { ticker: 'HBAR', standard: 'HTS',    color: '#000000', slip44: 3030 },
        flow:     { ticker: 'FLOW', standard: 'FT',     color: '#00EF8B', slip44: 539 },
        monero:   { ticker: 'XMR',  standard: 'XMR',    color: '#FF6600', slip44: 128 },
        polkadot: { ticker: 'DOT',  standard: 'DOT',    color: '#E6007A', slip44: 354 },
        kusama:   { ticker: 'KSM',  standard: 'KSM',    color: '#000000', slip44: 434 },

        cardano:  { ticker: 'ADA',  standard: 'CIP-14', color: '#0033AD', slip44: 1815 },
        starknet: { ticker: 'STRK', standard: 'ERC-20', color: '#0C0C4F', slip44: 9004 },

        cosmos:      { ticker: 'ATOM', standard: 'CW-20', color: '#2E3148', slip44: 118 },
        osmosis:     { ticker: 'OSMO', standard: 'CW-20', color: '#5E12A0', slip44: 118 },
        celestia:    { ticker: 'TIA',  standard: 'CW-20', color: '#7B2BF9', slip44: 118 },
        juno:        { ticker: 'JUNO', standard: 'CW-20', color: '#F0827D', slip44: 118 },
        secret:      { ticker: 'SCRT', standard: 'SNIP-20', color: '#000000', slip44: 529 },
        kujira:      { ticker: 'KUJI', standard: 'CW-20', color: '#E53935', slip44: 118 },
        akash:       { ticker: 'AKT',  standard: 'CW-20', color: '#FF4141', slip44: 118 },
        stargaze:    { ticker: 'STARS',standard: 'CW-20', color: '#BCC1FB', slip44: 118 },
        persistence: { ticker: 'XPRT', standard: 'CW-20', color: '#E50915', slip44: 118 },
        noble:       { ticker: 'USDC', standard: 'CW-20', color: '#000000', slip44: 118 },
        dymension:   { ticker: 'DYM',  standard: 'CW-20', color: '#DD00FF', slip44: 118 },
        saga:        { ticker: 'SAGA', standard: 'CW-20', color: '#FF007A', slip44: 118 },
        sei:         { ticker: 'SEI',  standard: 'CW-20', color: '#9E1F19', slip44: 118 },
        thorchain:   { ticker: 'RUNE', standard: 'CW-20', color: '#33FF99', slip44: 931 },
        injective:   { ticker: 'INJ',  standard: 'ERC-20', color: '#00F2FE', slip44: 60 },

        movement: { ticker: 'MOVE', standard: 'Move',   color: '#000000', slip44: 60 },
        xrp:      { ticker: 'XRP',  standard: 'XRP',    color: '#23292F', slip44: 144 },
        tron:     { ticker: 'TRX',  standard: 'TRC-20', color: '#EF0027', slip44: 195 },
        waves:    { ticker: 'WAVES',standard: 'WAVES',  color: '#0055FF', slip44: 5741564 }
    };

    // Собираем полный реестр: данные генератора + наши метаданные.
    var ALL = LIST.map(function (n) {
        var m = META[n.id] || {};
        return {
            id: n.id, name: n.name, group: n.group, type: n.type,
            path: n.path || null, sameAs: n.sameAs || null,
            addrType: n.addrType || null, hrp: n.hrp || null,
            p2pkhVer: (n.p2pkhVer === undefined ? null : n.p2pkhVer),
            p2shVer: (n.p2shVer === undefined ? null : n.p2shVer),
            popular: !!n.popular, note: n.note || '',
            ticker: m.ticker || '', standard: m.standard || '', color: m.color || '#5b6672',
            slip44: (m.slip44 === undefined ? null : m.slip44)
        };
    });

    var BY_ID = {};
    ALL.forEach(function (n) { BY_ID[n.id] = n; });

    var GROUPS = [];
    ALL.forEach(function (n) { if (GROUPS.indexOf(n.group) < 0) GROUPS.push(n.group); });

    return {
        ALL: ALL,
        GROUPS: GROUPS,
        count: function () { return ALL.length; },
        get: function (id) { return BY_ID[id] || null; },
        byGroup: function () {
            return GROUPS.map(function (g) {
                return { group: g, items: ALL.filter(function (n) { return n.group === g; }) };
            });
        },
        popular: function () { return ALL.filter(function (n) { return n.popular; }); },
        /// @dev Путь для конкретного номера адреса: {i} -> номер.
        pathFor: function (id, index) {
            var n = BY_ID[id];
            if (!n || !n.path) return null;
            return n.path.replace('{i}', String(index || 0));
        },
        /// @dev Сети, у которых адрес совпадает с данной (например, все EVM).
        sameAddress: function (id) {
            var n = BY_ID[id];
            if (!n) return [];
            var base = n.sameAs || n.id;
            return ALL.filter(function (x) { return (x.sameAs || x.id) === base; }).map(function (x) { return x.id; });
        }
    };
});