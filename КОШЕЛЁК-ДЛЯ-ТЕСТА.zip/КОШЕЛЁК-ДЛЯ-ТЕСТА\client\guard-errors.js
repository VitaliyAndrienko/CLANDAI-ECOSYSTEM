/* =========================================================================
   guard-errors.js — АВТОГЕНЕРАЦИЯ из ABI, не править руками.
   Обновить: npm run build && node tools/gen-error-map.js

   Зачем: контракт возвращает 4 байта селектора. Пользователю нужно
   человеческое объяснение ЧТО именно запрещено и почему.
   ========================================================================= */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.GuardErrors = factory();
})(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    /// @dev селектор -> { name, sig, args }
    var ERRORS = {
        '0x01071102': { name: 'UsdLimitExceeded', sig: 'UsdLimitExceeded()', args: [] },
        '0x062d80f8': { name: 'BadSignatureValue', sig: 'BadSignatureValue()', args: [] },
        '0x0790f4d1': { name: 'TooLateToCancel', sig: 'TooLateToCancel()', args: [] },
        '0x07cc321c': { name: 'BadConfig', sig: 'BadConfig()', args: [] },
        '0x0c7cb579': { name: 'MigratedOutError', sig: 'MigratedOutError()', args: [] },
        '0x0dc149f0': { name: 'AlreadyInitialized', sig: 'AlreadyInitialized()', args: [] },
        '0x1140cf7f': { name: 'PriceNotConfigured', sig: 'PriceNotConfigured()', args: [] },
        '0x1ab7da6b': { name: 'DeadlineExpired', sig: 'DeadlineExpired()', args: [] },
        '0x1bde18f7': { name: 'GuardReentrancyError', sig: 'GuardReentrancyError()', args: [] },
        '0x1f6d5aef': { name: 'NonceUsed', sig: 'NonceUsed()', args: [] },
        '0x1fd05a4a': { name: 'SessionExpired', sig: 'SessionExpired()', args: [] },
        '0x2171b80b': { name: 'BadPlan', sig: 'BadPlan()', args: [] },
        '0x220fb382': { name: 'ContractBlocked', sig: 'ContractBlocked()', args: [] },
        '0x28771d91': { name: 'PriceStale', sig: 'PriceStale()', args: [] },
        '0x30044a2f': { name: 'SelfCallForbidden', sig: 'SelfCallForbidden()', args: [] },
        '0x30cd7471': { name: 'NotOwner', sig: 'NotOwner()', args: [] },
        '0x324b3e7f': { name: 'WalletNotRegistered', sig: 'WalletNotRegistered()', args: [] },
        '0x3261c792': { name: 'LimitExceeded', sig: 'LimitExceeded()', args: [] },
        '0x32da96a3': { name: 'TokenNotApproved', sig: 'TokenNotApproved()', args: [] },
        '0x366fd453': { name: 'WrongPermit2', sig: 'WrongPermit2()', args: [] },
        '0x3708b32e': { name: 'NoMigration', sig: 'NoMigration()', args: [] },
        '0x372a2b05': { name: 'BadNickname', sig: 'BadNickname()', args: [] },
        '0x38e92d23': { name: 'WalletListLimitExceeded', sig: 'WalletListLimitExceeded()', args: [] },
        '0x3e3f8f73': { name: 'ApproveFailed', sig: 'ApproveFailed()', args: [] },
        '0x3f4d6053': { name: 'HashMismatch', sig: 'HashMismatch()', args: [] },
        '0x4083609a': { name: 'WalletPaused', sig: 'WalletPaused()', args: [] },
        '0x441dfbd6': { name: 'NotSet', sig: 'NotSet()', args: [] },
        '0x4612ac2a': { name: 'SessionTargetNotAllowed', sig: 'SessionTargetNotAllowed()', args: [] },
        '0x4797549d': { name: 'TransferBudgetNotSet', sig: 'TransferBudgetNotSet()', args: [] },
        '0x49dfdae1': { name: 'SessionBudgetExceeded', sig: 'SessionBudgetExceeded()', args: [] },
        '0x4abc75c5': { name: 'EmergencyKeyNotSet', sig: 'EmergencyKeyNotSet()', args: [] },
        '0x4e4257c4': { name: 'NativeLimitExceeded', sig: 'NativeLimitExceeded()', args: [] },
        '0x59fa4a93': { name: 'ThresholdNotMet', sig: 'ThresholdNotMet()', args: [] },
        '0x5c0e5add': { name: 'PlanDisabled', sig: 'PlanDisabled()', args: [] },
        '0x62f1e405': { name: 'NicknameNotRegistered', sig: 'NicknameNotRegistered()', args: [] },
        '0x669567ea': { name: 'ZeroBalance', sig: 'ZeroBalance()', args: [] },
        '0x6a8bde08': { name: 'NotMigrationHub', sig: 'NotMigrationHub()', args: [] },
        '0x6c3de550': { name: 'BadOwnerSet', sig: 'BadOwnerSet()', args: [] },
        '0x6c4ae96c': { name: 'BadCode', sig: 'BadCode()', args: [] },
        '0x6f7c43f1': { name: 'NotContract', sig: 'NotContract()', args: [] },
        '0x73532ea8': { name: 'NotGuard', sig: 'NotGuard()', args: [] },
        '0x792279f3': { name: 'WalletAlreadyRegistered', sig: 'WalletAlreadyRegistered()', args: [] },
        '0x7a743aad': { name: 'BalanceShareExceeded', sig: 'BalanceShareExceeded()', args: [] },
        '0x7bbfb6fe': { name: 'WindowExpired', sig: 'WindowExpired()', args: [] },
        '0x7d857b67': { name: 'TimelockActive', sig: 'TimelockActive()', args: [] },
        '0x7ec97525': { name: 'NicknameTaken', sig: 'NicknameTaken()', args: [] },
        '0x8044bb33': { name: 'DuplicateSigner', sig: 'DuplicateSigner()', args: [] },
        '0x86c0e541': { name: 'NoRecoveryTarget', sig: 'NoRecoveryTarget()', args: [] },
        '0x87138d5c': { name: 'NotInitialized', sig: 'NotInitialized()', args: [] },
        '0x87e497e5': { name: 'TooManySignatures', sig: 'TooManySignatures()', args: [] },
        '0x88a9dff1': { name: 'TokenBlacklisted', sig: 'TokenBlacklisted()', args: [] },
        '0x8c558476': { name: 'ColdOwnerRequired', sig: 'ColdOwnerRequired()', args: [] },
        '0x8e78f0cb': { name: 'WrongStatus', sig: 'WrongStatus()', args: [] },
        '0x94d97a7a': { name: 'SessionWrongWallet', sig: 'SessionWrongWallet()', args: [] },
        '0x9c5bebca': { name: 'PolicyExpired', sig: 'PolicyExpired()', args: [] },
        '0x9de97418': { name: 'NotHub', sig: 'NotHub()', args: [] },
        '0xa1839cde': { name: 'SessionTokenNotAllowed', sig: 'SessionTokenNotAllowed()', args: [] },
        '0xa5fa8d2b': { name: 'CallFailed', sig: 'CallFailed(bytes)', args: ['bytes'] },
        '0xa6add803': { name: 'RecipientBlacklisted', sig: 'RecipientBlacklisted()', args: [] },
        '0xa741a045': { name: 'AlreadySet', sig: 'AlreadySet()', args: [] },
        '0xaac1fcc6': { name: 'EmptyCommitment', sig: 'EmptyCommitment()', args: [] },
        '0xad764ce6': { name: 'SnapshotMismatch', sig: 'SnapshotMismatch()', args: [] },
        '0xadd19186': { name: 'StrictKeyNotSet', sig: 'StrictKeyNotSet()', args: [] },
        '0xb20d7fc3': { name: 'PermissionRequired', sig: 'PermissionRequired()', args: [] },
        '0xb311c972': { name: 'ArrayLimitExceeded', sig: 'ArrayLimitExceeded()', args: [] },
        '0xb472696e': { name: 'SessionNotSet', sig: 'SessionNotSet()', args: [] },
        '0xb982e3ad': { name: 'WrongGuard', sig: 'WrongGuard()', args: [] },
        '0xb9908b18': { name: 'PersistentApprovalForbidden', sig: 'PersistentApprovalForbidden()', args: [] },
        '0xbccdd6c6': { name: 'MigrationNotAccepted', sig: 'MigrationNotAccepted()', args: [] },
        '0xbec00580': { name: 'DeadlineInPast', sig: 'DeadlineInPast()', args: [] },
        '0xbfcd8a7c': { name: 'ContractNotWhitelisted', sig: 'ContractNotWhitelisted()', args: [] },
        '0xc06789fa': { name: 'InvalidCommitment', sig: 'InvalidCommitment()', args: [] },
        '0xc1ab61a1': { name: 'CooldownActive', sig: 'CooldownActive(uint256)', args: ['uint256'] },
        '0xc2571d09': { name: 'ActiveRecoveryExists', sig: 'ActiveRecoveryExists()', args: [] },
        '0xc64200e9': { name: 'AmountOutOfRange', sig: 'AmountOutOfRange()', args: [] },
        '0xc90cb5df': { name: 'TransferBudgetExceeded', sig: 'TransferBudgetExceeded()', args: [] },
        '0xcfbc0bc4': { name: 'SessionPerOpExceeded', sig: 'SessionPerOpExceeded()', args: [] },
        '0xd09669ee': { name: 'CancelsNotReached', sig: 'CancelsNotReached()', args: [] },
        '0xd2c661b9': { name: 'HighSValue', sig: 'HighSValue()', args: [] },
        '0xd2fa51d1': { name: 'TargetBlacklisted', sig: 'TargetBlacklisted()', args: [] },
        '0xd4c3b01a': { name: 'ExpiryOverflow', sig: 'ExpiryOverflow()', args: [] },
        '0xd5549763': { name: 'Permit2AllowanceExpired', sig: 'Permit2AllowanceExpired()', args: [] },
        '0xd5c0c7b7': { name: 'BadNewGuard', sig: 'BadNewGuard()', args: [] },
        '0xd6234725': { name: 'NotImplemented', sig: 'NotImplemented()', args: [] },
        '0xd76b2ccf': { name: 'StrictSignatureInvalid', sig: 'StrictSignatureInvalid()', args: [] },
        '0xd7bad83f': { name: 'BadSignatureLength', sig: 'BadSignatureLength()', args: [] },
        '0xd8802226': { name: 'NotPendingGuard', sig: 'NotPendingGuard()', args: [] },
        '0xd92e233d': { name: 'ZeroAddress', sig: 'ZeroAddress()', args: [] },
        '0xd9a28e5d': { name: 'MustIncrease', sig: 'MustIncrease()', args: [] },
        '0xdb3e2816': { name: 'AgentSignatureInvalid', sig: 'AgentSignatureInvalid()', args: [] },
        '0xde4168ba': { name: 'WrongState', sig: 'WrongState()', args: [] },
        '0xe269f6ad': { name: 'InvalidEmergencySignature', sig: 'InvalidEmergencySignature()', args: [] },
        '0xe3ec1017': { name: 'NoPendingGuard', sig: 'NoPendingGuard()', args: [] },
        '0xe5c48ac5': { name: 'ZeroSigner', sig: 'ZeroSigner()', args: [] },
        '0xe6e67656': { name: 'RecoveryRecipientBlacklisted', sig: 'RecoveryRecipientBlacklisted()', args: [] },
        '0xe6fb8bfa': { name: 'NotPausedWallet', sig: 'NotPausedWallet()', args: [] },
        '0xe727c691': { name: 'Permit2AllowanceInsufficient', sig: 'Permit2AllowanceInsufficient()', args: [] },
        '0xe755491f': { name: 'BadGuard', sig: 'BadGuard()', args: [] },
        '0xea8e4eb5': { name: 'NotAuthorized', sig: 'NotAuthorized()', args: [] },
        '0xed3ba6a6': { name: 'Reentrant', sig: 'Reentrant()', args: [] },
        '0xeea91ff8': { name: 'NotAnOwner', sig: 'NotAnOwner()', args: [] },
        '0xf4b3b1bc': { name: 'NativeTransferFailed', sig: 'NativeTransferFailed()', args: [] },
        '0xf52ef952': { name: 'TreasuryUnavailable', sig: 'TreasuryUnavailable()', args: [] },
        '0xf83e0d84': { name: 'EmptyCallData', sig: 'EmptyCallData()', args: [] },
        '0xfc0ee502': { name: 'MaxCancelsReached', sig: 'MaxCancelsReached()', args: [] },
        '0xfd09c43f': { name: 'NotReadyYet', sig: 'NotReadyYet()', args: [] },
    };

    /// @dev Слово i из АРГУМЕНТОВ revert-данных. Селектор занимает 8
    ///      hex-символов после '0x' — его обязательно пропускать, иначе все
    ///      слова читаются со сдвигом (на этом падала расшифровка Panic).
    var SELECTOR_LEN = 8;

    function wordAt(data, i) {
        var start = 2 + SELECTOR_LEN + i * 64;
        var h = data.slice(start, start + 64);
        return h.length === 64 ? h : null;
    }

    /// @dev Разбор одного аргумента. Динамические типы (bytes/string) лежат
    ///      как offset -> length -> data. Показывать сырое слово нельзя: это
    ///      вводит в заблуждение (проверено — декодер врал на CallFailed).
    ///      Смещения считаются от начала БЛОКА АРГУМЕНТОВ, то есть после
    ///      селектора, поэтому везде учтён SELECTOR_LEN.
    function decodeArg(type, data, i, word) {
        if (word === null) return null;
        if (type === 'address') return '0x' + word.slice(24);
        if (type === 'bool') return BigInt('0x' + word) !== 0n;
        if (type === 'bytes32') return '0x' + word;
        if (/^uint[0-9]*$/.test(type)) return BigInt('0x' + word).toString();
        if (type === 'bytes' || type === 'string') {
            var off = Number(BigInt('0x' + word)) * 2;
            var base = 2 + SELECTOR_LEN + off;
            var lenHex = data.slice(base, base + 64);
            if (lenHex.length !== 64) return '(нет данных)';
            var len = Number(BigInt('0x' + lenHex));
            var body = data.slice(base + 64, base + 64 + Math.min(len, 32) * 2);
            if (type === 'string') {
                var s = '';
                for (var k = 0; k < body.length; k += 2) s += String.fromCharCode(parseInt(body.substr(k, 2), 16));
                return s;
            }
            return '0x' + body + (len > 32 ? '...(' + len + ' bytes)' : '');
        }
        return '0x' + word;
    }

    /// @dev Разбор revert-данных в человеческий вид.
    ///      Возвращает { selector, name, sig, args, text } или null.
    function decode(data) {
        if (typeof data !== 'string' || data.length < 10) return null;
        var sel = data.slice(0, 10).toLowerCase();
        var e = ERRORS[sel];
        if (!e) return { selector: sel, name: null, sig: null, args: [], text: 'неизвестная ошибка ' + sel };
        var args = [];
        for (var i = 0; i < e.args.length; i++) args.push(decodeArg(e.args[i], data, i, wordAt(data, i)));
        var shown = args.map(function (a) {
            if (typeof a === 'string' && a.length === 42) return a.slice(0, 6) + '…' + a.slice(-4);
            return String(a);
        });
        return {
            selector: sel,
            name: e.name,
            sig: e.sig,
            args: args,
            text: e.name + (shown.length ? '(' + shown.join(', ') + ')' : '')
        };
    }

    /// @dev Ошибки Solidity Error(string) и Panic(uint256) — вне таблицы контрактов.
    ///      Панику полезно расшифровать: код говорит, ЧТО именно сломалось.
    var PANIC = {
        '0x01': 'assert не выполнен',
        '0x11': 'переполнение или деление на ноль',
        '0x12': 'деление на ноль',
        '0x21': 'недопустимое приведение enum',
        '0x22': 'испорчена память',
        '0x31': 'обращение к массиву вне границ',
        '0x32': 'индекс массива вне границ',
        '0x41': 'выделено слишком много памяти',
        '0x51': 'вызов несуществующей функции'
    };

    /// @dev Полное объяснение revert-данных, включая стандартные форматы.
    function explain(data) {
        if (!data || data === '0x') return 'отказ без данных';
        var sel = data.slice(0, 10).toLowerCase();
        if (sel === '0x08c379a0') return 'Error: ' + _rawString(data);
        if (sel === '0x4e487b71') {
            var w = wordAt(data, 0) || '';
            var code = '0x' + w.slice(62);
            return 'Panic(' + code + '): ' + (PANIC[code] || 'неизвестная паника');
        }
        var d = decode(data);
        return d ? d.text : 'отказ: ' + data.slice(0, 10);
    }

    function _rawString(data) {
        // Error(string): offset(32) + length(32) + data. Смещения считаются от
        // начала БЛОКА АРГУМЕНТОВ, то есть после селектора.
        try {
            var off = Number(BigInt('0x' + wordAt(data, 0))) * 2;
            var base = 2 + SELECTOR_LEN + off;
            var lenHex = data.slice(base, base + 64);
            var len = Number(BigInt('0x' + lenHex));
            var hex = data.slice(base + 64, base + 64 + len * 2);
            var s = '';
            for (var i = 0; i < hex.length; i += 2) s += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
            return s;
        } catch (e) { return '(не удалось разобрать)'; }
    }

    return { ERRORS: ERRORS, decode: decode, explain: explain, PANIC: PANIC };
});
