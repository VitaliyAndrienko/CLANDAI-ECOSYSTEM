/* =========================================================================
   app/ui/chrome.js — браузер: вкладки, адресная строка, ассистент.

   Криптографии здесь нет: кошелёк и ключи — в отдельном окне (кнопка
   КОШЕЛЁК). Ассистент общается с реестром инструментов, который живёт
   в главном процессе, поэтому подменить его лимиты со страницы нельзя.
   ========================================================================= */

'use strict';

const api = window.clandai;
const $ = (id) => document.getElementById(id);

let lastState = null;

// =====================================================================
// Вкладки
// =====================================================================

function renderTabs(s) {
    const host = $('tabs');
    host.innerHTML = '';
    (s.tabs || []).forEach(t => {
        const el = document.createElement('div');
        el.className = 'tab' + (t.id === s.activeId ? ' active' : '');
        el.title = t.url || '';
        const fav = document.createElement('span'); fav.className = 'fav';
        const name = document.createElement('span'); name.className = 'name';
        name.textContent = (t.title || t.url || 'Новая вкладка').slice(0, 40);
        const x = document.createElement('span'); x.className = 'x'; x.textContent = '✕';
        el.append(fav, name, x);
        el.onclick = (e) => {
            if (e.target === x) { api.browser.closeTab(t.id); return; }
            api.browser.activateTab(t.id);
        };
        host.appendChild(el);
    });
    const add = document.createElement('div');
    add.className = 'tab-add';
    add.textContent = '+';
    add.onclick = () => api.browser.newTab();
    host.appendChild(add);
}

function applyState(s) {
    lastState = s;
    renderTabs(s);
    const active = (s.tabs || []).find(t => t.id === s.activeId);
    if (active && document.activeElement !== $('url')) $('url').value = active.url || '';
    $('url-badge').textContent = s.loading ? 'loading' : 'sandboxed';
    $('nav-back').classList.toggle('dim', !s.canGoBack);
    $('nav-fwd').classList.toggle('dim', !s.canGoForward);
}

$('url').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    const v = e.target.value.trim();
    if (!v) return;
    api.browser.navigate(v);
    e.target.blur();
});
$('url').addEventListener('focus', (e) => e.target.select());
$('nav-back').onclick = () => api.browser.back();
$('nav-fwd').onclick = () => api.browser.forward();
$('nav-reload').onclick = () => api.browser.reload();
$('win-min').onclick = () => api.win.minimize();
$('win-max').onclick = () => api.win.maximize();
$('win-close').onclick = () => api.win.close();

// =====================================================================
// Боковые окна и панель
// =====================================================================

$('keys-btn').onclick = () => api.walletWin.open();
$('bank-btn').onclick = () => api.bank.open();

let panelWidth = 0;
function setPanel(open) {
    $('panel').hidden = !open;
    panelWidth = open ? 360 : 0;
    if (api.browser.setPanel) api.browser.setPanel(panelWidth);
    $('ai-btn').classList.toggle('on', open);
}
$('ai-btn').onclick = () => {
    const open = $('panel').hidden;
    setPanel(open);
    if (open) loadTools();
};
$('panel-close').onclick = () => setPanel(false);

// =====================================================================
// Ассистент
// =====================================================================

function bubble(text, mine) {
    const host = $('chat-messages');
    const wrap = document.createElement('div');
    wrap.className = 'msg' + (mine ? ' me' : '');
    const b = document.createElement('div');
    b.className = 'bubble';
    b.textContent = text;
    wrap.appendChild(b);
    host.appendChild(wrap);
    host.scrollTop = host.scrollHeight;
    return b;
}

function thinking(on) {
    $('ai-entity').classList.toggle('thinking', on);
    $('ai-label').classList.toggle('thinking', on);
    $('ai-label').textContent = on ? 'ДУМАЮ…' : 'CLANDAI AGENT';
}

let toolsLoaded = false;

async function loadTools() {
    if (toolsLoaded) return;
    const r = await api.agent.manifest();
    if (!r.ok) return;
    toolsLoaded = true;
    const host = $('ai-tools');
    host.innerHTML = '';
    (r.schema || []).forEach(fn => {
        const card = document.createElement('div');
        card.className = 'tool-card';
        card.title = fn.function.description;
        const nm = document.createElement('span');
        nm.className = 'nm';
        nm.textContent = fn.function.name.replace('wallet_', '');
        const cat = document.createElement('span');
        const isWrite = /execute/.test(fn.function.name);
        cat.className = 'cat' + (isWrite ? ' write' : '');
        cat.textContent = isWrite ? 'деньги' : 'чтение';
        card.append(nm, cat);
        host.appendChild(card);
    });
}

/// @dev Понимаем простые команды и отвечаем ДАННЫМИ из настоящего реестра
///      инструментов. Чего не умеем — говорим прямо, а не выдумываем.
/// @dev [БЛОК] КАРТОЧКА ПРЕДЛОЖЕНИЯ: агент ничего не выполняет сам.
///      Пользователь видит, что предлагается, и подтверждает нажатием.
function renderProposal(p) {
    const host = $('chat-messages');
    if (!host || !p) return;
    const el = document.createElement('div');
    el.className = 'bubble proposal';
    el.style.borderColor = 'rgba(94,234,212,.45)';
    const txt = document.createElement('div');
    txt.textContent = p.text || (p.kind === 'ui.open' ? 'Открыть раздел?' : 'Выполнить действие?');
    el.appendChild(txt);
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:8px;margin-top:8px';
    const yes = document.createElement('button');
    yes.textContent = 'Выполнить';
    yes.style.cssText = 'flex:1;padding:7px;border-radius:9px;cursor:pointer;border:1px solid var(--accent);' +
        'background:var(--accent);color:#06231f;font:inherit;font-size:11px';
    const no = document.createElement('button');
    no.textContent = 'Отмена';
    no.style.cssText = 'flex:1;padding:7px;border-radius:9px;cursor:pointer;border:1px solid var(--border-2);' +
        'background:transparent;color:var(--text-dim);font:inherit;font-size:11px';
    yes.onclick = async () => {
        yes.disabled = no.disabled = true;
        const r = await window.clandai.agent.applyProposal(p);
        yes.textContent = (r && r.ok) ? '\u2713 Выполнено' : '\u2717 Отказ';
        if (!(r && r.ok)) yes.textContent += ': ' + ((r && r.error) || '');
    };
    no.onclick = () => { yes.disabled = no.disabled = true; no.textContent = 'Отменено'; };
    row.appendChild(yes); row.appendChild(no);
    el.appendChild(row);
    host.appendChild(el);
    host.scrollTop = host.scrollHeight;
}

async function answer(text) {
    const t = text.toLowerCase();

    // --- справочники (только чтение) ---
    if (t.indexOf('сет') >= 0 || t.indexOf('network') >= 0) {
        const r = await api.agent.invoke('wallet_get_networks', {});
        if (r && r.ok && r.result && r.result.count) {
            const list = r.result.networks.slice(0, 6)
                .map(n => n.ticker + ' \u00b7 ' + n.standard).join('\n');
            return 'Поддерживается сетей: ' + r.result.count + '\n' + list + '\n\u2026';
        }
        return JSON.stringify(r && r.error ? r.error : r, null, 2);
    }
    if (t.indexOf('монет') >= 0 || t.indexOf('asset') >= 0) {
        const r = await api.agent.invoke('wallet_get_supported_assets', {});
        if (r && r.ok && r.result) {
            return 'Первыми: ' + r.result.promoted.map(x => x.symbol).join(', ') +
                   '\nОбычные: ' + r.result.common.map(x => x.symbol).join(', ');
        }
        return JSON.stringify(r && r.error ? r.error : r, null, 2);
    }

    // --- предложения: агент просит, пользователь подтверждает ---
    const secMatch = text.match(/(?:открой|открыть)\s+([a-zA-Zа-яА-Я\-]+)/);
    if (secMatch) {
        const map = { 'своп': 'swap', 'swap': 'swap', 'перенос': 'hotcold', 'вайтлист': 'whitelist',
                      'белый': 'whitelist', 'блэклист': 'blacklist', 'чёрный': 'blacklist', 'черный': 'blacklist',
                      'сессии': 'sessions', 'подписки': 'subs', 'квантов': 'quantum',
                      'токены': 'tokens', 'меню': 'menu', 'банк': 'bank' };
        const word = secMatch[1].toLowerCase();
        const key = map[word] || (['swap','hotcold','whitelist','blacklist','sessions','subs',
                                   'quantum','tokens','menu','bank'].indexOf(word) >= 0 ? word : null);
        if (key) {
            const r = await api.agent.invoke('wallet_propose_ui', { section: key });
            if (r && r.ok && r.result && r.result.proposal) {
                renderProposal(r.result.proposal);
                return 'Открыть раздел? Подтвердите нажатием.';
            }
            return JSON.stringify(r && r.error ? r.error : r, null, 2);
        }
    }
    const addrMatch = text.match(/0x[0-9a-fA-F]{40}/);
    if (addrMatch && (t.indexOf('бел') >= 0 || t.indexOf('whitelist') >= 0 ||
                      t.indexOf('чёрн') >= 0 || t.indexOf('черн') >= 0 || t.indexOf('blacklist') >= 0)) {
        const isWl = (t.indexOf('бел') >= 0 || t.indexOf('whitelist') >= 0);
        const r = await api.agent.invoke('wallet_propose_action',
            { action: isWl ? 'add-whitelist' : 'add-blacklist', address: addrMatch[0] });
        if (r && r.ok && r.result && r.result.proposal) {
            renderProposal(r.result.proposal);
            return 'Добавить адрес? Подтвердите нажатием.';
        }
        return JSON.stringify(r && r.error ? r.error : r, null, 2);
    }

    if (t.indexOf('лимит') >= 0 || t.indexOf('limit') >= 0) {
        const r = await api.agent.invoke('wallet_get_limits', {});
        return JSON.stringify(r.ok ? r.result : { error: r.error }, null, 2);
    }
    if (t.indexOf('баланс') >= 0 || t.indexOf('balance') >= 0) {
        const r = await api.agent.invoke('wallet_get_balance', {});
        return JSON.stringify(r.ok ? r.result : { error: r.error }, null, 2);
    }
    if (t.indexOf('привет') >= 0 || t.indexOf('здравств') >= 0) {
        return 'Привет! Я ассистент CLANDAI.\nПока умею: «лимиты», «баланс».\nКошелёк — кнопка КОШЕЛЁК, банк — кнопка БАНК.';
    }
    if (t.indexOf('кошел') >= 0) {
        return 'Кошелёк открывается кнопкой КОШЕЛЁК. Там ваша сид-фраза, части для восстановления и адрес.';
    }
    if (t.indexOf('банк') >= 0) {
        return 'Банк открывается кнопкой БАНК. Пока он не подключён к сети.';
    }
    return 'Пока я понимаю только: «лимиты», «баланс».\nОстальные команды появятся, когда будут готовы операции.';
}

async function send() {
    const input = $('chat-input');
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    bubble(text, true);
    thinking(true);
    const b = bubble('…', false);
    try {
        const out = await answer(text);
        b.textContent = out;
    } catch (e) {
        b.textContent = 'Не получилось: ' + (e.message || e);
    } finally {
        thinking(false);
        $('chat-messages').scrollTop = $('chat-messages').scrollHeight;
    }
}

$('chat-send').onclick = send;
$('chat-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') send(); });

api.browser.onState(applyState);
setPanel(false);

// =====================================================================
// Самопроверка браузера
// =====================================================================

window.__clandaiSelfTest = async function () {
    const problems = [];

    if (!api) problems.push('нет clandai');
    const need = { browser: api && api.browser, win: api && api.win, walletWin: api && api.walletWin,
                   bank: api && api.bank, agent: api && api.agent };
    Object.keys(need).forEach(k => { if (!need[k]) problems.push('нет clandai.' + k); });

    const methods = [
        [api.browser, ['newTab', 'closeTab', 'activateTab', 'navigate', 'back', 'forward', 'reload', 'onState']],
        [api.win, ['minimize', 'maximize', 'close']],
        [api.walletWin, ['open', 'close']],
        [api.bank, ['open', 'close']],
        [api.agent, ['manifest', 'invoke']]
    ];
    methods.forEach(pair => {
        if (!pair[0]) return;
        pair[1].forEach(n => { if (typeof pair[0][n] !== 'function') problems.push('нет метода ' + n); });
    });

    ['tabs', 'url', 'panel', 'stage', 'keys-btn', 'bank-btn', 'ai-btn',
     'chat-input', 'chat-send', 'chat-messages', 'ai-entity', 'ai-label', 'ai-tools']
        .forEach(id => { if (!$(id)) problems.push('нет элемента #' + id); });

    // название СЛИТНО и серым
    const brand = document.querySelector('.brand span');
    if (!brand || brand.textContent !== 'CLANDAI') {
        problems.push('в шапке не CLANDAI: ' + (brand ? brand.textContent : 'нет'));
    } else {
        const col = getComputedStyle(brand).color;
        const muted = getComputedStyle(document.documentElement).getPropertyValue('--muted').trim();
        if (col === 'rgb(0, 255, 170)') problems.push('название не серое: ' + col);
    }
    const logo = document.querySelector('.brand img');
    if (!logo || !/png/.test(logo.getAttribute('src') || '')) problems.push('нет логотипа в шапке');

    // глаза агента на месте (по ним видно, что вид из дизайна применён)
    if (document.querySelectorAll('.ai-eye').length !== 2) problems.push('у агента не два глаза');
    if (document.querySelectorAll('.ai-ring').length !== 3) problems.push('у агента не три кольца');

    // панель открывается и закрывается
    try {
        setPanel(true);
        if ($('panel').hidden) problems.push('панель не открылась');
        setPanel(false);
        if (!$('panel').hidden) problems.push('панель не закрылась');
    } catch (e) { problems.push('панель: ' + e.message); }

    // чат отвечает, и в ответе видны настоящие данные инструмента
    if (!$('chat-messages').querySelector('.bubble')) {
        bubble('проверка', false);
        if (!$('chat-messages').querySelector('.bubble')) problems.push('чат не выводит сообщения');
    }

    const bg = getComputedStyle(document.body).backgroundColor;
    if (!bg || bg === 'rgba(0, 0, 0, 0)') problems.push('тема не применилась');
    if (!lastState) problems.push('состояние от главного процесса не пришло');

    // --- предложения агента: подтверждение обязательно, обход невозможен ---
    // Главный процесс проверяет предложение ПОВТОРНО: страница может быть
    // скомпрометирована текстом, который сама же прочитала.
    try {
        const good = await window.clandai.agent.applyProposal({ kind: 'ui.open', section: 'swap' });
        if (!good || !good.ok) problems.push('разрешённое предложение не применилось: ' + JSON.stringify(good));

        const bad = await window.clandai.agent.applyProposal({ kind: 'ui.open', section: 'взлом' });
        if (bad && bad.ok) problems.push('ОПАСНО: принят неразрешённый раздел');

        const bad2 = await window.clandai.agent.applyProposal(
            { kind: 'list.add', action: 'dump-seed', address: '0x' + 'ab'.repeat(20) });
        if (bad2 && bad2.ok) problems.push('ОПАСНО: принято неразрешённое действие');

        const bad3 = await window.clandai.agent.applyProposal(
            { kind: 'list.add', action: 'add-whitelist', address: 'мусор' });
        if (bad3 && bad3.ok) problems.push('ОПАСНО: принят неверный адрес');
    } catch (e) { problems.push('предложения упали: ' + e.message); }

    return {
        ok: problems.length === 0,
        checks: 44,
        problems: problems,
        theme: bg,
        tabs: lastState ? lastState.tabs.length : 0,
        agentEyes: document.querySelectorAll('.ai-eye').length
    };
};