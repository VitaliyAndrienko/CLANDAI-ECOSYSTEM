/* =========================================================================
   guard-ops-signatures.js — АВТОГЕНЕРАЦИЯ, не править руками.
   Источник: скомпилированный ABI контрактов. Обновить:
       npm run build && node tools/gen-op-signatures.js
   ========================================================================= */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.GuardOpsSignatures = factory();
})(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    return {
        /// @dev name -> сигнатура; ADDRESSES говорит, к какому контракту звать.
        SIG: {
            transfer: 'transfer(address,address,address,uint256,uint256,uint256,bytes[])',
            transferNative: 'transferNative(address,address,uint256,uint256,uint256,bytes[])',
            executeOnContract: 'executeOnContract(address,address,address,uint256,bytes,uint256,uint256,bytes,bytes[])',
            approveOnContract: 'approveOnContract(address,address,address,uint256,uint256,uint256,bytes,bytes[])',
            executeAsAgent: 'executeAsAgent(address,address,address,address,uint256,bytes,uint256,uint256,bytes,bytes[],bytes)',
            emergencySweepAsset: 'emergencySweepAsset(address,address,uint8,uint256,uint256,uint256,uint256,bytes[])',
            subscribe: 'subscribe(uint8,address,uint256,uint256,bytes[])',
            setRecoveryTarget: 'setRecoveryTarget(address,address,address,uint256,uint256,bytes[])',
            removeRecoveryTarget: 'removeRecoveryTarget(address,address,uint256,uint256,bytes[])',
            changeOwners: 'changeOwners(address[],bool[],uint256,uint256,bytes[])',
            addWallet: 'addWallet(address,bool,uint256,uint256,bytes[])',
            removeWallet: 'removeWallet(address,uint256,uint256,bytes[])',
            revokePermit2OnWallet: 'revokePermit2OnWallet(address,address,uint256,uint256,bytes[])',
            addContractPolicy: 'addContractPolicy(address,uint256,uint256,uint256,uint256,uint256,bytes[])',
            blockContract: 'blockContract(address,bool,uint256,uint256,bytes[])',
            increaseContractUsdLimit: 'increaseContractUsdLimit(address,uint256,uint256,uint256,bytes[])',
            removeContractPolicy: 'removeContractPolicy(address,uint256,uint256,bytes[])',
            setNativeValueLimit: 'setNativeValueLimit(address,uint256,uint256,uint256,bytes[])',
            addTokenRisk: 'addTokenRisk(address,uint8,uint256,uint256,bytes[])',
            addTokenPrice: 'addTokenPrice(address,uint256,uint8,uint64,uint256,uint256,bytes[])',
            addTokenAmountPolicy: 'addTokenAmountPolicy(address,address,uint256,uint256,uint256,uint256,bytes[])',
            setDefaultTransferShare: 'setDefaultTransferShare(uint256,uint256,uint256,bytes[])',
            setTransferBudget: 'setTransferBudget(address,address,uint256,uint64,uint256,uint256,bytes[])',
            addBlacklist: 'addBlacklist(address,uint256,uint256,bytes[])',
            removeBlacklist: 'removeBlacklist(address,uint256,uint256,bytes[])',
            addToken: 'addToken(address,uint256,uint256,bytes[])',
            removeToken: 'removeToken(address,uint256,uint256,bytes[])',
            addRouter: 'addRouter(address,uint256,uint256,bytes[])',
            removeRouter: 'removeRouter(address,uint256,uint256,bytes[])',
            addTradingPlatform: 'addTradingPlatform(address,uint256,uint256,bytes[])',
            removeTradingPlatform: 'removeTradingPlatform(address,uint256,uint256,bytes[])',
            setSessionScope: 'setSessionScope(address,address,address,address,uint256,uint256,uint64,uint256,uint256,uint256,bytes[])',
            revokeSession: 'revokeSession(address,uint256,uint256,bytes[])',
            cancelRecoveryRequest: 'cancelRecoveryRequest(address,uint256,uint256,uint256,bytes[])',
            proposeStrictKey: 'proposeStrictKey(address,uint256,uint256,bytes[])',
            cancelStrictKey: 'cancelStrictKey(uint256,uint256,bytes[])',
            setMigrationEmergencyKey: 'setMigrationEmergencyKey(address,uint256,uint256,bytes[])',
        },
        ORIGIN: {
            transfer: 'SmartWalletGuard',
            transferNative: 'SmartWalletGuard',
            executeOnContract: 'SmartWalletGuard',
            approveOnContract: 'SmartWalletGuard',
            executeAsAgent: 'SmartWalletGuard',
            emergencySweepAsset: 'SmartWalletGuard',
            subscribe: 'SmartWalletGuard',
            setRecoveryTarget: 'SmartWalletGuard',
            removeRecoveryTarget: 'SmartWalletGuard',
            changeOwners: 'SmartWalletGuard',
            addWallet: 'SmartWalletGuard',
            removeWallet: 'SmartWalletGuard',
            revokePermit2OnWallet: 'SmartWalletGuard',
            addContractPolicy: 'SmartWalletPolicyOps',
            blockContract: 'SmartWalletPolicyOps',
            increaseContractUsdLimit: 'SmartWalletPolicyOps',
            removeContractPolicy: 'SmartWalletPolicyOps',
            setNativeValueLimit: 'SmartWalletPolicyOps',
            addTokenRisk: 'SmartWalletPolicyOps',
            addTokenPrice: 'SmartWalletPolicyOps',
            addTokenAmountPolicy: 'SmartWalletPolicyOps',
            setDefaultTransferShare: 'SmartWalletPolicyOps',
            setTransferBudget: 'SmartWalletPolicyOps',
            addBlacklist: 'SmartWalletPolicyOps',
            removeBlacklist: 'SmartWalletPolicyOps',
            addToken: 'SmartWalletPolicyOps',
            removeToken: 'SmartWalletPolicyOps',
            addRouter: 'SmartWalletPolicyOps',
            removeRouter: 'SmartWalletPolicyOps',
            addTradingPlatform: 'SmartWalletPolicyOps',
            removeTradingPlatform: 'SmartWalletPolicyOps',
            setSessionScope: 'SmartWalletPolicyOps',
            revokeSession: 'SmartWalletPolicyOps',
            cancelRecoveryRequest: 'SmartWalletPolicyOps',
            proposeStrictKey: 'SmartWalletPolicyOps',
            cancelStrictKey: 'SmartWalletPolicyOps',
            setMigrationEmergencyKey: 'SmartWalletPolicyOps',
        }
    };
});
