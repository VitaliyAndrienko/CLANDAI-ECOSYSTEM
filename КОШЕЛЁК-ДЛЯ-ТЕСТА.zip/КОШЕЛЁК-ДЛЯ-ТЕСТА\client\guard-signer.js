/* =========================================================================
   guard-signer.js — подпись EIP-712 digest-ов (secp256k1 ECDSA).

   Зачем свой, а не ethers: кошелёк грузит ethers с внешнего CDN, а это
   supply-chain риск для крипто-кода, который подписывает транзакции. Здесь
   всё локально: keccak256 берётся из guard-digests.js, secp256k1 реализован
   здесь. Работает и в браузере, и в Node.

   Корректность НЕ декларируется, а доказывается: test/SignerParity.t.sol
   проверяет, что ecrecover в Solidity возвращает ровно тот адрес, которому
   принадлежит ключ.

   О nonce: k выводится детерминированно как keccak256(privkey || digest ||
   counter) mod n. Это безопасно (keccak необратим, RNG не участвует, повторов
   нет), но это НЕ RFC 6979. Продакшен-кошелёк может подписывать через
   ethers (RFC 6979) — подпись над тем же digest-ом получится другой, но
   валидной: контракту важна валидность, а не способ выбора k.
   ========================================================================= */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) {
        module.exports = factory(require('./guard-digests.js'));
    } else {
        root.GuardSigner = factory(root.GuardDigests);
    }
})(typeof self !== 'undefined' ? self : this, function (D) {
    'use strict';

    // ---- параметры кривой secp256k1 ----
    var P = 0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2fn;
    var N = 0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n;
    var GX = 0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798n;
    var GY = 0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8n;
    var HALF_N = N >> 1n;

    function mod(a, m) { var r = a % m; return r < 0n ? r + m : r; }

    function modInv(a, m) {
        // расширенный алгоритм Евклида
        var g = m, x = 0n, x1 = 1n, a1 = mod(a, m);
        while (a1 !== 0n) {
            var q = g / a1;
            var t = g - q * a1; g = a1; a1 = t;
            t = x - q * x1; x = x1; x1 = t;
        }
        if (g !== 1n) throw new Error('no inverse');
        return mod(x, m);
    }

    // ---- аффинные операции над точками ----
    function double(pt) {
        if (pt === null) return null;
        var x = pt[0], y = pt[1];
        if (y === 0n) return null;
        var l = mod(3n * x * x * modInv(2n * y, P), P);
        var x3 = mod(l * l - 2n * x, P);
        var y3 = mod(l * (x - x3) - y, P);
        return [x3, y3];
    }

    function add(a, b) {
        if (a === null) return b;
        if (b === null) return a;
        if (a[0] === b[0]) {
            if (mod(a[1] + b[1], P) === 0n) return null;
            return double(a);
        }
        var l = mod((b[1] - a[1]) * modInv(b[0] - a[0], P), P);
        var x3 = mod(l * l - a[0] - b[0], P);
        var y3 = mod(l * (a[0] - x3) - a[1], P);
        return [x3, y3];
    }

    function mul(k, pt) {
        var r = null, q = pt, kk = mod(k, N);
        while (kk > 0n) {
            if (kk & 1n) r = add(r, q);
            q = double(q);
            kk >>= 1n;
        }
        return r;
    }

    var G = [GX, GY];

    // ---- байты <-> bigint ----
    function bytesToBig(bytes) {
        var v = 0n;
        for (var i = 0; i < bytes.length; i++) v = (v << 8n) | BigInt(bytes[i]);
        return v;
    }

    function bigTo32(v) {
        var out = new Uint8Array(32);
        for (var i = 31; i >= 0; i--) { out[i] = Number(v & 0xffn); v >>= 8n; }
        if (v !== 0n) throw new Error('bigTo32 overflow');
        return out;
    }

    function hexToBytes(h) {
        var s = h.slice(0, 2) === '0x' ? h.slice(2) : h;
        if (s.length !== 64 && s.length !== 40 && s.length % 2 !== 0) {
            throw new Error('bad hex length');
        }
        var out = new Uint8Array(s.length / 2);
        for (var i = 0; i < out.length; i++) out[i] = parseInt(s.substr(i * 2, 2), 16);
        return out;
    }

    function toHex(bytes) {
        var s = '0x';
        for (var i = 0; i < bytes.length; i++) s += bytes[i].toString(16).padStart(2, '0');
        return s;
    }

    function concatBytes(a, b) {
        var out = new Uint8Array(a.length + b.length);
        out.set(a, 0); out.set(b, a.length);
        return out;
    }

    // ---- ключи и адреса ----

    function privateToPublic(priv) {
        var d = mod(BigInt(priv), N);
        if (d === 0n) throw new Error('zero private key');
        return mul(d, G);
    }

    /// @dev EIP-55: регистр каждого символа адреса зависит от соответствующей
    ///      шестнадцатеричной цифры keccak256 от адреса в нижнем регистре.
    ///      Нужен и Solidity (адресные литералы обязаны быть checksummed),
    ///      и UI кошелька — так адрес визуально проверяем человеком.
    function toChecksumAddress(addr) {
        var a = addr.slice(0, 2) === '0x' ? addr.slice(2).toLowerCase() : addr.toLowerCase();
        if (a.length !== 40) throw new Error('bad address length');
        var h = D.keccak256Bytes(a);
        var out = '0x';
        for (var i = 0; i < 40; i++) {
            var nibble = (h[i >> 1] >> (i % 2 === 0 ? 4 : 0)) & 0x0f;
            out += nibble >= 8 ? a[i].toUpperCase() : a[i];
        }
        return out;
    }

    /// @dev Ethereum-адрес: последние 20 байт keccak256(несжатый публичный ключ
    ///      без префикса). Возвращается в checksum-форме (EIP-55).
    function addressOf(priv) {
        var pt = privateToPublic(priv);
        var pub = concatBytes(bigTo32(pt[0]), bigTo32(pt[1]));
        var lower = '0x' + D.keccak256Bytes(pub).slice(12).reduce(function (s, b) {
            return s + b.toString(16).padStart(2, '0');
        }, '');
        return toChecksumAddress(lower);
    }

    // ---- подпись ----

    /// @dev Детерминированный k. Повтор при k вне диапазона или при r == 0.
    function deriveK(d, digestBytes, counter) {
        var msg = new Uint8Array(32 + 32 + 1);
        msg.set(bigTo32(d), 0);
        msg.set(digestBytes, 32);
        msg[64] = counter;
        return mod(bytesToBig(D.keccak256Bytes(msg)), N);
    }

    /// @dev Подпись digest-а. Возвращает 65 байт: r(32) || s(32) || v(1).
    ///      s приводится к нижней половине (EIP-2), v — это 27 + recid.
    function sign(digestHex, priv) {
        var d = mod(BigInt(priv), N);
        if (d === 0n) throw new Error('zero private key');
        var z = bytesToBig(hexToBytes(digestHex));
        var counter = 0;

        while (true) {
            var k = deriveK(d, hexToBytes(digestHex), counter);
            counter++;
            if (k === 0n) continue;

            var R = mul(k, G);
            if (R === null) continue;
            var r = mod(R[0], N);
            if (r === 0n) continue;

            var s = mod(modInv(k, N) * (z + r * d), N);
            if (s === 0n) continue;

            // recovery id: чётность y у R; при s > n/2 подпись "переворачивается"
            var recid = Number(R[1] & 1n);
            if (R[0] >= N) recid += 2;
            if (s > HALF_N) { s = N - s; recid ^= 1; }

            return toHex(concatBytes(concatBytes(bigTo32(r), bigTo32(s)), new Uint8Array([27 + recid])));
        }
    }

    /// @dev Подпись структурного хеша операции: digestOf(domainSeparator, structHash).
    function signStructHash(domainSeparator, structHash, priv) {
        return sign(D.digestOf(domainSeparator, structHash), priv);
    }

    /// @dev Набор из n подписей одним ключом (bytes[] для аргументов контракта).
    function signMany(digestHex, priv, n) {
        var out = [];
        for (var i = 0; i < n; i++) out.push(sign(digestHex, priv));
        return out;
    }

    return {
        CURVE: { P: P, N: N, GX: GX, GY: GY },
        privateToPublic: privateToPublic,
        addressOf: addressOf,
        toChecksumAddress: toChecksumAddress,
        sign: sign,
        signStructHash: signStructHash,
        signMany: signMany,
        toHex: toHex
    };
});
