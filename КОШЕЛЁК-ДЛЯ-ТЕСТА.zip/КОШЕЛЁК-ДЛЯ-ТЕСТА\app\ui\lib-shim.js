/* =========================================================================
   lib-shim.js — мост между дизайном заказчика и локальными библиотеками.

   Дизайн подключал библиотеки с CDN (ethers, argon2-browser). Сети нет,
   поэтому вместо CDN стоят локальные сборки из app/vendor.

   Дизайн вызывает window.argon2.hash({pass, salt, time, mem, hashLen,
   parallelism}) — как argon2-browser. Здесь тот же вызов переводится на
   hash-wasm, имена параметров отличаются, поэтому их надо сопоставить.
   ========================================================================= */

'use strict';

(function () {
    var hw = window.hashwasm || window.HashWasm || window.hashwasmModule || null;

    function findArgon2id() {
        if (!hw) return null;
        if (typeof hw.argon2id === 'function') return hw.argon2id;
        if (hw.default && typeof hw.default.argon2id === 'function') return hw.default.argon2id;
        return null;
    }

    var argon2id = findArgon2id();

    if (!argon2id) {
        // Явная ошибка вместо тихой поломки: без Argon2id кошелёк создавать нельзя.
        window.argon2 = {
            ArgonType: { Argon2d: 0, Argon2i: 1, Argon2id: 2 },
            hash: function () { return Promise.reject(new Error('Argon2id недоступен: локальная сборка не загрузилась')); }
        };
        return;
    }

    function toBytes(v) {
        if (v instanceof Uint8Array) return v;
        if (v instanceof ArrayBuffer) return new Uint8Array(v);
        if (typeof v === 'string') return new TextEncoder().encode(v);
        if (Array.isArray(v)) return new Uint8Array(v);
        return new Uint8Array(v);
    }

    function hexOf(bytes) {
        var s = '';
        for (var i = 0; i < bytes.length; i++) s += ('0' + bytes[i].toString(16)).slice(-2);
        return s;
    }

    /// @dev Дизайн обращается к window.argon2.ArgonType.Argon2id — это
    ///      константа argon2-browser. Без неё падало ВСЁ создание частей
    ///      («Cannot read properties of undefined»), что нашёл клик-тест.
    ///      Значения как в argon2-browser: Argon2d=0, Argon2i=1, Argon2id=2.
    var ArgonType = { Argon2d: 0, Argon2i: 1, Argon2id: 2 };

    window.argon2 = {
        ArgonType: ArgonType,
        hash: async function (o) {
            o = o || {};
            var salt = toBytes(o.salt);
            var out = await argon2id({
                password: (typeof o.pass === 'string') ? o.pass : toBytes(o.pass),
                salt: salt,
                parallelism: o.parallelism || 1,
                iterations: o.time || 3,
                memorySize: o.mem || 65536,
                hashLength: o.hashLen || 32,
                outputType: 'binary'
            });
            var bytes = toBytes(out);
            return {
                hash: bytes,
                hashHex: hexOf(bytes),
                encoded: hexOf(bytes)
            };
        }
    };
})();
