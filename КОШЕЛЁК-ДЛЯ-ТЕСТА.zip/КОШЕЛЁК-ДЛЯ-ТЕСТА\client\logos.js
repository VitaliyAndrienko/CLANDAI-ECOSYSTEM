/* =========================================================================
   logos.js — логотипы сетей и монет.

   ГДЕ БЕРУТСЯ, по порядку:
     1. ЛОКАЛЬНЫЙ ФАЙЛ — app/ui/logos/<id>.svg (или .png).
        Это основной путь: заказчик кладёт официальный логотип в папку,
        и он появляется сам, БЕЗ правки кода.
     2. CDN по тикеру — работает на машине пользователя (там есть сеть).
        В песочнице без сети не загрузится, и включится пункт 3.
     3. МОНОГРАММА — рисуется кодом: фирменный цвет сети + тикер.
        Интерфейс НИКОГДА не остаётся без значка.

   ПОЧЕМУ ТАК: официальные логотипы нельзя скачать без сети. Система готова
   их принять, а пока показывает аккуратные монограммы в фирменных цветах.
   Достаточно положить файлы в app/ui/logos/ — и ничего больше не менять.

   ТОКЕНЫ (CLANDAI, ONCLND) — локальные картинки, всегда первыми в списке.
   ========================================================================= */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.GuardLogos = factory();
})(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    /// @dev Папка с локальными логотипами (относительно ui/).
    var LOCAL_DIR = 'logos/';

    /// @dev CDN-источник по тикеру. Пункт 2 — только если нет локального файла.
    function cdnByTicker(ticker) {
        if (!ticker) return null;
        return 'https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/svg/color/' +
            String(ticker).toLowerCase() + '.svg';
    }

    /// @dev Монограмма: круг фирменного цвета + тикер. Возвращает data-URI SVG.
    ///      Рисуется кодом, поэтому не требует ни сети, ни файлов.
    function monogram(net) {
        var color = (net && net.color) || '#5b6672';
        var label = String((net && (net.ticker || net.id)) || '?').slice(0, 4).toUpperCase();
        var fs = label.length > 3 ? 15 : (label.length > 2 ? 18 : 22);
        var svg =
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">' +
            '<defs><radialGradient id="g" cx="35%" cy="28%">' +
            '<stop offset="0%" stop-color="' + color + '" stop-opacity=".95"/>' +
            '<stop offset="100%" stop-color="' + color + '" stop-opacity=".45"/>' +
            '</radialGradient></defs>' +
            '<circle cx="32" cy="32" r="31" fill="url(#g)" stroke="' + color + '" stroke-width="1.5"/>' +
            '<text x="32" y="32" text-anchor="middle" dominant-baseline="central" ' +
            'font-family="ui-monospace,Menlo,Consolas,monospace" font-size="' + fs + '" ' +
            'font-weight="700" fill="#08090b">' + label + '</text></svg>';
        return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    }

    /// @dev Токены, которые всегда показываются ПЕРВЫМИ и вне зависимости
    ///      от выбранной сети (требование заказчика).
    var PROMOTED = [
        { id: 'clandai', symbol: 'CLANDAI', name: 'CLANDAI', file: 'CLANDAI.png', color: '#00ffaa' },
        { id: 'onclnd',  symbol: 'ONCLND',  name: 'ONCLND',  file: 'ONCLND.png',  color: '#00d9ff' }
    ];

    /// @dev Обычные монеты — показываются ниже закреплённых.
    var COMMON = [
        { id: 'usdt', symbol: 'USDT', name: 'Tether USD',  color: '#26A17B' },
        { id: 'usdc', symbol: 'USDC', name: 'USD Coin',    color: '#2775CA' },
        { id: 'dai',  symbol: 'DAI',  name: 'Dai Stablecoin', color: '#F5AC37' }
    ];

    /// @dev Источники для одной сети, по порядку применения.
    function sources(net) {
        var out = [];
        if (!net) return out;
        out.push(LOCAL_DIR + net.id + '.svg');
        out.push(LOCAL_DIR + net.id + '.png');
        var cdn = cdnByTicker(net.ticker);
        if (cdn) out.push(cdn);
        return out;
    }

    /// @dev Первый применимый источник, иначе монограмма.
    ///      Проверка «файл существует» в браузере невозможна без запроса,
    ///      поэтому разметка ставит локальный путь, а onerror переключает
    ///      на монограмму (см. attach()).
    function url(net) {
        var s = sources(net);
        return s.length ? s[0] : monogram(net);
    }

    /// @dev [ПРАВКА] Логотип токена: сначала ЛОКАЛЬНЫЙ файл по символу
    ///      (logos/USDT.svg), потом уже монограмма. Раньше локальные файлы
    ///      не использовались вовсе, и все токены рисовались буквами.
    function fileForToken(t) {
        if (!t) return monogram({ ticker: '?' });
        if (t.file) return LOCAL_DIR + t.file;
        var sym = String(t.symbol || '').toUpperCase();
        if (sym) return LOCAL_DIR + sym + '.svg';
        return monogram(t);
    }

    /// @dev Список источников для токена: локальный файл, затем CDN по тикеру,
    ///      затем монограмма. Нужен, чтобы картинка сама переключалась при отказе.
    function tokenSources(t) {
        var out = [];
        if (!t) return out;
        if (t.file) out.push(LOCAL_DIR + t.file);
        var sym = String(t.symbol || '').toUpperCase();
        if (sym) out.push(LOCAL_DIR + sym + '.svg');
        var cdn = cdnByTicker(sym);
        if (cdn) out.push(cdn);
        return out;
    }

    /// @dev Навесить логотип на <img>: локальный -> CDN -> монограмма.
    ///      Единственная точка, где обрабатывается отказ загрузки.
    function attach(img, net) {
        if (!img || !net) return;
        var list = sources(net);
        var i = 0;
        img.onerror = function () {
            i++;
            if (i < list.length) { img.src = list[i]; return; }
            img.onerror = null;
            img.src = monogram(net);
        };
        img.src = list.length ? list[0] : monogram(net);
    }

    return {
        LOCAL_DIR: LOCAL_DIR,
        PROMOTED: PROMOTED,
        COMMON: COMMON,
        sources: sources,
        tokenSources: tokenSources,
        url: url,
        monogram: monogram,
        attach: attach,
        fileForToken: fileForToken,
        /// @dev Полный список монет для списка токенов: сначала закреплённые.
        tokens: function () { return PROMOTED.concat(COMMON); }
    };
});
