/* =========================================================================
   i18n.js — переводы интерфейса.

   ЗАЧЕМ СВОЙ, А НЕ ИЗ ДИЗАЙНА: в дизайне было 2–3 языка и десятки ключей.
   Нужно «хотя бы 22 языка, и чтобы менялись ВСЕ слова».

   КАК ПОЛЬЗОВАТЬСЯ (в разметке)
   -----------------------------
     <span data-i18n="wallet.balance"></span>       — подставить текст
     <input data-i18n-ph="common.search">           — подставить placeholder
     <span data-i18n="net.count" data-i18n-n="82">  — с подстановкой {n}

   КАК ПОЛЬЗОВАТЬСЯ (в коде)
   -------------------------
     I18N.t('wallet.send')            — текст
     I18N.t('net.count', {n: 82})     — с подстановкой
     I18N.set('de')                   — сменить язык (перерисует страницу)
     I18N.lang()                      — текущий язык
     I18N.onChange(fn)                — подписка на смену языка

   ПРАВИЛА
   -------
   * английский — БАЗОВЫЙ: нет ключа в языке — берётся английский.
     Интерфейс НИКОГДА не остаётся пустым.
   * I18N.coverage() показывает пробелы; это проверяет tools/check-i18n.js,
     а не глаза.
   * Язык хранится в localStorage('clandai_lang').
   ========================================================================= */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else {
        var api = factory();
        // ВАЖНО: в дизайне кошелька уже есть свой объект с именем I18N.
        // В классическом скрипте `const I18N` перекрывает window.I18N, поэтому
        // модуль дополнительно доступен как GuardI18n — им и пользуемся там,
        // где имя занято.
        root.I18N = api;
        root.GuardI18n = api;
    }
})(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    /// @dev Языки. rtl — справа налево (влияет на направление разметки).
    var LANGS = [
        { code: 'en', name: 'English',    native: 'English',    rtl: false },
        { code: 'ru', name: 'Russian',    native: 'Русский',    rtl: false },
        { code: 'uk', name: 'Ukrainian',  native: 'Українська', rtl: false },
        { code: 'de', name: 'German',     native: 'Deutsch',    rtl: false },
        { code: 'fr', name: 'French',     native: 'Français',   rtl: false },
        { code: 'es', name: 'Spanish',    native: 'Español',    rtl: false },
        { code: 'pt', name: 'Portuguese', native: 'Português',  rtl: false },
        { code: 'it', name: 'Italian',    native: 'Italiano',   rtl: false },
        { code: 'nl', name: 'Dutch',      native: 'Nederlands', rtl: false },
        { code: 'pl', name: 'Polish',     native: 'Polski',     rtl: false },
        { code: 'cs', name: 'Czech',      native: 'Čeština',    rtl: false },
        { code: 'tr', name: 'Turkish',    native: 'Türkçe',     rtl: false },
        { code: 'ar', name: 'Arabic',     native: 'العربية',    rtl: true  },
        { code: 'fa', name: 'Persian',    native: 'فارسی',      rtl: true  },
        { code: 'he', name: 'Hebrew',     native: 'עברית',      rtl: true  },
        { code: 'hi', name: 'Hindi',      native: 'हिन्दी',      rtl: false },
        { code: 'bn', name: 'Bengali',    native: 'বাংলা',      rtl: false },
        { code: 'id', name: 'Indonesian', native: 'Indonesia',  rtl: false },
        { code: 'vi', name: 'Vietnamese', native: 'Tiếng Việt', rtl: false },
        { code: 'th', name: 'Thai',       native: 'ไทย',        rtl: false },
        { code: 'zh', name: 'Chinese',    native: '中文',        rtl: false },
        { code: 'ja', name: 'Japanese',   native: '日本語',      rtl: false },
        { code: 'ko', name: 'Korean',     native: '한국어',      rtl: false }
    ];

    /// @dev БАЗОВЫЙ язык. Его ключи обязаны быть во всех языках.
    var EN = {
        'app.wallet': 'Wallet', 'app.bank': 'Bank', 'app.agent': 'Assistant',
        'app.menu': 'Menu', 'app.settings': 'Settings', 'app.language': 'Language',

        'common.confirm': 'Confirm', 'common.cancel': 'Cancel', 'common.save': 'Save',
        'common.add': 'Add', 'common.delete': 'Delete', 'common.close': 'Close',
        'common.back': 'Back', 'common.next': 'Next', 'common.search': 'Search',
        'common.loading': 'Loading…', 'common.error': 'Error', 'common.empty': 'Empty',
        'common.all': 'All', 'common.more': 'More', 'common.copy': 'Copy',
        'common.copied': 'Copied', 'common.min': 'Min', 'common.max': 'Max',

        'wallet.balance': 'Balance', 'wallet.address': 'Address', 'wallet.accounts': 'Accounts',
        'wallet.network': 'Network', 'wallet.networks': 'Networks', 'wallet.send': 'Send',
        'wallet.receive': 'Receive', 'wallet.swap': 'Swap', 'wallet.transactions': 'Transactions',
        'wallet.tokens': 'Tokens', 'wallet.favorites': 'Favorites', 'wallet.amount': 'Amount',
        'wallet.fee': 'Fee', 'wallet.total': 'Total', 'wallet.hot': 'Hot wallet',
        'wallet.cold': 'Cold wallet',

        'menu.whitelist': 'Whitelist', 'menu.blacklist': 'Blacklist',
        'menu.sessions': 'Active sessions', 'menu.subscriptions': 'My crypto subscriptions',
        'menu.walletFormat': 'Wallet format', 'menu.signatureType': 'Signature type',
        'menu.quantum': 'Quantum signature', 'menu.hotCold': 'Hot to cold and back',

        'net.popular': 'Popular', 'net.standard': 'Standard', 'net.count': '{n} networks',

        'ai.ask': 'Ask anything…', 'ai.thinking': 'Thinking…',

        'bank.cards': 'Cards', 'bank.history': 'History', 'bank.deposit': 'Deposit',

        'sub.upgrade': 'Upgrade', 'sub.plan': 'Plan',

        'common.drag': 'Drag', 'common.name': 'Name', 'common.description': 'Description', 'common.notReceived': 'Not received', 'common.received': 'Received',

        'onboard.create': 'Create wallet', 'onboard.import': 'Import seed phrase', 'onboard.questions': 'Three questions', 'onboard.pattern': 'Graphic password', 'onboard.done': 'Wallet ready',

        'menu.backup': 'Backup',
    };

    /// @dev Словари. Достаточно отличающихся ключей — остальное из английского.
    var DICT = {
        en: EN,

        ru: {
            'menu.backup': 'Резервная копия',
            'onboard.create': 'Создать кошелёк', 'onboard.import': 'Импорт seed-фразы', 'onboard.questions': 'Три вопроса', 'onboard.pattern': 'Графический пароль', 'onboard.done': 'Кошелёк готов',
            'common.drag': 'Тяните', 'common.name': 'Имя', 'common.description': 'Описание', 'common.notReceived': 'Не получил', 'common.received': 'Получил',
            'app.wallet': 'Кошелёк', 'app.bank': 'Банк', 'app.agent': 'Ассистент',
            'app.menu': 'Меню', 'app.settings': 'Настройки', 'app.language': 'Язык',
            'common.confirm': 'Подтвердить', 'common.cancel': 'Отмена', 'common.save': 'Сохранить',
            'common.add': 'Добавить', 'common.delete': 'Удалить', 'common.close': 'Закрыть',
            'common.back': 'Назад', 'common.next': 'Далее', 'common.search': 'Поиск',
            'common.loading': 'Загрузка…', 'common.error': 'Ошибка', 'common.empty': 'Пусто',
            'common.all': 'Все', 'common.more': 'Ещё', 'common.copy': 'Копировать',
            'common.copied': 'Скопировано', 'common.min': 'Мин', 'common.max': 'Макс',
            'wallet.balance': 'Баланс', 'wallet.address': 'Адрес', 'wallet.accounts': 'Счета',
            'wallet.network': 'Сеть', 'wallet.networks': 'Сети', 'wallet.send': 'Отправить',
            'wallet.receive': 'Получить', 'wallet.swap': 'Обмен', 'wallet.transactions': 'Транзакции',
            'wallet.tokens': 'Токены', 'wallet.favorites': 'Избранные', 'wallet.amount': 'Сумма',
            'wallet.fee': 'Комиссия', 'wallet.total': 'Итого', 'wallet.hot': 'Тёплый кошелёк',
            'wallet.cold': 'Холодный кошелёк',
            'menu.whitelist': 'Вайтлист', 'menu.blacklist': 'Блэклист',
            'menu.sessions': 'Активные сессии', 'menu.subscriptions': 'Мои крипто-подписки',
            'menu.walletFormat': 'Формат кошелька', 'menu.signatureType': 'Вид подписи',
            'menu.quantum': 'Квантовая подпись', 'menu.hotCold': 'С тёплого на холодный и обратно',
            'net.popular': 'Популярные', 'net.standard': 'Стандарт', 'net.count': '{n} сетей',
            'ai.ask': 'Спросите что угодно…', 'ai.thinking': 'Думаю…',
            'bank.cards': 'Карты', 'bank.history': 'История', 'bank.deposit': 'Пополнить',
            'sub.upgrade': 'Апгрейд', 'sub.plan': 'Тариф'
        },

        uk: {
            'menu.backup': 'Резервна копія',
            'onboard.create': 'Створити гаманець', 'onboard.import': 'Імпорт seed-фрази', 'onboard.questions': 'Три питання', 'onboard.pattern': 'Графічний пароль', 'onboard.done': 'Гаманець готовий',
            'common.drag': 'Тягніть', 'common.name': 'Ім’я', 'common.description': 'Опис', 'common.notReceived': 'Не отримав', 'common.received': 'Отримав',
            'app.wallet': 'Гаманець', 'app.bank': 'Банк', 'app.agent': 'Асистент',
            'app.menu': 'Меню', 'app.settings': 'Налаштування', 'app.language': 'Мова',
            'common.confirm': 'Підтвердити', 'common.cancel': 'Скасувати', 'common.save': 'Зберегти',
            'common.add': 'Додати', 'common.delete': 'Видалити', 'common.close': 'Закрити',
            'common.back': 'Назад', 'common.next': 'Далі', 'common.search': 'Пошук',
            'common.loading': 'Завантаження…', 'common.error': 'Помилка', 'common.empty': 'Порожньо',
            'common.all': 'Усі', 'common.more': 'Ще', 'common.copy': 'Копіювати', 'common.copied': 'Скопійовано',
            'common.min': 'Мін', 'common.max': 'Макс',
            'wallet.balance': 'Баланс', 'wallet.address': 'Адреса', 'wallet.accounts': 'Рахунки',
            'wallet.network': 'Мережа', 'wallet.networks': 'Мережі', 'wallet.send': 'Надіслати',
            'wallet.receive': 'Отримати', 'wallet.swap': 'Обмін', 'wallet.transactions': 'Транзакції',
            'wallet.tokens': 'Токени', 'wallet.favorites': 'Обрані', 'wallet.amount': 'Сума',
            'wallet.fee': 'Комісія', 'wallet.total': 'Разом', 'wallet.hot': 'Теплий гаманець',
            'wallet.cold': 'Холодний гаманець',
            'menu.whitelist': 'Білий список', 'menu.blacklist': 'Чорний список',
            'menu.sessions': 'Активні сесії', 'menu.subscriptions': 'Мої крипто-підписки',
            'menu.walletFormat': 'Формат гаманця', 'menu.signatureType': 'Вид підпису',
            'menu.quantum': 'Квантовий підпис', 'menu.hotCold': 'З теплого на холодний і назад',
            'net.popular': 'Популярні', 'net.standard': 'Стандарт', 'net.count': '{n} мереж',
            'ai.ask': 'Запитайте будь-що…', 'ai.thinking': 'Думаю…',
            'bank.cards': 'Картки', 'bank.history': 'Історія', 'bank.deposit': 'Поповнити',
            'sub.upgrade': 'Апгрейд', 'sub.plan': 'Тариф'
        },

        de: {
            'menu.backup': 'Sicherung',
            'onboard.create': 'Wallet erstellen', 'onboard.import': 'Seed-Phrase importieren', 'onboard.questions': 'Drei Fragen', 'onboard.pattern': 'Grafisches Passwort', 'onboard.done': 'Wallet bereit',
            'common.drag': 'Ziehen', 'common.name': 'Name', 'common.description': 'Beschreibung', 'common.notReceived': 'Nicht erhalten', 'common.received': 'Erhalten',
            'app.wallet': 'Wallet', 'app.bank': 'Bank', 'app.agent': 'Assistent',
            'app.menu': 'Menü', 'app.settings': 'Einstellungen', 'app.language': 'Sprache',
            'common.confirm': 'Bestätigen', 'common.cancel': 'Abbrechen', 'common.save': 'Speichern',
            'common.add': 'Hinzufügen', 'common.delete': 'Löschen', 'common.close': 'Schließen',
            'common.back': 'Zurück', 'common.next': 'Weiter', 'common.search': 'Suchen',
            'common.loading': 'Lädt…', 'common.error': 'Fehler', 'common.empty': 'Leer',
            'common.all': 'Alle', 'common.more': 'Mehr', 'common.copy': 'Kopieren', 'common.copied': 'Kopiert',
            'common.min': 'Min', 'common.max': 'Max',
            'wallet.balance': 'Guthaben', 'wallet.address': 'Adresse', 'wallet.accounts': 'Konten',
            'wallet.network': 'Netzwerk', 'wallet.networks': 'Netzwerke', 'wallet.send': 'Senden',
            'wallet.receive': 'Empfangen', 'wallet.swap': 'Tauschen', 'wallet.transactions': 'Transaktionen',
            'wallet.tokens': 'Token', 'wallet.favorites': 'Favoriten', 'wallet.amount': 'Betrag',
            'wallet.fee': 'Gebühr', 'wallet.total': 'Gesamt', 'wallet.hot': 'Warme Wallet',
            'wallet.cold': 'Kalte Wallet',
            'menu.whitelist': 'Whitelist', 'menu.blacklist': 'Blacklist',
            'menu.sessions': 'Aktive Sitzungen', 'menu.subscriptions': 'Meine Krypto-Abos',
            'menu.walletFormat': 'Wallet-Format', 'menu.signatureType': 'Signaturtyp',
            'menu.quantum': 'Quantensignatur', 'menu.hotCold': 'Warm zu kalt und zurück',
            'net.popular': 'Beliebt', 'net.standard': 'Standard', 'net.count': '{n} Netzwerke',
            'ai.ask': 'Fragen Sie alles…', 'ai.thinking': 'Denke…',
            'bank.cards': 'Karten', 'bank.history': 'Verlauf', 'bank.deposit': 'Einzahlen',
            'sub.upgrade': 'Upgrade', 'sub.plan': 'Tarif'
        },

        fr: {
            'menu.backup': 'Sauvegarde',
            'onboard.create': 'Créer un portefeuille', 'onboard.import': 'Importer la phrase seed', 'onboard.questions': 'Trois questions', 'onboard.pattern': 'Motif de déverrouillage', 'onboard.done': 'Portefeuille prêt',
            'common.drag': 'Glissez', 'common.name': 'Nom', 'common.description': 'Description', 'common.notReceived': 'Non reçu', 'common.received': 'Reçu',
            'app.wallet': 'Portefeuille', 'app.bank': 'Banque', 'app.agent': 'Assistant',
            'app.menu': 'Menu', 'app.settings': 'Paramètres', 'app.language': 'Langue',
            'common.confirm': 'Confirmer', 'common.cancel': 'Annuler', 'common.save': 'Enregistrer',
            'common.add': 'Ajouter', 'common.delete': 'Supprimer', 'common.close': 'Fermer',
            'common.back': 'Retour', 'common.next': 'Suivant', 'common.search': 'Rechercher',
            'common.loading': 'Chargement…', 'common.error': 'Erreur', 'common.empty': 'Vide',
            'common.all': 'Tout', 'common.more': 'Plus', 'common.copy': 'Copier', 'common.copied': 'Copié',
            'common.min': 'Min', 'common.max': 'Max',
            'wallet.balance': 'Solde', 'wallet.address': 'Adresse', 'wallet.accounts': 'Comptes',
            'wallet.network': 'Réseau', 'wallet.networks': 'Réseaux', 'wallet.send': 'Envoyer',
            'wallet.receive': 'Recevoir', 'wallet.swap': 'Échanger', 'wallet.transactions': 'Transactions',
            'wallet.tokens': 'Jetons', 'wallet.favorites': 'Favoris', 'wallet.amount': 'Montant',
            'wallet.fee': 'Frais', 'wallet.total': 'Total', 'wallet.hot': 'Portefeuille chaud',
            'wallet.cold': 'Portefeuille froid',
            'menu.whitelist': 'Liste blanche', 'menu.blacklist': 'Liste noire',
            'menu.sessions': 'Sessions actives', 'menu.subscriptions': 'Mes abonnements crypto',
            'menu.walletFormat': 'Format du portefeuille', 'menu.signatureType': 'Type de signature',
            'menu.quantum': 'Signature quantique', 'menu.hotCold': 'Du chaud au froid et retour',
            'net.popular': 'Populaires', 'net.standard': 'Standard', 'net.count': '{n} réseaux',
            'ai.ask': 'Demandez n’importe quoi…', 'ai.thinking': 'Je réfléchis…',
            'bank.cards': 'Cartes', 'bank.history': 'Historique', 'bank.deposit': 'Déposer',
            'sub.upgrade': 'Améliorer', 'sub.plan': 'Forfait'
        },

        es: {
            'menu.backup': 'Copia de seguridad',
            'onboard.create': 'Crear cartera', 'onboard.import': 'Importar frase semilla', 'onboard.questions': 'Tres preguntas', 'onboard.pattern': 'Patrón gráfico', 'onboard.done': 'Cartera lista',
            'common.drag': 'Arrastre', 'common.name': 'Nombre', 'common.description': 'Descripción', 'common.notReceived': 'No recibido', 'common.received': 'Recibido',
            'app.wallet': 'Cartera', 'app.bank': 'Banco', 'app.agent': 'Asistente',
            'app.menu': 'Menú', 'app.settings': 'Ajustes', 'app.language': 'Idioma',
            'common.confirm': 'Confirmar', 'common.cancel': 'Cancelar', 'common.save': 'Guardar',
            'common.add': 'Añadir', 'common.delete': 'Eliminar', 'common.close': 'Cerrar',
            'common.back': 'Atrás', 'common.next': 'Siguiente', 'common.search': 'Buscar',
            'common.loading': 'Cargando…', 'common.error': 'Error', 'common.empty': 'Vacío',
            'common.all': 'Todo', 'common.more': 'Más', 'common.copy': 'Copiar', 'common.copied': 'Copiado',
            'common.min': 'Mín', 'common.max': 'Máx',
            'wallet.balance': 'Saldo', 'wallet.address': 'Dirección', 'wallet.accounts': 'Cuentas',
            'wallet.network': 'Red', 'wallet.networks': 'Redes', 'wallet.send': 'Enviar',
            'wallet.receive': 'Recibir', 'wallet.swap': 'Intercambiar', 'wallet.transactions': 'Transacciones',
            'wallet.tokens': 'Tokens', 'wallet.favorites': 'Favoritos', 'wallet.amount': 'Importe',
            'wallet.fee': 'Comisión', 'wallet.total': 'Total', 'wallet.hot': 'Cartera caliente',
            'wallet.cold': 'Cartera fría',
            'menu.whitelist': 'Lista blanca', 'menu.blacklist': 'Lista negra',
            'menu.sessions': 'Sesiones activas', 'menu.subscriptions': 'Mis suscripciones cripto',
            'menu.walletFormat': 'Formato de cartera', 'menu.signatureType': 'Tipo de firma',
            'menu.quantum': 'Firma cuántica', 'menu.hotCold': 'De caliente a frío y vuelta',
            'net.popular': 'Populares', 'net.standard': 'Estándar', 'net.count': '{n} redes',
            'ai.ask': 'Pregunta lo que quieras…', 'ai.thinking': 'Pensando…',
            'bank.cards': 'Tarjetas', 'bank.history': 'Historial', 'bank.deposit': 'Depositar',
            'sub.upgrade': 'Mejorar', 'sub.plan': 'Plan'
        },

        pt: {
            'menu.backup': 'Backup',
            'onboard.create': 'Criar carteira', 'onboard.import': 'Importar frase semente', 'onboard.questions': 'Três perguntas', 'onboard.pattern': 'Padrão gráfico', 'onboard.done': 'Carteira pronta',
            'common.drag': 'Arraste', 'common.name': 'Nome', 'common.description': 'Descrição', 'common.notReceived': 'Não recebido', 'common.received': 'Recebido',
            'app.wallet': 'Carteira', 'app.bank': 'Banco', 'app.agent': 'Assistente',
            'app.menu': 'Menu', 'app.settings': 'Configurações', 'app.language': 'Idioma',
            'common.confirm': 'Confirmar', 'common.cancel': 'Cancelar', 'common.save': 'Salvar',
            'common.add': 'Adicionar', 'common.delete': 'Excluir', 'common.close': 'Fechar',
            'common.back': 'Voltar', 'common.next': 'Próximo', 'common.search': 'Buscar',
            'common.loading': 'Carregando…', 'common.error': 'Erro', 'common.empty': 'Vazio',
            'common.all': 'Tudo', 'common.more': 'Mais', 'common.copy': 'Copiar', 'common.copied': 'Copiado',
            'common.min': 'Mín', 'common.max': 'Máx',
            'wallet.balance': 'Saldo', 'wallet.address': 'Endereço', 'wallet.accounts': 'Contas',
            'wallet.network': 'Rede', 'wallet.networks': 'Redes', 'wallet.send': 'Enviar',
            'wallet.receive': 'Receber', 'wallet.swap': 'Trocar', 'wallet.transactions': 'Transações',
            'wallet.tokens': 'Tokens', 'wallet.favorites': 'Favoritos', 'wallet.amount': 'Valor',
            'wallet.fee': 'Taxa', 'wallet.total': 'Total', 'wallet.hot': 'Carteira quente',
            'wallet.cold': 'Carteira fria',
            'menu.whitelist': 'Lista branca', 'menu.blacklist': 'Lista negra',
            'menu.sessions': 'Sessões ativas', 'menu.subscriptions': 'Minhas assinaturas cripto',
            'menu.walletFormat': 'Formato da carteira', 'menu.signatureType': 'Tipo de assinatura',
            'menu.quantum': 'Assinatura quântica', 'menu.hotCold': 'Do quente ao frio e volta',
            'net.popular': 'Populares', 'net.standard': 'Padrão', 'net.count': '{n} redes',
            'ai.ask': 'Pergunte qualquer coisa…', 'ai.thinking': 'Pensando…',
            'bank.cards': 'Cartões', 'bank.history': 'Histórico', 'bank.deposit': 'Depositar',
            'sub.upgrade': 'Melhorar', 'sub.plan': 'Plano'
        },

        it: {
            'menu.backup': 'Backup',
            'onboard.create': 'Crea portafoglio', 'onboard.import': 'Importa frase seed', 'onboard.questions': 'Tre domande', 'onboard.pattern': 'Sequenza grafica', 'onboard.done': 'Portafoglio pronto',
            'common.drag': 'Trascina', 'common.name': 'Nome', 'common.description': 'Descrizione', 'common.notReceived': 'Non ricevuto', 'common.received': 'Ricevuto',
            'app.wallet': 'Portafoglio', 'app.bank': 'Banca', 'app.agent': 'Assistente',
            'app.menu': 'Menu', 'app.settings': 'Impostazioni', 'app.language': 'Lingua',
            'common.confirm': 'Conferma', 'common.cancel': 'Annulla', 'common.save': 'Salva',
            'common.add': 'Aggiungi', 'common.delete': 'Elimina', 'common.close': 'Chiudi',
            'common.back': 'Indietro', 'common.next': 'Avanti', 'common.search': 'Cerca',
            'common.loading': 'Caricamento…', 'common.error': 'Errore', 'common.empty': 'Vuoto',
            'common.all': 'Tutto', 'common.more': 'Altro', 'common.copy': 'Copia', 'common.copied': 'Copiato',
            'common.min': 'Min', 'common.max': 'Max',
            'wallet.balance': 'Saldo', 'wallet.address': 'Indirizzo', 'wallet.accounts': 'Conti',
            'wallet.network': 'Rete', 'wallet.networks': 'Reti', 'wallet.send': 'Invia',
            'wallet.receive': 'Ricevi', 'wallet.swap': 'Scambia', 'wallet.transactions': 'Transazioni',
            'wallet.tokens': 'Token', 'wallet.favorites': 'Preferiti', 'wallet.amount': 'Importo',
            'wallet.fee': 'Commissione', 'wallet.total': 'Totale', 'wallet.hot': 'Portafoglio caldo',
            'wallet.cold': 'Portafoglio freddo',
            'menu.whitelist': 'Lista bianca', 'menu.blacklist': 'Lista nera',
            'menu.sessions': 'Sessioni attive', 'menu.subscriptions': 'I miei abbonamenti crypto',
            'menu.walletFormat': 'Formato portafoglio', 'menu.signatureType': 'Tipo di firma',
            'menu.quantum': 'Firma quantistica', 'menu.hotCold': 'Da caldo a freddo e ritorno',
            'net.popular': 'Popolari', 'net.standard': 'Standard', 'net.count': '{n} reti',
            'ai.ask': 'Chiedi qualsiasi cosa…', 'ai.thinking': 'Sto pensando…',
            'bank.cards': 'Carte', 'bank.history': 'Cronologia', 'bank.deposit': 'Deposita',
            'sub.upgrade': 'Upgrade', 'sub.plan': 'Piano'
        },

        nl: {
            'menu.backup': 'Back-up',
            'onboard.create': 'Wallet aanmaken', 'onboard.import': 'Seed-phrase importeren', 'onboard.questions': 'Drie vragen', 'onboard.pattern': 'Patroon', 'onboard.done': 'Wallet gereed',
            'common.drag': 'Sleep', 'common.name': 'Naam', 'common.description': 'Beschrijving', 'common.notReceived': 'Niet ontvangen', 'common.received': 'Ontvangen',
            'app.wallet': 'Portemonnee', 'app.bank': 'Bank', 'app.agent': 'Assistent',
            'app.menu': 'Menu', 'app.settings': 'Instellingen', 'app.language': 'Taal',
            'common.confirm': 'Bevestigen', 'common.cancel': 'Annuleren', 'common.save': 'Opslaan',
            'common.add': 'Toevoegen', 'common.delete': 'Verwijderen', 'common.close': 'Sluiten',
            'common.back': 'Terug', 'common.next': 'Volgende', 'common.search': 'Zoeken',
            'common.loading': 'Laden…', 'common.error': 'Fout', 'common.empty': 'Leeg',
            'common.all': 'Alles', 'common.more': 'Meer', 'common.copy': 'Kopiëren', 'common.copied': 'Gekopieerd',
            'common.min': 'Min', 'common.max': 'Max',
            'wallet.balance': 'Saldo', 'wallet.address': 'Adres', 'wallet.accounts': 'Rekeningen',
            'wallet.network': 'Netwerk', 'wallet.networks': 'Netwerken', 'wallet.send': 'Verzenden',
            'wallet.receive': 'Ontvangen', 'wallet.swap': 'Wisselen', 'wallet.transactions': 'Transacties',
            'wallet.tokens': 'Tokens', 'wallet.favorites': 'Favorieten', 'wallet.amount': 'Bedrag',
            'wallet.fee': 'Kosten', 'wallet.total': 'Totaal', 'wallet.hot': 'Warme portemonnee',
            'wallet.cold': 'Koude portemonnee',
            'menu.whitelist': 'Witte lijst', 'menu.blacklist': 'Zwarte lijst',
            'menu.sessions': 'Actieve sessies', 'menu.subscriptions': 'Mijn crypto-abonnementen',
            'menu.walletFormat': 'Portemonnee-formaat', 'menu.signatureType': 'Handtekeningtype',
            'menu.quantum': 'Kwantumhandtekening', 'menu.hotCold': 'Warm naar koud en terug',
            'net.popular': 'Populair', 'net.standard': 'Standaard', 'net.count': '{n} netwerken',
            'ai.ask': 'Vraag maar alles…', 'ai.thinking': 'Aan het denken…',
            'bank.cards': 'Kaarten', 'bank.history': 'Geschiedenis', 'bank.deposit': 'Storten',
            'sub.upgrade': 'Upgrade', 'sub.plan': 'Abonnement'
        },

        pl: {
            'menu.backup': 'Kopia zapasowa',
            'onboard.create': 'Utwórz portfel', 'onboard.import': 'Importuj frazę seed', 'onboard.questions': 'Trzy pytania', 'onboard.pattern': 'Wzór graficzny', 'onboard.done': 'Portfel gotowy',
            'common.drag': 'Przeciągnij', 'common.name': 'Nazwa', 'common.description': 'Opis', 'common.notReceived': 'Nie otrzymano', 'common.received': 'Otrzymano',
            'app.wallet': 'Portfel', 'app.bank': 'Bank', 'app.agent': 'Asystent',
            'app.menu': 'Menu', 'app.settings': 'Ustawienia', 'app.language': 'Język',
            'common.confirm': 'Potwierdź', 'common.cancel': 'Anuluj', 'common.save': 'Zapisz',
            'common.add': 'Dodaj', 'common.delete': 'Usuń', 'common.close': 'Zamknij',
            'common.back': 'Wstecz', 'common.next': 'Dalej', 'common.search': 'Szukaj',
            'common.loading': 'Ładowanie…', 'common.error': 'Błąd', 'common.empty': 'Pusto',
            'common.all': 'Wszystko', 'common.more': 'Więcej', 'common.copy': 'Kopiuj', 'common.copied': 'Skopiowano',
            'common.min': 'Min', 'common.max': 'Maks',
            'wallet.balance': 'Saldo', 'wallet.address': 'Adres', 'wallet.accounts': 'Konta',
            'wallet.network': 'Sieć', 'wallet.networks': 'Sieci', 'wallet.send': 'Wyślij',
            'wallet.receive': 'Odbierz', 'wallet.swap': 'Wymień', 'wallet.transactions': 'Transakcje',
            'wallet.tokens': 'Tokeny', 'wallet.favorites': 'Ulubione', 'wallet.amount': 'Kwota',
            'wallet.fee': 'Opłata', 'wallet.total': 'Razem', 'wallet.hot': 'Ciepły portfel',
            'wallet.cold': 'Zimny portfel',
            'menu.whitelist': 'Biała lista', 'menu.blacklist': 'Czarna lista',
            'menu.sessions': 'Aktywne sesje', 'menu.subscriptions': 'Moje subskrypcje krypto',
            'menu.walletFormat': 'Format portfela', 'menu.signatureType': 'Typ podpisu',
            'menu.quantum': 'Podpis kwantowy', 'menu.hotCold': 'Z ciepłego na zimny i z powrotem',
            'net.popular': 'Popularne', 'net.standard': 'Standard', 'net.count': '{n} sieci',
            'ai.ask': 'Zapytaj o cokolwiek…', 'ai.thinking': 'Myślę…',
            'bank.cards': 'Karty', 'bank.history': 'Historia', 'bank.deposit': 'Wpłać',
            'sub.upgrade': 'Ulepsz', 'sub.plan': 'Plan'
        },

        cs: {
            'menu.backup': 'Záloha',
            'onboard.create': 'Vytvořit peněženku', 'onboard.import': 'Importovat seed frázi', 'onboard.questions': 'Tři otázky', 'onboard.pattern': 'Grafický vzor', 'onboard.done': 'Peněženka připravena',
            'common.drag': 'Táhněte', 'common.name': 'Název', 'common.description': 'Popis', 'common.notReceived': 'Nepřijato', 'common.received': 'Přijato',
            'app.wallet': 'Peněženka', 'app.bank': 'Banka', 'app.agent': 'Asistent',
            'app.menu': 'Menu', 'app.settings': 'Nastavení', 'app.language': 'Jazyk',
            'common.confirm': 'Potvrdit', 'common.cancel': 'Zrušit', 'common.save': 'Uložit',
            'common.add': 'Přidat', 'common.delete': 'Smazat', 'common.close': 'Zavřít',
            'common.back': 'Zpět', 'common.next': 'Další', 'common.search': 'Hledat',
            'common.loading': 'Načítání…', 'common.error': 'Chyba', 'common.empty': 'Prázdné',
            'common.all': 'Vše', 'common.more': 'Více', 'common.copy': 'Kopírovat', 'common.copied': 'Zkopírováno',
            'common.min': 'Min', 'common.max': 'Max',
            'wallet.balance': 'Zůstatek', 'wallet.address': 'Adresa', 'wallet.accounts': 'Účty',
            'wallet.network': 'Síť', 'wallet.networks': 'Sítě', 'wallet.send': 'Odeslat',
            'wallet.receive': 'Přijmout', 'wallet.swap': 'Vyměnit', 'wallet.transactions': 'Transakce',
            'wallet.tokens': 'Tokeny', 'wallet.favorites': 'Oblíbené', 'wallet.amount': 'Částka',
            'wallet.fee': 'Poplatek', 'wallet.total': 'Celkem', 'wallet.hot': 'Teplá peněženka',
            'wallet.cold': 'Studená peněženka',
            'menu.whitelist': 'Bílý seznam', 'menu.blacklist': 'Černý seznam',
            'menu.sessions': 'Aktivní relace', 'menu.subscriptions': 'Moje krypto předplatná',
            'menu.walletFormat': 'Formát peněženky', 'menu.signatureType': 'Typ podpisu',
            'menu.quantum': 'Kvantový podpis', 'menu.hotCold': 'Z teplé na studenou a zpět',
            'net.popular': 'Populární', 'net.standard': 'Standard', 'net.count': '{n} sítí',
            'ai.ask': 'Zeptejte se na cokoli…', 'ai.thinking': 'Přemýšlím…',
            'bank.cards': 'Karty', 'bank.history': 'Historie', 'bank.deposit': 'Vložit',
            'sub.upgrade': 'Vylepšit', 'sub.plan': 'Tarif'
        },

        tr: {
            'menu.backup': 'Yedek',
            'onboard.create': 'Cüzdan oluştur', 'onboard.import': 'Seed ifadesini içe aktar', 'onboard.questions': 'Üç soru', 'onboard.pattern': 'Desen şifresi', 'onboard.done': 'Cüzdan hazır',
            'common.drag': 'Kaydır', 'common.name': 'Ad', 'common.description': 'Açıklama', 'common.notReceived': 'Alınmadı', 'common.received': 'Alındı',
            'app.wallet': 'Cüzdan', 'app.bank': 'Banka', 'app.agent': 'Asistan',
            'app.menu': 'Menü', 'app.settings': 'Ayarlar', 'app.language': 'Dil',
            'common.confirm': 'Onayla', 'common.cancel': 'İptal', 'common.save': 'Kaydet',
            'common.add': 'Ekle', 'common.delete': 'Sil', 'common.close': 'Kapat',
            'common.back': 'Geri', 'common.next': 'İleri', 'common.search': 'Ara',
            'common.loading': 'Yükleniyor…', 'common.error': 'Hata', 'common.empty': 'Boş',
            'common.all': 'Tümü', 'common.more': 'Daha', 'common.copy': 'Kopyala', 'common.copied': 'Kopyalandı',
            'common.min': 'Min', 'common.max': 'Maks',
            'wallet.balance': 'Bakiye', 'wallet.address': 'Adres', 'wallet.accounts': 'Hesaplar',
            'wallet.network': 'Ağ', 'wallet.networks': 'Ağlar', 'wallet.send': 'Gönder',
            'wallet.receive': 'Al', 'wallet.swap': 'Takas', 'wallet.transactions': 'İşlemler',
            'wallet.tokens': 'Tokenlar', 'wallet.favorites': 'Favoriler', 'wallet.amount': 'Tutar',
            'wallet.fee': 'Ücret', 'wallet.total': 'Toplam', 'wallet.hot': 'Sıcak cüzdan',
            'wallet.cold': 'Soğuk cüzdan',
            'menu.whitelist': 'Beyaz liste', 'menu.blacklist': 'Kara liste',
            'menu.sessions': 'Aktif oturumlar', 'menu.subscriptions': 'Kripto aboneliklerim',
            'menu.walletFormat': 'Cüzdan biçimi', 'menu.signatureType': 'İmza türü',
            'menu.quantum': 'Kuantum imza', 'menu.hotCold': 'Sıcaktan soğuğa ve geri',
            'net.popular': 'Popüler', 'net.standard': 'Standart', 'net.count': '{n} ağ',
            'ai.ask': 'Her şeyi sorun…', 'ai.thinking': 'Düşünüyorum…',
            'bank.cards': 'Kartlar', 'bank.history': 'Geçmiş', 'bank.deposit': 'Yatır',
            'sub.upgrade': 'Yükselt', 'sub.plan': 'Plan'
        },

        ar: {
            'menu.backup': 'نسخة احتياطية',
            'onboard.create': 'إنشاء محفظة', 'onboard.import': 'استيراد عبارة الاسترداد', 'onboard.questions': 'ثلاثة أسئلة', 'onboard.pattern': 'النمط الرسومي', 'onboard.done': 'المحفظة جاهزة',
            'common.drag': 'اسحب', 'common.name': 'الاسم', 'common.description': 'الوصف', 'common.notReceived': 'لم يتم الاستلام', 'common.received': 'تم الاستلام',
            'app.wallet': 'المحفظة', 'app.bank': 'البنك', 'app.agent': 'المساعد',
            'app.menu': 'القائمة', 'app.settings': 'الإعدادات', 'app.language': 'اللغة',
            'common.confirm': 'تأكيد', 'common.cancel': 'إلغاء', 'common.save': 'حفظ',
            'common.add': 'إضافة', 'common.delete': 'حذف', 'common.close': 'إغلاق',
            'common.back': 'رجوع', 'common.next': 'التالي', 'common.search': 'بحث',
            'common.loading': 'جار التحميل…', 'common.error': 'خطأ', 'common.empty': 'فارغ',
            'common.all': 'الكل', 'common.more': 'المزيد', 'common.copy': 'نسخ', 'common.copied': 'تم النسخ',
            'common.min': 'الأدنى', 'common.max': 'الأقصى',
            'wallet.balance': 'الرصيد', 'wallet.address': 'العنوان', 'wallet.accounts': 'الحسابات',
            'wallet.network': 'الشبكة', 'wallet.networks': 'الشبكات', 'wallet.send': 'إرسال',
            'wallet.receive': 'استلام', 'wallet.swap': 'مبادلة', 'wallet.transactions': 'المعاملات',
            'wallet.tokens': 'الرموز', 'wallet.favorites': 'المفضلة', 'wallet.amount': 'المبلغ',
            'wallet.fee': 'الرسوم', 'wallet.total': 'الإجمالي', 'wallet.hot': 'محفظة ساخنة',
            'wallet.cold': 'محفظة باردة',
            'menu.whitelist': 'القائمة البيضاء', 'menu.blacklist': 'القائمة السوداء',
            'menu.sessions': 'الجلسات النشطة', 'menu.subscriptions': 'اشتراكاتي في العملات',
            'menu.walletFormat': 'صيغة المحفظة', 'menu.signatureType': 'نوع التوقيع',
            'menu.quantum': 'التوقيع الكمي', 'menu.hotCold': 'من الساخن إلى البارد والعودة',
            'net.popular': 'شائعة', 'net.standard': 'المعيار', 'net.count': '{n} شبكة',
            'ai.ask': 'اسأل أي شيء…', 'ai.thinking': 'أفكر…',
            'bank.cards': 'البطاقات', 'bank.history': 'السجل', 'bank.deposit': 'إيداع',
            'sub.upgrade': 'ترقية', 'sub.plan': 'الخطة'
        },

        fa: {
            'menu.backup': 'پشتیبان',
            'onboard.create': 'ساخت کیف پول', 'onboard.import': 'وارد کردن عبارت بازیابی', 'onboard.questions': 'سه پرسش', 'onboard.pattern': 'الگوی گرافیکی', 'onboard.done': 'کیف پول آماده است',
            'common.drag': 'بکشید', 'common.name': 'نام', 'common.description': 'توضیحات', 'common.notReceived': 'دریافت نشد', 'common.received': 'دریافت شد',
            'app.wallet': 'کیف پول', 'app.bank': 'بانک', 'app.agent': 'دستیار',
            'app.menu': 'منو', 'app.settings': 'تنظیمات', 'app.language': 'زبان',
            'common.confirm': 'تأیید', 'common.cancel': 'لغو', 'common.save': 'ذخیره',
            'common.add': 'افزودن', 'common.delete': 'حذف', 'common.close': 'بستن',
            'common.back': 'بازگشت', 'common.next': 'بعدی', 'common.search': 'جستجو',
            'common.loading': 'در حال بارگذاری…', 'common.error': 'خطا', 'common.empty': 'خالی',
            'common.all': 'همه', 'common.more': 'بیشتر', 'common.copy': 'کپی', 'common.copied': 'کپی شد',
            'common.min': 'کم', 'common.max': 'زیاد',
            'wallet.balance': 'موجودی', 'wallet.address': 'آدرس', 'wallet.accounts': 'حساب‌ها',
            'wallet.network': 'شبکه', 'wallet.networks': 'شبکه‌ها', 'wallet.send': 'ارسال',
            'wallet.receive': 'دریافت', 'wallet.swap': 'تبدیل', 'wallet.transactions': 'تراکنش‌ها',
            'wallet.tokens': 'توکن‌ها', 'wallet.favorites': 'مورد علاقه', 'wallet.amount': 'مبلغ',
            'wallet.fee': 'کارمزد', 'wallet.total': 'مجموع', 'wallet.hot': 'کیف گرم',
            'wallet.cold': 'کیف سرد',
            'menu.whitelist': 'لیست سفید', 'menu.blacklist': 'لیست سیاه',
            'menu.sessions': 'نشست‌های فعال', 'menu.subscriptions': 'اشتراک‌های کریپتو من',
            'menu.walletFormat': 'قالب کیف پول', 'menu.signatureType': 'نوع امضا',
            'menu.quantum': 'امضای کوانتومی', 'menu.hotCold': 'از گرم به سرد و برگشت',
            'net.popular': 'محبوب', 'net.standard': 'استاندارد', 'net.count': '{n} شبکه',
            'ai.ask': 'هر چیزی بپرسید…', 'ai.thinking': 'در حال فکر…',
            'bank.cards': 'کارت‌ها', 'bank.history': 'تاریخچه', 'bank.deposit': 'واریز',
            'sub.upgrade': 'ارتقا', 'sub.plan': 'طرح'
        },

        he: {
            'menu.backup': 'גיבוי',
            'onboard.create': 'צור ארנק', 'onboard.import': 'ייבא ביטוי seed', 'onboard.questions': 'שלוש שאלות', 'onboard.pattern': 'סיסמה גרפית', 'onboard.done': 'הארנק מוכן',
            'common.drag': 'גרור', 'common.name': 'שם', 'common.description': 'תיאור', 'common.notReceived': 'לא התקבל', 'common.received': 'התקבל',
            'app.wallet': 'ארנק', 'app.bank': 'בנק', 'app.agent': 'עוזר',
            'app.menu': 'תפריט', 'app.settings': 'הגדרות', 'app.language': 'שפה',
            'common.confirm': 'אישור', 'common.cancel': 'ביטול', 'common.save': 'שמור',
            'common.add': 'הוסף', 'common.delete': 'מחק', 'common.close': 'סגור',
            'common.back': 'חזרה', 'common.next': 'הבא', 'common.search': 'חיפוש',
            'common.loading': 'טוען…', 'common.error': 'שגיאה', 'common.empty': 'ריק',
            'common.all': 'הכל', 'common.more': 'עוד', 'common.copy': 'העתק', 'common.copied': 'הועתק',
            'common.min': 'מינ', 'common.max': 'מקס',
            'wallet.balance': 'יתרה', 'wallet.address': 'כתובת', 'wallet.accounts': 'חשבונות',
            'wallet.network': 'רשת', 'wallet.networks': 'רשתות', 'wallet.send': 'שלח',
            'wallet.receive': 'קבל', 'wallet.swap': 'החלפה', 'wallet.transactions': 'עסקאות',
            'wallet.tokens': 'אסימונים', 'wallet.favorites': 'מועדפים', 'wallet.amount': 'סכום',
            'wallet.fee': 'עמלה', 'wallet.total': 'סה״כ', 'wallet.hot': 'ארנק חם',
            'wallet.cold': 'ארנק קר',
            'menu.whitelist': 'רשימה לבנה', 'menu.blacklist': 'רשימה שחורה',
            'menu.sessions': 'הפעלות פעילות', 'menu.subscriptions': 'המינויים הקריפטו שלי',
            'menu.walletFormat': 'פורמט ארנק', 'menu.signatureType': 'סוג חתימה',
            'menu.quantum': 'חתימה קוונטית', 'menu.hotCold': 'מחם לקר ובחזרה',
            'net.popular': 'פופולרי', 'net.standard': 'תקן', 'net.count': '{n} רשתות',
            'ai.ask': 'שאל כל דבר…', 'ai.thinking': 'חושב…',
            'bank.cards': 'כרטיסים', 'bank.history': 'היסטוריה', 'bank.deposit': 'הפקדה',
            'sub.upgrade': 'שדרוג', 'sub.plan': 'מסלול'
        },

        hi: {
            'menu.backup': 'बैकअप',
            'onboard.create': 'वॉलेट बनाएँ', 'onboard.import': 'सीड वाक्यांश आयात करें', 'onboard.questions': 'तीन प्रश्न', 'onboard.pattern': 'ग्राफ़िक पासवर्ड', 'onboard.done': 'वॉलेट तैयार',
            'common.drag': 'खींचें', 'common.name': 'नाम', 'common.description': 'विवरण', 'common.notReceived': 'प्राप्त नहीं हुआ', 'common.received': 'प्राप्त हुआ',
            'app.wallet': 'वॉलेट', 'app.bank': 'बैंक', 'app.agent': 'सहायक',
            'app.menu': 'मेनू', 'app.settings': 'सेटिंग्स', 'app.language': 'भाषा',
            'common.confirm': 'पुष्टि करें', 'common.cancel': 'रद्द करें', 'common.save': 'सहेजें',
            'common.add': 'जोड़ें', 'common.delete': 'हटाएँ', 'common.close': 'बंद करें',
            'common.back': 'पीछे', 'common.next': 'आगे', 'common.search': 'खोजें',
            'common.loading': 'लोड हो रहा है…', 'common.error': 'त्रुटि', 'common.empty': 'खाली',
            'common.all': 'सभी', 'common.more': 'अधिक', 'common.copy': 'कॉपी', 'common.copied': 'कॉपी हो गया',
            'common.min': 'न्यूनतम', 'common.max': 'अधिकतम',
            'wallet.balance': 'शेष', 'wallet.address': 'पता', 'wallet.accounts': 'खाते',
            'wallet.network': 'नेटवर्क', 'wallet.networks': 'नेटवर्क', 'wallet.send': 'भेजें',
            'wallet.receive': 'प्राप्त करें', 'wallet.swap': 'बदलें', 'wallet.transactions': 'लेनदेन',
            'wallet.tokens': 'टोकन', 'wallet.favorites': 'पसंदीदा', 'wallet.amount': 'राशि',
            'wallet.fee': 'शुल्क', 'wallet.total': 'कुल', 'wallet.hot': 'हॉट वॉलेट',
            'wallet.cold': 'कोल्ड वॉलेट',
            'menu.whitelist': 'व्हाइटलिस्ट', 'menu.blacklist': 'ब्लैकलिस्ट',
            'menu.sessions': 'सक्रिय सत्र', 'menu.subscriptions': 'मेरी क्रिप्टो सदस्यताएँ',
            'menu.walletFormat': 'वॉलेट प्रारूप', 'menu.signatureType': 'हस्ताक्षर प्रकार',
            'menu.quantum': 'क्वांटम हस्ताक्षर', 'menu.hotCold': 'हॉट से कोल्ड और वापस',
            'net.popular': 'लोकप्रिय', 'net.standard': 'मानक', 'net.count': '{n} नेटवर्क',
            'ai.ask': 'कुछ भी पूछें…', 'ai.thinking': 'सोच रहा हूँ…',
            'bank.cards': 'कार्ड', 'bank.history': 'इतिहास', 'bank.deposit': 'जमा करें',
            'sub.upgrade': 'अपग्रेड', 'sub.plan': 'प्लान'
        },

        bn: {
            'menu.backup': 'ব্যাকআপ',
            'onboard.create': 'ওয়ালেট তৈরি করুন', 'onboard.import': 'সিড বাক্য আমদানি করুন', 'onboard.questions': 'তিনটি প্রশ্ন', 'onboard.pattern': 'গ্রাফিক পাসওয়ার্ড', 'onboard.done': 'ওয়ালেট প্রস্তুত',
            'common.drag': 'টানুন', 'common.name': 'নাম', 'common.description': 'বিবরণ', 'common.notReceived': 'পাইনি', 'common.received': 'পেয়েছি',
            'app.wallet': 'ওয়ালেট', 'app.bank': 'ব্যাংক', 'app.agent': 'সহকারী',
            'app.menu': 'মেনু', 'app.settings': 'সেটিংস', 'app.language': 'ভাষা',
            'common.confirm': 'নিশ্চিত করুন', 'common.cancel': 'বাতিল', 'common.save': 'সংরক্ষণ',
            'common.add': 'যোগ করুন', 'common.delete': 'মুছুন', 'common.close': 'বন্ধ',
            'common.back': 'পিছনে', 'common.next': 'পরবর্তী', 'common.search': 'খুঁজুন',
            'common.loading': 'লোড হচ্ছে…', 'common.error': 'ত্রুটি', 'common.empty': 'খালি',
            'common.all': 'সব', 'common.more': 'আরও', 'common.copy': 'কপি', 'common.copied': 'কপি হয়েছে',
            'common.min': 'সর্বনিম্ন', 'common.max': 'সর্বোচ্চ',
            'wallet.balance': 'ব্যালেন্স', 'wallet.address': 'ঠিকানা', 'wallet.accounts': 'অ্যাকাউন্ট',
            'wallet.network': 'নেটওয়ার্ক', 'wallet.networks': 'নেটওয়ার্ক', 'wallet.send': 'পাঠান',
            'wallet.receive': 'গ্রহণ', 'wallet.swap': 'বিনিময়', 'wallet.transactions': 'লেনদেন',
            'wallet.tokens': 'টোকেন', 'wallet.favorites': 'প্রিয়', 'wallet.amount': 'পরিমাণ',
            'wallet.fee': 'ফি', 'wallet.total': 'মোট', 'wallet.hot': 'হট ওয়ালেট',
            'wallet.cold': 'কোল্ড ওয়ালেট',
            'menu.whitelist': 'হোয়াইটলিস্ট', 'menu.blacklist': 'ব্ল্যাকলিস্ট',
            'menu.sessions': 'সক্রিয় সেশন', 'menu.subscriptions': 'আমার ক্রিপ্টো সাবস্ক্রিপশন',
            'menu.walletFormat': 'ওয়ালেট ফরম্যাট', 'menu.signatureType': 'স্বাক্ষরের ধরন',
            'menu.quantum': 'কোয়ান্টাম স্বাক্ষর', 'menu.hotCold': 'হট থেকে কোল্ড এবং ফিরে',
            'net.popular': 'জনপ্রিয়', 'net.standard': 'স্ট্যান্ডার্ড', 'net.count': '{n} নেটওয়ার্ক',
            'ai.ask': 'যেকোনো কিছু জিজ্ঞাসা করুন…', 'ai.thinking': 'ভাবছি…',
            'bank.cards': 'কার্ড', 'bank.history': 'ইতিহাস', 'bank.deposit': 'জমা',
            'sub.upgrade': 'আপগ্রেড', 'sub.plan': 'প্ল্যান'
        },

        id: {
            'menu.backup': 'Cadangan',
            'onboard.create': 'Buat dompet', 'onboard.import': 'Impor frasa seed', 'onboard.questions': 'Tiga pertanyaan', 'onboard.pattern': 'Pola grafis', 'onboard.done': 'Dompet siap',
            'common.drag': 'Geser', 'common.name': 'Nama', 'common.description': 'Deskripsi', 'common.notReceived': 'Tidak diterima', 'common.received': 'Diterima',
            'app.wallet': 'Dompet', 'app.bank': 'Bank', 'app.agent': 'Asisten',
            'app.menu': 'Menu', 'app.settings': 'Pengaturan', 'app.language': 'Bahasa',
            'common.confirm': 'Konfirmasi', 'common.cancel': 'Batal', 'common.save': 'Simpan',
            'common.add': 'Tambah', 'common.delete': 'Hapus', 'common.close': 'Tutup',
            'common.back': 'Kembali', 'common.next': 'Lanjut', 'common.search': 'Cari',
            'common.loading': 'Memuat…', 'common.error': 'Kesalahan', 'common.empty': 'Kosong',
            'common.all': 'Semua', 'common.more': 'Lainnya', 'common.copy': 'Salin', 'common.copied': 'Disalin',
            'common.min': 'Min', 'common.max': 'Maks',
            'wallet.balance': 'Saldo', 'wallet.address': 'Alamat', 'wallet.accounts': 'Akun',
            'wallet.network': 'Jaringan', 'wallet.networks': 'Jaringan', 'wallet.send': 'Kirim',
            'wallet.receive': 'Terima', 'wallet.swap': 'Tukar', 'wallet.transactions': 'Transaksi',
            'wallet.tokens': 'Token', 'wallet.favorites': 'Favorit', 'wallet.amount': 'Jumlah',
            'wallet.fee': 'Biaya', 'wallet.total': 'Total', 'wallet.hot': 'Dompet panas',
            'wallet.cold': 'Dompet dingin',
            'menu.whitelist': 'Daftar putih', 'menu.blacklist': 'Daftar hitam',
            'menu.sessions': 'Sesi aktif', 'menu.subscriptions': 'Langganan kripto saya',
            'menu.walletFormat': 'Format dompet', 'menu.signatureType': 'Jenis tanda tangan',
            'menu.quantum': 'Tanda tangan kuantum', 'menu.hotCold': 'Dari panas ke dingin dan kembali',
            'net.popular': 'Populer', 'net.standard': 'Standar', 'net.count': '{n} jaringan',
            'ai.ask': 'Tanyakan apa saja…', 'ai.thinking': 'Berpikir…',
            'bank.cards': 'Kartu', 'bank.history': 'Riwayat', 'bank.deposit': 'Setor',
            'sub.upgrade': 'Tingkatkan', 'sub.plan': 'Paket'
        },

        vi: {
            'menu.backup': 'Sao lưu',
            'onboard.create': 'Tạo ví', 'onboard.import': 'Nhập cụm từ seed', 'onboard.questions': 'Ba câu hỏi', 'onboard.pattern': 'Mật khẩu hình', 'onboard.done': 'Ví đã sẵn sàng',
            'common.drag': 'Kéo', 'common.name': 'Tên', 'common.description': 'Mô tả', 'common.notReceived': 'Chưa nhận', 'common.received': 'Đã nhận',
            'app.wallet': 'Ví', 'app.bank': 'Ngân hàng', 'app.agent': 'Trợ lý',
            'app.menu': 'Menu', 'app.settings': 'Cài đặt', 'app.language': 'Ngôn ngữ',
            'common.confirm': 'Xác nhận', 'common.cancel': 'Hủy', 'common.save': 'Lưu',
            'common.add': 'Thêm', 'common.delete': 'Xóa', 'common.close': 'Đóng',
            'common.back': 'Quay lại', 'common.next': 'Tiếp', 'common.search': 'Tìm kiếm',
            'common.loading': 'Đang tải…', 'common.error': 'Lỗi', 'common.empty': 'Trống',
            'common.all': 'Tất cả', 'common.more': 'Thêm nữa', 'common.copy': 'Sao chép', 'common.copied': 'Đã sao chép',
            'common.min': 'Tối thiểu', 'common.max': 'Tối đa',
            'wallet.balance': 'Số dư', 'wallet.address': 'Địa chỉ', 'wallet.accounts': 'Tài khoản',
            'wallet.network': 'Mạng', 'wallet.networks': 'Mạng', 'wallet.send': 'Gửi',
            'wallet.receive': 'Nhận', 'wallet.swap': 'Hoán đổi', 'wallet.transactions': 'Giao dịch',
            'wallet.tokens': 'Token', 'wallet.favorites': 'Yêu thích', 'wallet.amount': 'Số tiền',
            'wallet.fee': 'Phí', 'wallet.total': 'Tổng', 'wallet.hot': 'Ví nóng',
            'wallet.cold': 'Ví lạnh',
            'menu.whitelist': 'Danh sách trắng', 'menu.blacklist': 'Danh sách đen',
            'menu.sessions': 'Phiên hoạt động', 'menu.subscriptions': 'Đăng ký crypto của tôi',
            'menu.walletFormat': 'Định dạng ví', 'menu.signatureType': 'Loại chữ ký',
            'menu.quantum': 'Chữ ký lượng tử', 'menu.hotCold': 'Từ nóng sang lạnh và ngược lại',
            'net.popular': 'Phổ biến', 'net.standard': 'Tiêu chuẩn', 'net.count': '{n} mạng',
            'ai.ask': 'Hỏi bất cứ điều gì…', 'ai.thinking': 'Đang suy nghĩ…',
            'bank.cards': 'Thẻ', 'bank.history': 'Lịch sử', 'bank.deposit': 'Nạp tiền',
            'sub.upgrade': 'Nâng cấp', 'sub.plan': 'Gói'
        },

        th: {
            'menu.backup': 'สำรองข้อมูล',
            'onboard.create': 'สร้างกระเป๋า', 'onboard.import': 'นำเข้าคำ seed', 'onboard.questions': 'สามคำถาม', 'onboard.pattern': 'รหัสแบบลาก', 'onboard.done': 'กระเป๋าพร้อม',
            'common.drag': 'ลาก', 'common.name': 'ชื่อ', 'common.description': 'คำอธิบาย', 'common.notReceived': 'ไม่ได้รับ', 'common.received': 'ได้รับ',
            'app.wallet': 'กระเป๋าเงิน', 'app.bank': 'ธนาคาร', 'app.agent': 'ผู้ช่วย',
            'app.menu': 'เมนู', 'app.settings': 'ตั้งค่า', 'app.language': 'ภาษา',
            'common.confirm': 'ยืนยัน', 'common.cancel': 'ยกเลิก', 'common.save': 'บันทึก',
            'common.add': 'เพิ่ม', 'common.delete': 'ลบ', 'common.close': 'ปิด',
            'common.back': 'กลับ', 'common.next': 'ถัดไป', 'common.search': 'ค้นหา',
            'common.loading': 'กำลังโหลด…', 'common.error': 'ข้อผิดพลาด', 'common.empty': 'ว่าง',
            'common.all': 'ทั้งหมด', 'common.more': 'เพิ่มเติม', 'common.copy': 'คัดลอก', 'common.copied': 'คัดลอกแล้ว',
            'common.min': 'ต่ำสุด', 'common.max': 'สูงสุด',
            'wallet.balance': 'ยอดคงเหลือ', 'wallet.address': 'ที่อยู่', 'wallet.accounts': 'บัญชี',
            'wallet.network': 'เครือข่าย', 'wallet.networks': 'เครือข่าย', 'wallet.send': 'ส่ง',
            'wallet.receive': 'รับ', 'wallet.swap': 'แลกเปลี่ยน', 'wallet.transactions': 'ธุรกรรม',
            'wallet.tokens': 'โทเคน', 'wallet.favorites': 'รายการโปรด', 'wallet.amount': 'จำนวน',
            'wallet.fee': 'ค่าธรรมเนียม', 'wallet.total': 'รวม', 'wallet.hot': 'กระเป๋าร้อน',
            'wallet.cold': 'กระเป๋าเย็น',
            'menu.whitelist': 'ไวท์ลิสต์', 'menu.blacklist': 'แบล็คลิสต์',
            'menu.sessions': 'เซสชันที่ใช้งาน', 'menu.subscriptions': 'การสมัครคริปโตของฉัน',
            'menu.walletFormat': 'รูปแบบกระเป๋า', 'menu.signatureType': 'ประเภทลายเซ็น',
            'menu.quantum': 'ลายเซ็นควอนตัม', 'menu.hotCold': 'จากร้อนไปเย็นและกลับ',
            'net.popular': 'ยอดนิยม', 'net.standard': 'มาตรฐาน', 'net.count': '{n} เครือข่าย',
            'ai.ask': 'ถามอะไรก็ได้…', 'ai.thinking': 'กำลังคิด…',
            'bank.cards': 'บัตร', 'bank.history': 'ประวัติ', 'bank.deposit': 'ฝาก',
            'sub.upgrade': 'อัปเกรด', 'sub.plan': 'แพ็กเกจ'
        },

        zh: {
            'menu.backup': '备份',
            'onboard.create': '创建钱包', 'onboard.import': '导入助记词', 'onboard.questions': '三个问题', 'onboard.pattern': '手势密码', 'onboard.done': '钱包已就绪',
            'common.drag': '拖动', 'common.name': '名称', 'common.description': '描述', 'common.notReceived': '未收到', 'common.received': '已收到',
            'app.wallet': '钱包', 'app.bank': '银行', 'app.agent': '助手',
            'app.menu': '菜单', 'app.settings': '设置', 'app.language': '语言',
            'common.confirm': '确认', 'common.cancel': '取消', 'common.save': '保存',
            'common.add': '添加', 'common.delete': '删除', 'common.close': '关闭',
            'common.back': '返回', 'common.next': '下一步', 'common.search': '搜索',
            'common.loading': '加载中…', 'common.error': '错误', 'common.empty': '空',
            'common.all': '全部', 'common.more': '更多', 'common.copy': '复制', 'common.copied': '已复制',
            'common.min': '最小', 'common.max': '最大',
            'wallet.balance': '余额', 'wallet.address': '地址', 'wallet.accounts': '账户',
            'wallet.network': '网络', 'wallet.networks': '网络', 'wallet.send': '发送',
            'wallet.receive': '接收', 'wallet.swap': '兑换', 'wallet.transactions': '交易',
            'wallet.tokens': '代币', 'wallet.favorites': '收藏', 'wallet.amount': '金额',
            'wallet.fee': '手续费', 'wallet.total': '总计', 'wallet.hot': '热钱包',
            'wallet.cold': '冷钱包',
            'menu.whitelist': '白名单', 'menu.blacklist': '黑名单',
            'menu.sessions': '活动会话', 'menu.subscriptions': '我的加密订阅',
            'menu.walletFormat': '钱包格式', 'menu.signatureType': '签名类型',
            'menu.quantum': '量子签名', 'menu.hotCold': '从热到冷并返回',
            'net.popular': '热门', 'net.standard': '标准', 'net.count': '{n} 个网络',
            'ai.ask': '问我任何问题…', 'ai.thinking': '思考中…',
            'bank.cards': '卡片', 'bank.history': '历史', 'bank.deposit': '存入',
            'sub.upgrade': '升级', 'sub.plan': '方案'
        },

        ja: {
            'menu.backup': 'バックアップ',
            'onboard.create': 'ウォレットを作成', 'onboard.import': 'シードフレーズをインポート', 'onboard.questions': '3つの質問', 'onboard.pattern': 'パターン認証', 'onboard.done': 'ウォレット準備完了',
            'common.drag': 'ドラッグ', 'common.name': '名前', 'common.description': '説明', 'common.notReceived': '未受領', 'common.received': '受領済み',
            'app.wallet': 'ウォレット', 'app.bank': '銀行', 'app.agent': 'アシスタント',
            'app.menu': 'メニュー', 'app.settings': '設定', 'app.language': '言語',
            'common.confirm': '確認', 'common.cancel': 'キャンセル', 'common.save': '保存',
            'common.add': '追加', 'common.delete': '削除', 'common.close': '閉じる',
            'common.back': '戻る', 'common.next': '次へ', 'common.search': '検索',
            'common.loading': '読み込み中…', 'common.error': 'エラー', 'common.empty': '空',
            'common.all': 'すべて', 'common.more': 'もっと', 'common.copy': 'コピー', 'common.copied': 'コピーしました',
            'common.min': '最小', 'common.max': '最大',
            'wallet.balance': '残高', 'wallet.address': 'アドレス', 'wallet.accounts': 'アカウント',
            'wallet.network': 'ネットワーク', 'wallet.networks': 'ネットワーク', 'wallet.send': '送金',
            'wallet.receive': '受け取る', 'wallet.swap': '交換', 'wallet.transactions': '取引',
            'wallet.tokens': 'トークン', 'wallet.favorites': 'お気に入り', 'wallet.amount': '金額',
            'wallet.fee': '手数料', 'wallet.total': '合計', 'wallet.hot': 'ホットウォレット',
            'wallet.cold': 'コールドウォレット',
            'menu.whitelist': 'ホワイトリスト', 'menu.blacklist': 'ブラックリスト',
            'menu.sessions': 'アクティブセッション', 'menu.subscriptions': '暗号資産サブスク',
            'menu.walletFormat': 'ウォレット形式', 'menu.signatureType': '署名の種類',
            'menu.quantum': '量子署名', 'menu.hotCold': 'ホットからコールドへ',
            'net.popular': '人気', 'net.standard': '規格', 'net.count': '{n} ネットワーク',
            'ai.ask': '何でも聞いてください…', 'ai.thinking': '考えています…',
            'bank.cards': 'カード', 'bank.history': '履歴', 'bank.deposit': '入金',
            'sub.upgrade': 'アップグレード', 'sub.plan': 'プラン'
        },

        ko: {
            'menu.backup': '백업',
            'onboard.create': '지갑 만들기', 'onboard.import': '시드 구문 가져오기', 'onboard.questions': '세 가지 질문', 'onboard.pattern': '패턴 잠금', 'onboard.done': '지갑 준비 완료',
            'common.drag': '끌기', 'common.name': '이름', 'common.description': '설명', 'common.notReceived': '미수령', 'common.received': '수령함',
            'app.wallet': '지갑', 'app.bank': '은행', 'app.agent': '어시스턴트',
            'app.menu': '메뉴', 'app.settings': '설정', 'app.language': '언어',
            'common.confirm': '확인', 'common.cancel': '취소', 'common.save': '저장',
            'common.add': '추가', 'common.delete': '삭제', 'common.close': '닫기',
            'common.back': '뒤로', 'common.next': '다음', 'common.search': '검색',
            'common.loading': '불러오는 중…', 'common.error': '오류', 'common.empty': '비어 있음',
            'common.all': '전체', 'common.more': '더 보기', 'common.copy': '복사', 'common.copied': '복사됨',
            'common.min': '최소', 'common.max': '최대',
            'wallet.balance': '잔액', 'wallet.address': '주소', 'wallet.accounts': '계정',
            'wallet.network': '네트워크', 'wallet.networks': '네트워크', 'wallet.send': '보내기',
            'wallet.receive': '받기', 'wallet.swap': '교환', 'wallet.transactions': '거래',
            'wallet.tokens': '토큰', 'wallet.favorites': '즐겨찾기', 'wallet.amount': '금액',
            'wallet.fee': '수수료', 'wallet.total': '합계', 'wallet.hot': '핫 월렛',
            'wallet.cold': '콜드 월렛',
            'menu.whitelist': '화이트리스트', 'menu.blacklist': '블랙리스트',
            'menu.sessions': '활성 세션', 'menu.subscriptions': '내 크립토 구독',
            'menu.walletFormat': '지갑 형식', 'menu.signatureType': '서명 유형',
            'menu.quantum': '양자 서명', 'menu.hotCold': '핫에서 콜드로 그리고 뒤로',
            'net.popular': '인기', 'net.standard': '표준', 'net.count': '{n}개 네트워크',
            'ai.ask': '무엇이든 물어보세요…', 'ai.thinking': '생각 중…',
            'bank.cards': '카드', 'bank.history': '내역', 'bank.deposit': '입금',
            'sub.upgrade': '업그레이드', 'sub.plan': '요금제'
        }
    };

    // ==================================================================
    // Движок
    // ==================================================================

    var current = 'en';
    var listeners = [];

    function storage() {
        try { return (typeof localStorage !== 'undefined') ? localStorage : null; } catch (e) { return null; }
    }

    function isLang(code) { return !!(code && DICT[code] && LANGS.some(function (l) { return l.code === code; })); }

    /// @dev Перевод. Всегда что-то возвращает: нет ключа в языке — берём
    ///      английский, нет и там — вернём сам ключ. Пустоты не бывает.
    function t(key, vars) {
        var v = (DICT[current] && DICT[current][key]);
        if (v === undefined) v = EN[key];
        if (v === undefined) v = key;
        if (vars) {
            Object.keys(vars).forEach(function (k) {
                v = v.split('{' + k + '}').join(String(vars[k]));
            });
        }
        return v;
    }


    /// @dev ИСХОДНЫЕ СТРОКИ РАЗДЕЛОВ: русский текст дизайнов -> ключ словаря.
    ///      Разделы пришли из готовых макетов со своими русскими подписями.
    ///      Мы НЕ правим их разметку: при смене языка движок проходит по
    ///      текстовым узлам и подменяет знакомые строки. Сопоставление идёт с
    ///      УЖЕ СУЩЕСТВУЮЩИМИ ключами, поэтому новых переводов не требуется.
    var SRC = {
        'БАЛАНС': 'wallet.balance',
        'АДРЕС': 'wallet.address', 'АДРЕСА': 'wallet.accounts',
        'СЕТЬ': 'wallet.network', 'СЕТИ': 'wallet.networks',
        'ОТПРАВИТЬ': 'wallet.send', 'ПОЛУЧИТЬ': 'wallet.receive',
        'ОБМЕН': 'wallet.swap', 'ОБМЕНЯТЬ': 'wallet.swap', 'SWAP': 'wallet.swap',
        'ТРАНЗАКЦИИ': 'wallet.transactions', 'ИСТОРИЯ': 'bank.history',
        'ТОКЕНЫ': 'wallet.tokens', 'ИЗБРАННЫЕ': 'wallet.favorites',
        'СУММА': 'wallet.amount', 'КОМИССИЯ': 'wallet.fee', 'ИТОГО': 'wallet.total',
        'ТЕПЛО': 'wallet.hot', 'ТЁПЛЫЙ': 'wallet.hot',
        'ХОЛОД': 'wallet.cold', 'ХОЛОДНЫЙ': 'wallet.cold',
        'ПОДТВЕРДИТЬ': 'common.confirm', 'ГОТОВО': 'common.confirm',
        'ОТМЕНА': 'common.cancel', 'ОТМЕНИТЬ': 'common.cancel',
        'СОХРАНИТЬ': 'common.save', 'ДОБАВИТЬ': 'common.add',
        'УДАЛИТЬ': 'common.delete', 'ЗАКРЫТЬ': 'common.close',
        'НАЗАД': 'common.back', 'ДАЛЕЕ': 'common.next',
        'ПОИСК': 'common.search', 'НАЙТИ': 'common.search',
        'ЗАГРУЗКА...': 'common.loading', 'ОШИБКА': 'common.error',
        'ВСЕ': 'common.all', 'ВСЯ': 'common.all', 'ЕЩЁ': 'common.more',
        'КОПИРОВАТЬ': 'common.copy', 'МИН': 'common.min', 'МАКС': 'common.max',
        'ВАЙТЛИСТ': 'menu.whitelist', 'БЛЭКЛИСТ': 'menu.blacklist',
        'АКТИВНЫЕ СЕССИИ': 'menu.sessions', 'СЕССИИ': 'menu.sessions',
        'ПОДПИСКИ': 'menu.subscriptions',
        'КВАНТОВАЯ ПОДПИСЬ': 'menu.quantum',
        'КАРТЫ': 'bank.cards', 'ДЕПОЗИТ': 'bank.deposit',
        'АССИСТЕНТ': 'app.agent', 'ЯЗЫК': 'app.language', 'МЕНЮ': 'app.menu',
        'ПОПУЛЯРНЫЕ': 'net.popular', 'СТАНДАРТ': 'net.standard',

        /* строки из разметки разделов */
        'ПОДТВЕРЖДЕНИЕ': 'common.confirm',
        'КОМИССИЯ СЕТИ': 'wallet.fee',
        'СЕРВЕР ОБРАБАТЫВАЕТ...': 'common.loading',
        'АДРЕС КОШЕЛЬКА': 'wallet.address',
        'ТОКЕНОВ': 'wallet.tokens',
        'СТОИМОСТЬ': 'wallet.total',
        'ОТДАЁТЕ': 'wallet.send',
        'ПОЛУЧАЕТЕ': 'wallet.receive',
        'СОХРАНИТЬ ПОДПИСКУ': 'common.save',
        '+ ДОБАВИТЬ': 'common.add',
        'КОЛИЧЕСТВО ПОДПИСЕЙ': 'net.count',
        'ПОДПИСАТЬ': 'sub.upgrade',
        'ЦЕНА ЗА ПОДПИСЬ': 'sub.plan',
        'ЕЖЕМЕСЯЧНО': 'sub.plan',
        'СВЕРНУТЬ': 'common.min',
        'ТЯНИТЕ →': 'common.drag',
        'ТЯНИ →': 'common.drag',
        'ИМЯ': 'common.name',
        'ИМЯ (НЕОБЯЗАТЕЛЬНО)': 'common.name',
        'ОПИСАНИЕ': 'common.description',
        'ОПИСАНИЕ (НЕОБЯЗАТЕЛЬНО)': 'common.description',
        'НЕ ПОЛУЧИЛ': 'common.notReceived',
        'ПОЛУЧИЛ': 'common.received',
        'ФАЙЛ НЕ ВЫБРАН': 'common.empty',
        /* подписи онбординга */
        'СОЗДАТЬ КОШЕЛЁК': 'onboard.create',
        'ИМПОРТ SEED-ФРАЗЫ': 'onboard.import',
        'ТРИ ВОПРОСА': 'onboard.questions',
        'ГРАФИЧЕСКИЙ ПАРОЛЬ': 'onboard.pattern',
        'КОШЕЛЁК ГОТОВ': 'onboard.done',
        'МОИ АДРЕСА': 'wallet.accounts',
        'ИНИЦИАЛИЗАЦИЯ...': 'common.loading',
        '📋 СКОПИРОВАТЬ СИД-ФРАЗУ': 'common.copy',
        'СКОПИРОВАТЬ СИД-ФРАЗУ': 'common.copy',
        'Я ЗАПИСАЛ(А) — ДАЛЬШЕ': 'common.next',
        '← НАЗАД К ПАТТЕРНУ': 'common.back',
        'ОБА': 'common.all',
    };

    /// @dev Перевести текстовые узлы разделов по словарю исходных строк.
    function applyText(rootEl) {
        var root = rootEl || (typeof document !== 'undefined' ? document : null);
        if (!root || typeof document.createTreeWalker !== 'function') return 0;
        var w = document.createTreeWalker(root, 4 /* SHOW_TEXT */, null);
        var nodes = [], node;
        while ((node = w.nextNode())) nodes.push(node);
        var n = 0;
        nodes.forEach(function (nd) {
            var raw = nd.nodeValue;
            if (!raw) return;
            /* [ПРАВКА] Узлы внутри [data-no-i18n] не трогаем: иначе кнопки с
               готовым текстом («Готово») подменяются словарными значениями. */
            var par = nd.parentElement;
            if (par && par.closest && par.closest('[data-no-i18n]')) return;
            var key = raw.trim();
            // ВАЖНО: ключ запоминаем на самом узле. Иначе перевод необратим:
            // перевели на английский — русская строка исчезла, и вернуться
            // к ней уже нечем (словарь знает только русские исходники).
            if (!nd.__srcKey) {
                if (!key) return;
                var dictKey = SRC[key.toUpperCase()];
                if (!dictKey) return;
                nd.__srcKey = dictKey;
            }
            var val = t(nd.__srcKey);
            if (!val) return;
            var lead = raw.match(/^\s*/)[0], tail = raw.match(/\s*$/)[0];
            var next = lead + val + tail;
            if (next === raw) return;
            nd.nodeValue = next;
            n++;
        });
        return n;
    }

    /// @dev Перерисовать страницу: тексты, placeholder-ы, подсказки, направление.
    function apply(rootEl) {
        var root = rootEl || (typeof document !== 'undefined' ? document : null);
        if (!root) return 0;
        var n = 0;

        // ВАЖНО: атрибуты называются data-t*, а НЕ data-i18n*.
        // В дизайне кошелька уже есть свой applyTranslations(), который
        // перебирает ВСЕ [data-i18n] и подставляет t(ключ); для незнакомых
        // ключей он возвращает сам ключ и затирал наши тексты.
        // Разные атрибуты — каждый движок работает только со своими.
        // тексты разделов из дизайнов (по словарю исходных строк)
        applyText(root);

        root.querySelectorAll('[data-t]').forEach(function (el) {
            el.textContent = t(el.getAttribute('data-t'));
            n++;
        });
        root.querySelectorAll('[data-t-ph]').forEach(function (el) {
            el.setAttribute('placeholder', t(el.getAttribute('data-t-ph')));
            n++;
        });
        root.querySelectorAll('[data-t-title]').forEach(function (el) {
            el.setAttribute('title', t(el.getAttribute('data-t-title')));
            n++;
        });

        var info = lang();
        if (info && root.documentElement) {
            root.documentElement.setAttribute('lang', info.code);
            root.documentElement.setAttribute('dir', info.rtl ? 'rtl' : 'ltr');
        }
        return n;
    }

    function set(code) {
        if (!isLang(code)) return false;
        current = code;
        var s = storage();
        if (s) s.setItem('clandai_lang', code);
        apply();
        listeners.forEach(function (fn) { try { fn(code); } catch (e) {} });
        return true;
    }

    function lang() {
        for (var i = 0; i < LANGS.length; i++) if (LANGS[i].code === current) return LANGS[i];
        return LANGS[0];
    }

    function onChange(fn) { listeners.push(fn); }

    /// @dev Чего не хватает: проверяется инструментом, а не глазами.
    function coverage() {
        return LANGS.map(function (l) {
            var d = DICT[l.code] || {};
            var keys = Object.keys(EN);
            var missing = keys.filter(function (k) { return d[k] === undefined; });
            return { code: l.code, total: keys.length, translated: keys.length - missing.length, missing: missing };
        });
    }

    // Автовыбор: сохранённый -> язык системы -> английский.
    (function init() {
        var s = storage();
        var saved = s ? s.getItem('clandai_lang') : null;
        if (isLang(saved)) { current = saved; return; }
        var nav = (typeof navigator !== 'undefined' && (navigator.language || navigator.userLanguage)) || '';
        var two = String(nav).slice(0, 2).toLowerCase();
        if (isLang(two)) current = two;
    })();

    return {
        LANGS: LANGS,
        EN: EN,
        DICT: DICT,
        t: t,
        set: set,
        lang: lang,
        apply: apply,
        applyText: applyText,
        SRC: SRC,
        onChange: onChange,
        coverage: coverage,
        keys: function () { return Object.keys(EN); }
    };
});
