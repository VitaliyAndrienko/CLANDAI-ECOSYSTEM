/* =========================================================================
   vault.js — хранилище ключей кошелька.

   РАБОТАЕТ ТОЛЬКО В ГЛАВНОМ ПРОЦЕССЕ. Страница не получает ни сид-фразу,
   ни приватные ключи: она просит «подпиши вот это», получает подпись.

   Формат совместим с дизайном кошелька v9.3, чтобы уже созданные файлы
   открывались:
     Argon2id {time:3, mem:65536, hashLen:32, parallelism:1}
     AES-256-GCM, IV 12 байт, tag 128, additionalData = строка
     { version:9, type:'clandai-local', address, salt, iv, data, aad,
       questions, hasPassphrase, createdAt }

   Криптография НЕ реализуется здесь: Argon2id, BIP-39/32 и генератор
   случайных чисел ПЕРЕДАЮТСЯ снаружи (инъекция зависимостей). Причины:
     * BIP-39 и Argon2id нельзя писать руками — это источники уязвимостей;
     * модуль остаётся без npm-зависимостей и поэтому проверяем в Node
       тем же кодом, что работает в приложении;
     * в браузере и в Node подставляются разные реализации — интерфейс один.
   ========================================================================= */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.GuardVault = factory();
})(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    // Параметры из дизайна v9.3 (менять нельзя: иначе старые файлы не откроются)
    var ARGON2 = { time: 3, mem: 65536, hashLen: 32, parallelism: 1 };
    var VAULT_VERSION = 9;
    var VAULT_TYPE = 'clandai-local';
    var BACKUP_TYPE = 'clandai-backup';
    var DEFAULT_PATH = "m/44'/60'/0'/0/0";

    // Пороговая схема — основная. Значения по умолчанию из дизайна заказчика
    // (софт генерации файла шифрования): Total 6, Threshold 4.
    var DEFAULT_THRESHOLD = 4;
    var DEFAULT_TOTAL = 6;
    var SHARE_TYPE = 'clandai-shamir-share';
    var LEGACY_SHARE_TYPE = 'clandai-backup';   // две доли XOR (v9.3) — только чтение

    // ---------------------------------------------------------------------
    // base64 (в браузере и в Node одинаково)
    // ---------------------------------------------------------------------

    /// @dev Только btoa/atob/TextEncoder — они есть и в браузере, и в Node 24.
    ///      Buffer здесь использовать нельзя: в браузере его нет.
    function bufToB64(buf) {
        var b = new Uint8Array(buf);
        var s = '';
        for (var i = 0; i < b.length; i++) s += String.fromCharCode(b[i]);
        return btoa(s);
    }

    function b64ToBuf(b64) {
        var s = atob(b64);
        var out = new Uint8Array(s.length);
        for (var i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
        return out;
    }

    function utf8(str) { return new TextEncoder().encode(str); }
    function fromUtf8(bytes) { return new TextDecoder().decode(bytes); }

    // =====================================================================
    // GF(256) — арифметика поля для пороговой схемы.
    // Полином 0x11b, генератор 3. Сложение в GF(256) — это XOR.
    // =====================================================================

    var GF_EXP = new Uint8Array(512);
    var GF_LOG = new Uint8Array(256);
    (function buildGfTables() {
        var x = 1;
        for (var i = 0; i < 255; i++) {
            GF_EXP[i] = x;
            GF_LOG[x] = i;
            var x2 = (x << 1) & 0xff;
            if (x & 0x80) x2 ^= 0x1b;   // приведение по модулю 0x11b
            x = x2 ^ x;                 // умножение на 3 (генератор)
        }
        for (var j = 255; j < 512; j++) GF_EXP[j] = GF_EXP[j - 255];
    })();

    function gfMul(a, b) {
        if (a === 0 || b === 0) return 0;
        return GF_EXP[GF_LOG[a] + GF_LOG[b]];
    }

    function gfDiv(a, b) {
        if (b === 0) throw new Error('GF_DIVISION_BY_ZERO');
        if (a === 0) return 0;
        return GF_EXP[GF_LOG[a] - GF_LOG[b] + 255];
    }

    /// @dev Значение многочлена в точке (схема Горнера). coeffs[0] — свободный член.
    function gfPolyEval(coeffs, x) {
        var y = 0;
        for (var i = coeffs.length - 1; i >= 0; i--) y = gfMul(y, x) ^ coeffs[i];
        return y;
    }

    /// @dev Делит секрет на `total` долей с порогом `threshold`.
    ///      Любые `threshold` долей восстанавливают секрет, любые
    ///      `threshold - 1` не дают о нём НИЧЕГО.
    ///
    ///      Старший коэффициент для каждого байта принудительно ненулевой:
    ///      иначе для байта с нулевым старшим коэффициентом фактический порог
    ///      оказался бы ниже заявленного — классическая ошибка реализаций Shamir.
    function splitSecret(secret, threshold, total, randomBytes) {
        if (!(threshold >= 2)) throw new Error('THRESHOLD_TOO_LOW');
        if (!(total >= threshold)) throw new Error('TOTAL_BELOW_THRESHOLD');
        if (total > 255) throw new Error('TOO_MANY_SHARES');

        var shares = [];
        for (var i = 0; i < total; i++) shares.push({ x: i + 1, y: new Uint8Array(secret.length) });

        for (var p = 0; p < secret.length; p++) {
            var coeffs = new Uint8Array(threshold);
            coeffs[0] = secret[p];
            var rnd = randomBytes(threshold - 1);
            for (var j = 1; j < threshold; j++) coeffs[j] = rnd[j - 1];
            while (coeffs[threshold - 1] === 0) coeffs[threshold - 1] = randomBytes(1)[0];
            for (var s = 0; s < total; s++) shares[s].y[p] = gfPolyEval(coeffs, shares[s].x);
        }
        return shares;
    }

    /// @dev Восстанавливает секрет по долям (интерполяция Лагранжа в точке 0).
    function combineSecret(points) {
        if (!points || points.length < 2) throw new Error('NOT_ENOUGH_SHARES');
        var len = points[0].y.length;
        var seen = {};
        for (var i = 0; i < points.length; i++) {
            if (points[i].y.length !== len) throw new Error('SHARE_LENGTH_MISMATCH');
            if (points[i].x < 1 || points[i].x > 255) throw new Error('BAD_SHARE_INDEX');
            if (seen[points[i].x]) throw new Error('DUPLICATE_SHARE_INDEX');
            seen[points[i].x] = true;
        }
        var secret = new Uint8Array(len);
        for (var p = 0; p < len; p++) {
            var acc = 0;
            for (var a = 0; a < points.length; a++) {
                var num = 1, den = 1;
                for (var b = 0; b < points.length; b++) {
                    if (a === b) continue;
                    num = gfMul(num, points[b].x);
                    den = gfMul(den, points[a].x ^ points[b].x);
                }
                acc ^= gfMul(points[a].y[p], gfDiv(num, den));
            }
            secret[p] = acc;
        }
        return secret;
    }

    function xorBytes(a, b) {
        if (a.length !== b.length) throw new Error('SHARE_LENGTH_MISMATCH');
        var o = new Uint8Array(a.length);
        for (var i = 0; i < a.length; i++) o[i] = a[i] ^ b[i];
        return o;
    }

    // ---------------------------------------------------------------------
    // Пароли-обёртки (совпадают с дизайном)
    // ---------------------------------------------------------------------

    function buildPinPassword(pin) { return 'CLANDAIv9|pin:' + pin; }

    function buildBackupPassword(questions, answers, pattern, pin) {
        var qa = questions.map(function (q, i) {
            return String(q).trim().toLowerCase() + '::' + String(answers[i] || '').trim().toLowerCase();
        }).join('||');
        return 'CLANDAIv9|backup:' + qa + '|pattern:' + pattern + '|pin:' + pin;
    }

    // ---------------------------------------------------------------------
    // Хранилище
    // ---------------------------------------------------------------------

    /// @dev deps: {
    ///        argon2id({password, salt, parallelism, iterations, memorySize, hashLength}) -> Uint8Array
    ///        mnemonic: { generate(strengthBits) -> phrase, validate(phrase) -> bool }
    ///        hd: { fromPhrase(phrase, passphrase) -> { derivePath(path) -> { address, privateKey } } }
    ///        randomBytes(n) -> Uint8Array
    ///      }
    function create(deps) {
        if (!deps || !deps.argon2id) throw new Error('vault: нужен argon2id');
        if (!deps.mnemonic || !deps.hd) throw new Error('vault: нужны mnemonic и hd');
        if (!deps.randomBytes) throw new Error('vault: нужен randomBytes');

        var subtle = (typeof crypto !== 'undefined' && crypto.subtle) ? crypto.subtle
            : (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.subtle
                ? globalThis.crypto.subtle : null);
        if (!subtle) throw new Error('vault: нет WebCrypto (AES-GCM)');

        // Держим расшифрованную фразу в замыкании и НЕ отдаём её наружу.
        var unlocked = null;   // { phrase, passphrase, accounts }

        // ---- Argon2id -> 32-байтовый ключ ----
        async function argon2Key(password, salt) {
            var out = await deps.argon2id({
                password: password,
                salt: salt,
                parallelism: ARGON2.parallelism,
                iterations: ARGON2.time,
                memorySize: ARGON2.mem,
                hashLength: ARGON2.hashLen
            });
            return new Uint8Array(out);
        }

        // ---- AES-256-GCM ----
        async function encryptAES(plaintext, key, aad) {
            var iv = deps.randomBytes(12);
            var alg = { name: 'AES-GCM', iv: iv, tagLength: 128 };
            if (aad) alg.additionalData = utf8(aad);
            var ct = await subtle.encrypt(alg, await subtle.importKey('raw', key, 'AES-GCM', false, ['encrypt']), utf8(plaintext));
            return { iv: bufToB64(iv), data: bufToB64(ct), aad: aad || '' };
        }

        async function decryptAES(ivB64, dataB64, key, aad) {
            var alg = { name: 'AES-GCM', iv: b64ToBuf(ivB64), tagLength: 128 };
            if (aad) alg.additionalData = utf8(aad);
            var pt = await subtle.decrypt(alg, await subtle.importKey('raw', key, 'AES-GCM', false, ['decrypt']), b64ToBuf(dataB64));
            return fromUtf8(new Uint8Array(pt));
        }

        // ---- сид-фразы и ключи ----

        function generatePhrase(words) {
            var bits = (words === 24) ? 256 : 128;
            return deps.mnemonic.generate(bits);
        }

        function validatePhrase(phrase) {
            if (typeof phrase !== 'string') return false;
            return deps.mnemonic.validate(phrase.trim().toLowerCase().replace(/\s+/g, ' '));
        }

        /// @dev Адреса выводятся из фразы детерминированно по путям BIP-44.
        function deriveAccounts(phrase, passphrase, paths) {
            var hd = deps.hd.fromPhrase(phrase, passphrase || '');
            return (paths || [DEFAULT_PATH]).map(function (p, i) {
                var node = hd.derivePath(p);
                return { id: i === 0 ? 'main' : 'acc' + i, path: p, address: node.address, privateKey: node.privateKey };
            });
        }

        // ---- создание хранилища ----

        /// @dev Возвращает { vault, phrase, accounts }. Фраза нужна ОДИН раз —
        ///      чтобы показать пользователю для записи. Наружу её отдаёт
        ///      вызывающий (главный процесс), не страница.
        async function seal(opts) {
            var phrase = opts.phrase && opts.phrase.trim() ? opts.phrase.trim().toLowerCase().replace(/\s+/g, ' ')
                : generatePhrase(opts.words || 12);
            if (!validatePhrase(phrase)) throw new Error('BAD_MNEMONIC');
            if (!opts.pin || String(opts.pin).length < 6) throw new Error('PIN_TOO_SHORT');

            var accounts = deriveAccounts(phrase, opts.passphrase, opts.paths);
            var salt = deps.randomBytes(16);
            var key = await argon2Key(buildPinPassword(opts.pin), salt);
            var enc = await encryptAES(phrase, key, 'vault');

            var vault = {
                version: VAULT_VERSION,
                type: VAULT_TYPE,
                address: accounts[0].address,
                salt: bufToB64(salt),
                iv: enc.iv,
                data: enc.data,
                aad: enc.aad,
                questions: opts.questions || [],
                hasPassphrase: !!opts.passphrase,
                createdAt: new Date().toISOString()
            };

            // Только что созданный кошелёк считается разблокированным: фраза
            // уже в памяти, а пользователь сию секунду доказал, что владеет ею.
            // Без этого сразу после создания падали бы резервные копии (LOCKED),
            // а статус показывал бы null вместо адреса — проверено самопроверкой.
            unlocked = { phrase: phrase, passphrase: opts.passphrase || '', accounts: accounts };

            return { vault: vault, phrase: phrase, accounts: accounts };
        }

        /// @dev Открывает хранилище. Бросает WRONG_PIN (неверный пароль) или
        ///      AUTH_TAG_MISMATCH (файл повреждён: GCM не сходится).
        async function open(vault, pin, passphrase) {
            if (!vault || vault.type !== VAULT_TYPE) throw new Error('BAD_VAULT');
            var key = await argon2Key(buildPinPassword(pin), b64ToBuf(vault.salt));
            var phrase = await decryptAES(vault.iv, vault.data, key, vault.aad || 'vault');
            if (!validatePhrase(phrase)) throw new Error('WRONG_PIN');
            var accounts = deriveAccounts(phrase, passphrase, [DEFAULT_PATH]);
            // Сверяем адрес: если passphrase не тот, адрес не совпадёт.
            if (vault.address && accounts[0].address.toLowerCase() !== String(vault.address).toLowerCase()) {
                throw new Error('WRONG_PASSPHRASE');
            }
            unlocked = { phrase: phrase, passphrase: passphrase || '', accounts: accounts };
            return { address: accounts[0].address, accounts: accounts };
        }

        function lock() { unlocked = null; }

        function isUnlocked() { return !!unlocked; }

        function address() { return unlocked ? unlocked.accounts[0].address : null; }

        function accounts() { return unlocked ? unlocked.accounts.slice() : []; }

        /// @dev Подпись digest-а ключом владельца. Ключ не покидает модуль.
        ///      sign — функция (privateKey, digestHex) -> signature.
        async function signDigest(digestHex, index, sign) {
            if (!unlocked) throw new Error('LOCKED');
            var acc = unlocked.accounts[index || 0];
            if (!acc) throw new Error('NO_ACCOUNT');
            return sign(acc.privateKey, digestHex);
        }

        // =================================================================
        // РЕЗЕРВНЫЕ КОПИИ
        // Основная схема — пороговая (Shamir, «k из n»).
        // XOR двух долей из v9.3 оставлен ТОЛЬКО для чтения старых файлов.
        // =================================================================

        /// @dev Пороговая схема. Каждая доля шифруется своим ключом, а индекс
        ///      доли входит в AAD — подменить или перепутать доли нельзя.
        async function makeShares(phrase, opts) {
            var k = opts.threshold || DEFAULT_THRESHOLD;
            var n = opts.total || DEFAULT_TOTAL;
            var raw = splitSecret(utf8(phrase), k, n, deps.randomBytes);
            var pwd = buildBackupPassword(opts.questions, opts.answers, opts.pattern, opts.pin);
            var out = [];
            for (var i = 0; i < raw.length; i++) {
                var salt = deps.randomBytes(16);
                var key = await argon2Key(pwd, salt);
                var aad = 'shamir:' + raw[i].x;
                var enc = await encryptAES(bufToB64(raw[i].y), key, aad);
                out.push({
                    version: VAULT_VERSION,
                    type: SHARE_TYPE,
                    share: i + 1,
                    x: raw[i].x,
                    threshold: k,
                    total: n,
                    address: opts.address,
                    salt: bufToB64(salt),
                    iv: enc.iv,
                    data: enc.data,
                    aad: aad,
                    questions: (opts.questions || []).slice(),
                    createdAt: new Date().toISOString()
                });
            }
            return out;
        }

        /// @dev Резервная копия из УЖЕ РАЗБЛОКИРОВАННОГО хранилища.
        ///      Фраза при этом НЕ покидает модуль: страница получает только
        ///      зашифрованные доли, которые и предназначены для сохранения.
        async function makeSharesUnlocked(opts) {
            if (!unlocked) throw new Error('LOCKED');
            return makeShares(unlocked.phrase, opts);
        }

        /// @dev Восстановление. Само определяет схему: пороговые доли или
        ///      старые XOR-файлы v9.3, поэтому старые копии продолжают работать.
        async function restoreShares(files, opts) {
            if (!files || !files.length) throw new Error('NO_SHARES');

            if (files[0].type === LEGACY_SHARE_TYPE) {
                if (files.length !== 2) throw new Error('NEED_TWO_SHARES');
                return combineXorShares(files[0], files[1], opts);
            }
            if (files[0].type !== SHARE_TYPE) throw new Error('UNKNOWN_SHARE_TYPE');

            var k = files[0].threshold;
            if (!(k >= 2)) throw new Error('BAD_THRESHOLD_IN_FILE');
            if (files.length < k) {
                throw new Error('NOT_ENOUGH_SHARES: нужно ' + k + ', дано ' + files.length);
            }
            var addr = String(files[0].address).toLowerCase();
            for (var i = 1; i < files.length; i++) {
                if (String(files[i].address).toLowerCase() !== addr) throw new Error('SHARES_FROM_DIFFERENT_WALLETS');
                if (files[i].threshold !== k) throw new Error('THRESHOLD_MISMATCH');
                if (files[i].total !== files[0].total) throw new Error('TOTAL_MISMATCH');
            }

            var pwd = buildBackupPassword(opts.questions, opts.answers, opts.pattern, opts.pin);
            var points = [];
            for (var j = 0; j < files.length; j++) {
                var f = files[j];
                var key = await argon2Key(pwd, b64ToBuf(f.salt));
                var b64 = await decryptAES(f.iv, f.data, key, f.aad || ('shamir:' + f.x));
                points.push({ x: f.x, y: b64ToBuf(b64) });
            }
            var phrase = fromUtf8(combineSecret(points));
            if (!validatePhrase(phrase)) throw new Error('WRONG_ANSWERS_OR_PIN');
            return phrase;
        }

        /// @dev ЛЕГАСИ: две XOR-доли из дизайна v9.3. Оставлено, чтобы уже
        ///      созданные файлы читались. Новые копии делает makeShares.
        async function makeXorShares(phrase, opts) {
            var secret = utf8(phrase);
            var share2 = deps.randomBytes(secret.length);
            var share1 = xorBytes(secret, share2);
            var pwd = buildBackupPassword(opts.questions, opts.answers, opts.pattern, opts.pin);
            var out = [];
            var parts = [share1, share2];
            for (var i = 0; i < 2; i++) {
                var salt = deps.randomBytes(16);
                var key = await argon2Key(pwd, salt);
                var enc = await encryptAES(bufToB64(parts[i]), key, 'share' + (i + 1));
                out.push({
                    version: VAULT_VERSION,
                    type: LEGACY_SHARE_TYPE,
                    share: i + 1,
                    total: 2,
                    address: opts.address,
                    salt: bufToB64(salt),
                    iv: enc.iv,
                    data: enc.data,
                    aad: enc.aad,
                    questions: (opts.questions || []).slice(),
                    createdAt: new Date().toISOString()
                });
            }
            return out;
        }

        async function combineXorShares(file1, file2, opts) {
            if (!file1 || !file2) throw new Error('NEED_TWO_SHARES');
            if (String(file1.address).toLowerCase() !== String(file2.address).toLowerCase()) {
                throw new Error('SHARES_FROM_DIFFERENT_WALLETS');
            }
            var pwd = buildBackupPassword(opts.questions, opts.answers, opts.pattern, opts.pin);
            var parts = [];
            for (var i = 0; i < 2; i++) {
                var f = i === 0 ? file1 : file2;
                var key = await argon2Key(pwd, b64ToBuf(f.salt));
                var b64 = await decryptAES(f.iv, f.data, key, f.aad || ('share' + (i + 1)));
                parts.push(b64ToBuf(b64));
            }
            var phrase = fromUtf8(xorBytes(parts[0], parts[1]));
            if (!validatePhrase(phrase)) throw new Error('WRONG_ANSWERS_OR_PIN');
            return phrase;
        }

        return {
            ARGON2: ARGON2,
            DEFAULT_PATH: DEFAULT_PATH,
            generatePhrase: generatePhrase,
            validatePhrase: validatePhrase,
            deriveAccounts: deriveAccounts,
            seal: seal,
            open: open,
            lock: lock,
            isUnlocked: isUnlocked,
            address: address,
            accounts: accounts,
            signDigest: signDigest,
            makeShares: makeShares,
            makeSharesUnlocked: makeSharesUnlocked,
            restoreShares: restoreShares,
            makeXorShares: makeXorShares,
            combineXorShares: combineXorShares,
            // для проверок
            _internal: { buildPinPassword: buildPinPassword, buildBackupPassword: buildBackupPassword, xorBytes: xorBytes, argon2Key: argon2Key }
        };
    }

    return {
        create: create,
        ARGON2: ARGON2,
        VAULT_VERSION: VAULT_VERSION,
        DEFAULT_PATH: DEFAULT_PATH,
        DEFAULT_THRESHOLD: DEFAULT_THRESHOLD,
        DEFAULT_TOTAL: DEFAULT_TOTAL,
        SHARE_TYPE: SHARE_TYPE,
        LEGACY_SHARE_TYPE: LEGACY_SHARE_TYPE,
        // пороговая схема — чистые функции, проверяются отдельно от хранилища
        splitSecret: splitSecret,
        combineSecret: combineSecret,
        gfMul: gfMul,
        gfDiv: gfDiv
    };
});
