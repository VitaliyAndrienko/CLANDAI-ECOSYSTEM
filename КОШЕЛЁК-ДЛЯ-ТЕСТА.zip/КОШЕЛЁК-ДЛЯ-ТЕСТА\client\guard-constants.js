/* =========================================================================
   guard-constants.js — АВТОГЕНЕРАЦИЯ из ABI, не править руками.
   Обновить: npm run build && node tools/gen-constants.js

   Это ЗНАЧЕНИЯ ПО УМОЛЧАНИЮ. В рантайме клиент должен читать их с цепи
   (это публичные view-функции), чтобы исключить расхождение с деплоем.
   ========================================================================= */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.GuardConstants = factory();
})(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    /// @dev Имя контракта -> { ИМЯ_КОНСТАНТЫ: тип }
    var TYPES = {
        'SmartWalletGuard': {
            'DOMAIN_SEPARATOR': 'bytes32',
            'NATIVE': 'address',
            'PERM_APP_VERIFY': 'uint256',
            'PERM_COLD_WARM': 'uint256',
            'PERM_EMERGENCY': 'uint256',
            'PERM_P2P': 'uint256',
            'PERM_SECURITY': 'uint256',
            'PERM_TRADING': 'uint256',
            'VERSION': 'string'
        },
        'SmartWalletPolicyOps': {
            'DOMAIN_SEPARATOR': 'bytes32',
            'NATIVE': 'address',
            'VERSION': 'string'
        },
        'SmartWalletPolicyRegistry': {
            'BPS_DENOMINATOR': 'uint256',
            'MAX_REGISTRY_ITEMS': 'uint256',
            'NATIVE': 'address',
            'PRICE_SCALE': 'uint256',
            'USD_UNIT': 'uint256',
            'VERSION': 'string'
        },
        'SmartWalletGuardOwnerRegistry': {
            'CRITICAL_THRESHOLD': 'uint256',
            'HOT_OWNERS': 'uint256',
            'HOT_THRESHOLD': 'uint256',
            'MAX_WALLETS_PER_CLASS': 'uint256',
            'TOTAL_OWNERS': 'uint256',
            'VERSION': 'string'
        },
        'SmartWalletGuardSubscriptions': {
            'DOMAIN_SEPARATOR': 'bytes32',
            'MAX_PLAN_CONFIGS_PER_CLAIM': 'uint256',
            'NATIVE': 'address',
            'PERM_APP_VERIFY': 'uint256',
            'PERM_COLD_WARM': 'uint256',
            'PERM_EMERGENCY': 'uint256',
            'PERM_P2P': 'uint256',
            'PERM_SECURITY': 'uint256',
            'PERM_TRADING': 'uint256',
            'PLAN_FREE': 'uint8',
            'PLAN_PREMIUM': 'uint8',
            'PLAN_STANDARD': 'uint8',
            'VERSION': 'string'
        },
        'SmartWalletGuardMigrationModule': {
            'MAX_SNAPSHOT_ITEMS': 'uint256',
            'VERSION': 'string'
        },
        'SmartWalletMigrationHub': {
            'MAX_MIGRATION_CANCELS': 'uint256',
            'MIGRATION_DELAY': 'uint256',
            'VERSION': 'string'
        },
        'SmartWallet': {
            'VERSION': 'string'
        },
        'SmartWalletRecovery': {
            'CODE_VALIDITY': 'uint256',
            'MAX_25_DIGIT': 'uint256',
            'MIN_25_DIGIT': 'uint256',
            'REQUEST_COOLDOWN': 'uint256',
            'SECURITY_DELAY': 'uint256'
        },
    };

    /// @dev Значения, прочитанные из ABI на момент генерации.
    var VALUES = {
        'SmartWalletGuard': {}, // заполняется на цепи
        'SmartWalletPolicyOps': {}, // заполняется на цепи
        'SmartWalletPolicyRegistry': {}, // заполняется на цепи
        'SmartWalletGuardOwnerRegistry': {}, // заполняется на цепи
        'SmartWalletGuardSubscriptions': {}, // заполняется на цепи
        'SmartWalletGuardMigrationModule': {}, // заполняется на цепи
        'SmartWalletMigrationHub': {}, // заполняется на цепи
        'SmartWallet': {}, // заполняется на цепи
        'SmartWalletRecovery': {}, // заполняется на цепи
    };

    /// @dev Кодирование вызова view-функции без аргументов (для eth_call).
    function callData(name) {
        return SELECTORS[name] || null;
    }

    /// @dev селекторы view-функций: нужны, чтобы прочитать константу с цепи
    var SELECTORS = {
        'DOMAIN_SEPARATOR': '0x3644e515',
        'NATIVE': '0xa0cf0aea',
        'PERM_APP_VERIFY': '0x151feadf',
        'PERM_COLD_WARM': '0x26c96d14',
        'PERM_EMERGENCY': '0x0ffc20ca',
        'PERM_P2P': '0x632e6d80',
        'PERM_SECURITY': '0x5fb69fc9',
        'PERM_TRADING': '0x3d38ae11',
        'VERSION': '0xffa1ad74',
        'DOMAIN_SEPARATOR': '0x3644e515',
        'NATIVE': '0xa0cf0aea',
        'VERSION': '0xffa1ad74',
        'BPS_DENOMINATOR': '0xe1a45218',
        'MAX_REGISTRY_ITEMS': '0x2fa4eb16',
        'NATIVE': '0xa0cf0aea',
        'PRICE_SCALE': '0xc33f59d3',
        'USD_UNIT': '0x1baf72bf',
        'VERSION': '0xffa1ad74',
        'CRITICAL_THRESHOLD': '0x7f14c6d0',
        'HOT_OWNERS': '0x430344b4',
        'HOT_THRESHOLD': '0xf6b5c2c0',
        'MAX_WALLETS_PER_CLASS': '0x63fa82e4',
        'TOTAL_OWNERS': '0xbca45de4',
        'VERSION': '0xffa1ad74',
        'DOMAIN_SEPARATOR': '0x3644e515',
        'MAX_PLAN_CONFIGS_PER_CLAIM': '0x191aae6b',
        'NATIVE': '0xa0cf0aea',
        'PERM_APP_VERIFY': '0x151feadf',
        'PERM_COLD_WARM': '0x26c96d14',
        'PERM_EMERGENCY': '0x0ffc20ca',
        'PERM_P2P': '0x632e6d80',
        'PERM_SECURITY': '0x5fb69fc9',
        'PERM_TRADING': '0x3d38ae11',
        'PLAN_FREE': '0x14a9c8ea',
        'PLAN_PREMIUM': '0xdb553921',
        'PLAN_STANDARD': '0x2065199d',
        'VERSION': '0xffa1ad74',
        'MAX_SNAPSHOT_ITEMS': '0xc093d4f1',
        'VERSION': '0xffa1ad74',
        'MAX_MIGRATION_CANCELS': '0x2714e2ec',
        'MIGRATION_DELAY': '0xb4b0609b',
        'VERSION': '0xffa1ad74',
        'VERSION': '0xffa1ad74',
        'CODE_VALIDITY': '0x135d9090',
        'MAX_25_DIGIT': '0x65fbfa6c',
        'MIN_25_DIGIT': '0xa2f0e9c5',
        'REQUEST_COOLDOWN': '0xd3b144c6',
        'SECURITY_DELAY': '0x4d9e29ac',
    };

    /// @dev Расшифровка значения, прочитанного с цепи, по объявленному типу.
    function parse(type, word) {
        if (!word) return null;
        if (type === 'address') return '0x' + word.slice(24);
        if (type === 'bool') return BigInt('0x' + word) !== 0n;
        if (type === 'string') return null; // требует разбора offset/length
        return BigInt('0x' + word).toString();
    }

    return { TYPES: TYPES, VALUES: VALUES, SELECTORS: SELECTORS, callData: callData, parse: parse };
});
