/* ============================================================================
   МОСТ-ДЛЯ-БРАУЗЕРА.js — заглушка моста Electron для просмотра кошелька
   в обычном браузере.

   В приложении страница общается с главным процессом через window.clandai.
   Здесь его нет, и кошелёк честно сообщает «нет clandai». Чтобы внешний вид
   можно было смотреть без сборки, подставляем такой же по форме мост.

   ЧТО РАБОТАЕТ по-настоящему: создание кошелька, меню, все разделы, языки,
   настройки — всё это хранится в браузере и моста не требует.

   ЧТО НЕ РАБОТАЕТ и почему: открытие отдельного окна банка и связь с ним,
   а также инструменты ИИ-агента. Это отдельные окна Electron; вместо них
   показывается подсказка.
   ========================================================================== */
'use strict';
(function () {
    function hint(what) {
        return function () {
            console.log('[просмотр] ' + what + ': в папке для просмотра недоступно');
            if (typeof window.toast === 'function') {
                window.toast('Это доступно в приложении — здесь только просмотр вида', true);
            }
            return Promise.resolve({ ok: false, reason: 'просмотр без приложения' });
        };
    }

    window.clandai = {
        browser: { newTab: hint('браузер'), closeTab: hint('браузер'), activateTab: hint('браузер'),
                   navigate: hint('браузер'), back: hint('браузер'), forward: hint('браузер'),
                   reload: hint('браузер'), setPanel: hint('браузер'), onState: function () {} },
        win: { minimize: function () {}, maximize: function () {}, close: function () {} },
        wallet: { configure: hint('кошелёк'), prepare: hint('кошелёк'), simulate: hint('кошелёк'),
                  send: hint('кошелёк'), decoders: function () { return Promise.resolve({ ok: true, decoders: [] }); } },
        walletWin: { open: hint('окно кошелька'), close: function () {}, onRoute: function () {} },
        /* [ПРОСМОТР] Банк и агент — обычные страницы, открываем их по-настоящему
           в новой вкладке: иначе заказчик не может их посмотреть. */
        bank: { open: function () { window.open('bank.html', '_blank'); return Promise.resolve({ ok: true }); },
                close: function () {} },
        vault: { status: function () { return Promise.resolve({ ok: true, exists: false }); } },
        agent: { manifest: function () { return Promise.resolve({ ok: true, manifest: { tools: [] } }); },
                 invoke: hint('инструменты агента'), applyProposal: hint('предложения агента'),
                 onApply: function () {} }
    };

    console.log('[просмотр] мост для браузера: кошелёк работает, банк и агент открываются в новой вкладке');
})();
